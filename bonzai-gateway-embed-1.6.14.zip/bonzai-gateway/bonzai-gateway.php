<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks and order sync.
Requires Plugins: woocommerce
Version: 1.6.14
Author: Ramy
*/

if (!defined('ABSPATH')) exit;

// Used for cache-busting static assets (CSS/JS) when the plugin is updated.
if (!defined('BONZAI_GATEWAY_VERSION')) {
    define('BONZAI_GATEWAY_VERSION', '1.6.14');
}

/**
 * WooCommerce dependency guard.
 *
 * WordPress doesn't provide a strict "block install" mechanism, but we can:
 * - declare a dependency (UI support on recent WP)
 * - prevent activation without WooCommerce
 * - avoid fatal errors if WooCommerce is deactivated later
 */
function bonzai_is_woocommerce_available() {
    return class_exists('WooCommerce') && class_exists('WC_Payment_Gateway');
}

function bonzai_wc_missing_notice() {
    if (!is_admin()) return;
    if (!current_user_can('activate_plugins')) return;

    echo '<div class="notice notice-error"><p>'
        . esc_html__('Bonzai Payment Gateway requires WooCommerce to be installed and active.', 'bonzai-gateway')
        . '</p></div>';
}

register_activation_hook(__FILE__, function () {
    // On activation, ensure WooCommerce is active.
    if (!bonzai_is_woocommerce_available()) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            esc_html__('Bonzai Payment Gateway requires WooCommerce to be installed and active.', 'bonzai-gateway'),
            esc_html__('Plugin dependency missing', 'bonzai-gateway'),
            array('back_link' => true)
        );
    }
});

/**
 * Default gateway description.
 *
 * Important: some merchant setups (notably Checkout Blocks) can break client-side rendering
 * if a gateway returns a non-string/empty payload for certain fields. To be defensive, we
 * always provide a non-empty, human-readable description when the merchant leaves the field blank.
 */
function bonzai_default_gateway_description() {
    return bonzai_tr(
        'The Bonzai checkout will open after you enter your details.',
        "Le paiement Bonzai s'ouvrira après avoir saisi vos informations.",
        'El checkout de Bonzai se abrirá después de introducir tus datos.'
    );
}


/**
 * Lightweight runtime translations for EN/FR/ES.
 * This plugin supports .mo files via load_plugin_textdomain, but many merchants do not ship them.
 * The helper below ensures that core Bonzai-facing strings are translated based on the site locale.
 */
function bonzai_get_locale() {
    $loc = function_exists('determine_locale') ? determine_locale() : get_locale();
    $loc = strtolower((string) $loc);
    if (strpos($loc, 'fr') === 0) return 'fr';
    if (strpos($loc, 'es') === 0) return 'es';
    return 'en';
}
function bonzai_tr($en, $fr, $es) {
    $loc = bonzai_get_locale();
    if ($loc === 'fr') return $fr;
    if ($loc === 'es') return $es;
    return $en;
}

// Load translations (optional .mo files under /languages).
add_action('init', function () {
    load_plugin_textdomain('bonzai-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

// If the buyer returns with a wc_order param after paying on Bonzai, redirect to WooCommerce thank-you page.
add_action('template_redirect', function () {
    if (!function_exists('wc_get_order')) return;

    $order_id = 0;
    if (isset($_GET['wc_order'])) {
        $order_id = (int) $_GET['wc_order'];
    } elseif (isset($_GET['order_id'])) {
        $order_id = (int) $_GET['order_id'];
    }

    if ($order_id <= 0) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Only redirect when the order is paid to avoid looping on pending payments.
    if (method_exists($order, 'is_paid') && $order->is_paid()) {
        $thankyou = $order->get_checkout_order_received_url();

        // Bonzai may return the buyer inside an iframe (inline embed / some 3DS flows). A plain redirect would
        // only navigate the iframe, so we force a top-level navigation when possible.
        $thankyou_esc = esc_url($thankyou);

        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));

        echo '<!doctype html><html><head><meta charset="' . esc_attr(get_bloginfo('charset')) . '">';
        echo '<meta http-equiv="refresh" content="0;url=' . $thankyou_esc . '">';
        echo '<title>' . esc_html__('Redirecting…', 'bonzai-gateway') . '</title></head><body>';
        echo '<script>(function(){try{if(window.top&&window.top!==window){window.top.location.href=' . json_encode($thankyou_esc) . ';}else{window.location.href=' . json_encode($thankyou_esc) . ';}}catch(e){window.location.href=' . json_encode($thankyou_esc) . ';}})();</script>';
        echo '<a href="' . $thankyou_esc . '">' . esc_html__('Continue', 'bonzai-gateway') . '</a>';
        echo '</body></html>';
        exit;
    }
}, 1);


// WooCommerce Blocks support (Checkout Block).
// Without this, the Bonzai gateway may not appear when merchants use the block based checkout.
add_action('woocommerce_blocks_loaded', function () {
    if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
        return;
    }

    // Register Bonzai payment method type for Blocks.
    add_action('woocommerce_blocks_payment_method_type_registration', function ($payment_method_registry) {
        if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
            return;
        }

        if (!class_exists('WC_Gateway_Bonzai_Blocks')) {
            class WC_Gateway_Bonzai_Blocks extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {

                protected $name = 'bonzai';

                public function initialize() {
                    $this->settings = get_option('woocommerce_bonzai_settings', array());
                }

                public function is_active() {
                    $enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'no';
                    return $enabled === 'yes';
                }

                public function get_payment_method_script_handles() {
                    $handle = 'bonzai-gateway-blocks';

                    if (!wp_script_is($handle, 'registered')) {
                        wp_register_script(
                            $handle,
                            plugins_url('assets/bonzai-blocks.js', __FILE__),
                            array('wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-data'),
						BONZAI_GATEWAY_VERSION,
                            true
                        );
                    }

                    return array($handle);
                }

                public function get_payment_method_data() {
                    $title = isset($this->settings['title']) && $this->settings['title'] !== '' ? $this->settings['title'] : 'Bonzai';
                    $description = isset($this->settings['description']) ? (string) $this->settings['description'] : '';
                    // Defensive: a blank description can cause some checkout UIs to misbehave.
                    if (trim($description) === '') {
                        $description = bonzai_default_gateway_description();
                    }

                    $terms_required = false;
                    if (function_exists('wc_terms_and_conditions_checkbox_enabled')) {
                        $terms_required = (bool) wc_terms_and_conditions_checkbox_enabled();
                    } elseif (function_exists('wc_get_page_id')) {
                        $terms_required = (wc_get_page_id('terms') > 0);
                    }

                    return array(
                        'title'       => $title,
                        'description' => $description,
                        // Declare support for Blocks.
                        'supports'    => array('products'),
                        // Endpoints and security.
                        'prepare_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
                        'rest'         => esc_url_raw(rest_url('bonzai/v1/order-status')),
                        'nonce'        => wp_create_nonce('wp_rest'),
                        'iframe_height_3ds' => isset($this->settings['iframe_height_3ds']) ? absint($this->settings['iframe_height_3ds']) : 860,
                        'terms_required' => $terms_required,
                        // i18n
                        'i18n' => array(
                            'loading' => bonzai_tr('Loading secure payment...','Chargement du paiement sécurisé...','Cargando el pago seguro...'),
                            'error'   => bonzai_tr('Unable to load payment. Please refresh and try again.','Impossible de charger le paiement. Veuillez rafraîchir et réessayer.','No se puede cargar el pago. Actualiza e inténtalo de nuevo.'),
                            'missing_email' => bonzai_tr('Please enter a valid email to display the payment form.','Veuillez saisir un e-mail valide pour afficher le formulaire de paiement.','Introduce un correo electrónico válido para mostrar el formulario de pago.'),
                            'missing_terms' => bonzai_tr('Please accept the terms and conditions to proceed.','Veuillez accepter les conditions générales pour continuer.','Acepta los términos y condiciones para continuar.'),
                            // Requirements copy is dynamic on the front-end depending on whether the store actually shows a terms checkbox.
                            'requirements_base' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code).','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal).','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal).'),
                            'requirements_with_terms' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code), and accept the terms and conditions.','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal), et accepter les conditions générales.','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal) y acepta los términos y condiciones.'),
                            'missing_fields_base' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) antes de acceder al formulario de pago.'),
                            'missing_fields_with_terms' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) and accept the terms and conditions before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) et accepter les conditions générales avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) y acepta los términos y condiciones antes de acceder al formulario de pago.'),
                            'complete_payment' => bonzai_tr('Complete payment above to finish your order.','Terminez le paiement ci-dessus pour finaliser votre commande.','Completa el pago arriba para finalizar tu pedido.'),
                        ),
                    );
                }
            }
        }

        $payment_method_registry->register(new WC_Gateway_Bonzai_Blocks());
    });
});

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    // Hard dependency on WooCommerce. If WC is missing (or was deactivated after this plugin
    // was enabled), we must not define WC-dependent classes (prevents fatal errors).
    if (!bonzai_is_woocommerce_available()) {
        add_action('admin_notices', 'bonzai_wc_missing_notice');
        return;
    }

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = bonzai_tr('Bonzai', 'Bonzai', 'Bonzai');
            $this->method_description = bonzai_tr('Pay through Bonzai Checkout.', 'Payer via Bonzai Checkout.', 'Pagar a través de Bonzai Checkout.');
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->title               = $this->get_option('title');
            $this->description         = (string) $this->get_option('description');
            if (trim($this->description) === '') {
                $this->description = bonzai_default_gateway_description();
            }
            $this->enabled             = $this->get_option('enabled');
            $this->api_token           = trim($this->get_option('api_token'));
            $this->product_uuid        = trim($this->get_option('product_uuid'));
            // Redirect is handled by WooCommerce's native return URL (order received page).
            // Custom redirect URLs are intentionally not supported to prevent iframe-level redirects
            // and to keep behaviour consistent across Checkout Blocks and classic checkout.
			$this->popup_iframe       = $this->get_option('popup_iframe', 'yes');
			// Inline iframe embed inside WooCommerce checkout (no modal).
			$this->inline_iframe      = $this->get_option('inline_iframe', 'no');
			// Inline mode: iframe height during 3DS challenge (in px). Used by CSS variable.
			$this->iframe_height_3ds  = absint($this->get_option('iframe_height_3ds', 860));
            $this->debug               = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout             = absint($this->get_option('timeout', 20));
            $this->force_currency      = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount          = floatval($this->get_option('min_amount', 0));
            $this->webhook_token       = trim($this->get_option('webhook_token', ''));
            $this->is_vat_incl_default = $this->get_option('is_vat_incl_default', 'yes');
            $this->order_sync_enabled  = $this->get_option('order_sync_enabled', 'no');
            $this->order_sync_hour     = intval($this->get_option('order_sync_hour', 3));
            $this->order_sync_day      = strtolower($this->get_option('order_sync_day', 'monday'));

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        /**
         * Ensure required gateway settings are always sane.
         *
         * Merchants can save an empty Description in the gateway settings. In some themes / Blocks
         * setups, an empty description has been observed to break the checkout rendering.
         * We therefore normalize it to a translated default on save.
         */
        public function process_admin_options() {
            $saved = parent::process_admin_options();

            // Normalise saved options defensively.
            $key = $this->get_option_key();
            $opt = get_option($key, array());
            if (!is_array($opt)) {
                $opt = array();
            }

            // Title fallback (shouldn't happen but keep it safe).
            if (!isset($opt['title']) || trim((string) $opt['title']) === '') {
                $opt['title'] = bonzai_tr('Pay with BNZ', 'Payer avec BNZ', 'Pagar con BNZ');
            }

            // Description: prevent empty payloads.
            if (!isset($opt['description']) || trim((string) $opt['description']) === '') {
                $opt['description'] = bonzai_default_gateway_description();
            }

            update_option($key, $opt);
            return $saved;
        }

        public function init_form_fields() {
            $base_webhook_url = rest_url('bonzai/v1/webhook');

            
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => bonzai_tr('Enable', 'Activer', 'Habilitar'),
                    'type'    => 'checkbox',
                    'label'   => bonzai_tr('Enable Bonzai Checkout', 'Activer Bonzai Checkout', 'Habilitar Bonzai Checkout'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => bonzai_tr('Title', 'Titre', 'Título'),
                    'type'        => 'text',
                    'description' => bonzai_tr('Displayed title during checkout.', 'Titre affiché au moment du paiement.', 'Título mostrado durante el pago.'),
                    'default'     => bonzai_tr('Pay with BNZ', 'Payer avec BNZ', 'Pagar con BNZ'),
                ),
                'description' => array(
                    'title'       => bonzai_tr('Description', 'Description', 'Descripción'),
                    'type'        => 'textarea',
                    'default'     => bonzai_default_gateway_description(),
                    // Hint the admin UI that this field should not be left blank.
                    'custom_attributes' => array('required' => 'required'),
                ),
                'api_token' => array(
                    'title'       => bonzai_tr('API Token', 'Jeton API', 'Token API'),
                    'type'        => 'password',
                    'description' => bonzai_tr(
                        'Your Bonzai API token (Bonzai Premium dashboard → API Tokens).',
                        'Votre jeton API Bonzai (tableau de bord Bonzai Premium → API Tokens).',
                        'Tu token API de Bonzai (panel de Bonzai Premium → API Tokens).'
                    ),
                ),
                'product_uuid' => array(
                    'title'       => bonzai_tr('Bonzai Product UUID', 'UUID du produit Bonzai', 'UUID del producto Bonzai'),
                    'type'        => 'text',
                    'description' => bonzai_tr(
                        'The Bonzai product UUID used for all WooCommerce purchases.',
                        'UUID du produit Bonzai utilisé pour tous les achats WooCommerce.',
                        'UUID del producto Bonzai usado para todas las compras de WooCommerce.'
                    ),
                ),

                'popup_iframe' => array(
                    'title'       => bonzai_tr('Popup (iframe) mode', 'Mode popup (iframe)', 'Modo popup (iframe)'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Open Bonzai checkout in a modal popup (iframe)', 'Ouvrir le checkout Bonzai dans une popup modale (iframe)', 'Abrir el checkout de Bonzai en un modal (iframe)'),
                    'description' => bonzai_tr(
                        'After placing the order, the customer is redirected to a minimal page that immediately opens Bonzai checkout in a modal iframe. This improves conversion on desktop and many mobile browsers, but 3DS flows may still cause a full-page navigation depending on the bank/browser.',
                        "Après avoir passé la commande, le client est redirigé vers une page minimale qui ouvre immédiatement le checkout Bonzai dans une iframe modale. Cela améliore la conversion sur desktop et de nombreux navigateurs mobiles, mais certains parcours 3DS peuvent encore provoquer une navigation plein écran selon la banque/le navigateur.",
                        'Después de realizar el pedido, el cliente es redirigido a una página mínima que abre inmediatamente el checkout de Bonzai en un iframe modal. Esto mejora la conversión en escritorio y muchos navegadores móviles, pero algunos flujos 3DS aún pueden provocar una navegación a pantalla completa según el banco/navegador.'
                    ),
                    'default'     => 'no',
                ),

                'inline_iframe' => array(
                    'title'       => bonzai_tr('Inline embed (iframe) mode', 'Mode embed inline (iframe)', 'Modo incrustado en línea (iframe)'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Render Bonzai checkout inline inside WooCommerce checkout (no popup)', 'Intégrer le checkout Bonzai directement dans le checkout WooCommerce (sans popup)', 'Mostrar el checkout de Bonzai incrustado dentro del checkout de WooCommerce (sin popup)'),
                    'description' => bonzai_tr(
                        'If enabled, the Bonzai payment portal is embedded directly in the payment section (iframe). This mode disables the modal popup behaviour and keeps the customer on the checkout page. Note: some 3DS flows can still navigate the iframe to a full-page challenge depending on issuer/browser.',
                        "Si activé, le portail de paiement Bonzai est intégré directement dans la section paiement (iframe). Ce mode désactive la popup modale et maintient le client sur la page de paiement. Note : certains parcours 3DS peuvent encore naviguer l'iframe vers un challenge plein écran selon l’émetteur/le navigateur.",
                        'Si está activado, el portal de pago de Bonzai se incrusta directamente en la sección de pago (iframe). Este modo desactiva el comportamiento de popup modal y mantiene al cliente en la página de checkout. Nota: algunos flujos 3DS aún pueden navegar el iframe a un desafío de pantalla completa según el emisor/navegador.'
                    ),
                    'default'     => 'yes',
                ),

				'iframe_height_3ds' => array(
					'title'       => bonzai_tr('Iframe height during 3DS (px)', 'Hauteur de l’iframe pendant 3DS (px)', 'Altura del iframe durante 3DS (px)'),
					'type'        => 'number',
					'description' => bonzai_tr(
						'When the bank 3D Secure challenge is shown inside the embedded iframe, the plugin increases the iframe height. Set the height in pixels (e.g. 860).',
						'Quand le challenge 3D Secure de la banque est affiché dans l’iframe intégrée, le plugin augmente la hauteur de l’iframe. Définissez la hauteur en pixels (ex : 860).',
						'Cuando se muestra el desafío 3D Secure del banco dentro del iframe incrustado, el plugin aumenta la altura del iframe. Define la altura en píxeles (p.ej. 860).'
					),
					'default'     => '860',
					'custom_attributes' => array('min' => '300', 'max' => '2000', 'step' => '10'),
				),

                'force_currency' => array(
                    'title'       => bonzai_tr('Currency sent to Bonzai', 'Devise envoyée à Bonzai', 'Moneda enviada a Bonzai'),
                    'type'        => 'select',
                    'description' => bonzai_tr(
                        'If empty, WooCommerce currency will be used. Bonzai supports EUR or USD.',
                        'Si vide, la devise WooCommerce sera utilisée. Bonzai supporte EUR ou USD.',
                        'Si está vacío, se usará la moneda de WooCommerce. Bonzai admite EUR o USD.'
                    ),
                    'default'     => '',
                    'options'     => array(
                        ''    => bonzai_tr('Use WooCommerce currency', 'Utiliser la devise WooCommerce', 'Usar la moneda de WooCommerce'),
                        'EUR' => bonzai_tr('Force EUR', 'Forcer EUR', 'Forzar EUR'),
                        'USD' => bonzai_tr('Force USD', 'Forcer USD', 'Forzar USD'),
                    ),
                ),
                'min_amount' => array(
                    'title'       => bonzai_tr('Minimum amount', 'Montant minimum', 'Importe mínimo'),
                    'type'        => 'number',
                    'description' => bonzai_tr(
                        'Minimum cart total required to enable this payment method. Set 0 to disable.',
                        "Total minimum du panier requis pour activer ce moyen de paiement. Mettre 0 pour désactiver.",
                        'Total mínimo del carrito requerido para habilitar este método de pago. Ponga 0 para desactivar.'
                    ),
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => bonzai_tr('API Request Timeout (seconds)', "Délai d'expiration API (secondes)", 'Tiempo de espera de la API (segundos)'),
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => bonzai_tr('Debug Logs', 'Logs de debug', 'Registros de depuración'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Enable logs (WooCommerce → Status → Logs)', 'Activer les logs (WooCommerce → Statut → Logs)', 'Habilitar logs (WooCommerce → Estado → Logs)'),
                    'default'     => 'no',
                ),

                'is_vat_incl_default' => array(
                    'title'       => bonzai_tr('Amounts include VAT?', 'Montants TTC ?', '¿Importes incluyen IVA?'),
                    'type'        => 'select',
                    'description' => bonzai_tr(
                        'Default VAT handling for Bonzai amounts. Can be overridden per product.',
                        'Gestion TVA par défaut pour les montants Bonzai. Peut être surchargée par produit.',
                        'Gestión de IVA por defecto para importes Bonzai. Se puede sobrescribir por producto.'
                    ),
                    'default'     => 'yes',
                    'options'     => array(
                        'yes' => bonzai_tr('Yes, prices include VAT', 'Oui, prix TTC', 'Sí, los precios incluyen IVA'),
                        'no'  => bonzai_tr('No, prices are excl. VAT', 'Non, prix HT', 'No, los precios no incluyen IVA'),
                    ),
                ),

                'order_sync_title' => array(
                    'title'       => bonzai_tr('Automatic Bonzai order sync', 'Synchronisation automatique des commandes Bonzai', 'Sincronización automática de pedidos Bonzai'),
                    'type'        => 'title',
                    'description' => bonzai_tr(
                        'Automatically call Bonzai Retrieve an order to keep WooCommerce orders in sync.',
                        'Appelle automatiquement Bonzai “Retrieve an order” pour garder les commandes WooCommerce synchronisées.',
                        'Llama automáticamente a Bonzai “Retrieve an order” para mantener los pedidos de WooCommerce sincronizados.'
                    ),
                ),
                'order_sync_enabled' => array(
                    'title'       => bonzai_tr('Automatic sync frequency', 'Fréquence de synchronisation', 'Frecuencia de sincronización'),
                    'type'        => 'select',
                    'default'     => 'no',
                    'options'     => array(
                        'no'     => bonzai_tr('Disabled', 'Désactivé', 'Desactivado'),
                        'daily'  => bonzai_tr('Daily', 'Quotidien', 'Diaria'),
                        'weekly' => bonzai_tr('Weekly', 'Hebdomadaire', 'Semanal'),
                    ),
                ),
                'order_sync_hour' => array(
                    'title'       => bonzai_tr('Sync hour (0 to 23)', 'Heure de sync (0 à 23)', 'Hora de sincronización (0 a 23)'),
                    'type'        => 'number',
                    'default'     => '3',
                    'custom_attributes' => array('min' => '0', 'max' => '23', 'step' => '1'),
                    'description' => bonzai_tr(
                        'Hour of the day (server time) when the automatic sync should run.',
                        "Heure de la journée (heure serveur) à laquelle la synchronisation doit s'exécuter.",
                        'Hora del día (hora del servidor) en la que debe ejecutarse la sincronización.'
                    ),
                ),
                'order_sync_day' => array(
                    'title'       => bonzai_tr('Sync weekday (weekly sync)', 'Jour de sync (hebdomadaire)', 'Día de sincronización (semanal)'),
                    'type'        => 'select',
                    'default'     => 'monday',
                    'options'     => array(
                        'monday'    => bonzai_tr('Monday', 'Lundi', 'Lunes'),
                        'tuesday'   => bonzai_tr('Tuesday', 'Mardi', 'Martes'),
                        'wednesday' => bonzai_tr('Wednesday', 'Mercredi', 'Miércoles'),
                        'thursday'  => bonzai_tr('Thursday', 'Jeudi', 'Jueves'),
                        'friday'    => bonzai_tr('Friday', 'Vendredi', 'Viernes'),
                        'saturday'  => bonzai_tr('Saturday', 'Samedi', 'Sábado'),
                        'sunday'    => bonzai_tr('Sunday', 'Dimanche', 'Domingo'),
                    ),
                ),

                'webhook_title' => array(
                    'title'       => bonzai_tr('Bonzai Webhooks', 'Webhooks Bonzai', 'Webhooks de Bonzai'),
                    'type'        => 'title',
                    'description' => bonzai_tr(
                        'Bonzai sends product_access_granted and product_access_revoked. Secured using a token.',
                        'Bonzai envoie product_access_granted et product_access_revoked. Sécurisé via un token.',
                        'Bonzai envía product_access_granted y product_access_revoked. Asegurado mediante un token.'
                    ),
                ),
                'webhook_token' => array(
                    'title'       => bonzai_tr('Webhook Token', 'Token de webhook', 'Token de webhook'),
                    'type'        => 'text',
                    'description' => bonzai_tr(
                        'Use Generate token, then click Save changes. Paste the webhook URL in Bonzai Premium Webhooks.',
                        'Utilisez “Générer un token”, puis cliquez sur “Enregistrer les modifications”. Collez ensuite l’URL du webhook dans Bonzai Premium Webhooks.',
                        'Use “Generar token”, luego haga clic en “Guardar cambios”. Pegue la URL del webhook en Bonzai Premium Webhooks.'
                    ),
                ),
                'webhook_url' => array(
                    'title'       => bonzai_tr('Webhook URL', 'URL du webhook', 'URL del webhook'),
                    'type'        => 'title',
                    'description' =>
                        '<div style="margin:6px 0 10px 0;">' .
                        '<code id="bonzai_webhook_url_preview" data_base_url="' . esc_attr($base_webhook_url) . '">' .
                        esc_html($base_webhook_url . '?token=YOUR_TOKEN') .
                        '</code>' .
                        '</div>' .
                        '<div style="font-size:12px; color:#444;">' . esc_html(bonzai_tr('Paste this URL in Bonzai Premium Webhooks.', 'Collez cette URL dans Bonzai Premium Webhooks.', 'Pegue esta URL en Bonzai Premium Webhooks.')) . '</div>',
                ),
            );

}

        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai_gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function admin_options() {
            parent::admin_options();
            ?>
            <script type="text/javascript">
            (function($){
                $(function(){
                    var $tokenField = $('#woocommerce_bonzai_webhook_token');
                    if (!$tokenField.length) return;

var bonzaiGenerateTokenLabel = <?php echo wp_json_encode( bonzai_tr('Generate token', 'Générer un token', 'Generar token') ); ?>;
                    var $btn = $('<button type="button" class="button" style="margin-left:8px;"></button>').text(bonzaiGenerateTokenLabel);
                    $btn.insertAfter($tokenField);

                    var $preview = $('#bonzai_webhook_url_preview');
                    var baseUrl  = $preview.attr('data_base_url') || $preview.text();

                    function updatePreview() {
                        var token = $.trim($tokenField.val());
                        var url = baseUrl;
                        if (token) {
                            url += '?token=' + encodeURIComponent(token);
                        } else {
                            url += '?token=YOUR_TOKEN';
                        }
                        $preview.text(url);
                    }

                    $btn.on('click', function(e){
                        e.preventDefault();

                        var token = '';
                        while (token.length < 32) {
                            token += Math.random().toString(36).substring(2);
                        }
                        token = token.substring(0, 32);

                        $tokenField.val(token);
                        $tokenField.trigger('change');
                        updatePreview();

                        var $form = $tokenField.closest('form');
                        if ($form.length) {
                            $form.trigger('change');
                        }
                    });

                    $tokenField.on('input change', updatePreview);
                    updatePreview();
                });
            })(jQuery);
            </script>
            <?php
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) {
                $currency = 'EUR';
            }

            $email = $order->get_billing_email() ?: '';
            // Always rely on WooCommerce's native return URL (order received page).
            // We also add wc_order for our redirect bridge / iframe-safe navigation logic.
            $redirect_url = add_query_arg(
                array('wc_order' => $order->get_id()),
                $order->get_checkout_order_received_url()
            );

            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            $is_vat_incl = ($this->is_vat_incl_default === 'yes');
            $mode        = 'one_off';
            $interval    = null;

            if ($item_count > 0 && is_array($items)) {
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    $product_id   = $item->get_product_id();
                    $product      = $product_id ? wc_get_product($product_id) : null;

                    if ($product_id) {
                        $override_vat = get_post_meta($product_id, 'bonzai_is_vat_incl', true);
                        if ($override_vat === 'yes') $is_vat_incl = true;
                        if ($override_vat === 'no')  $is_vat_incl = false;
                    }

                    $product_mode = $product_id ? get_post_meta($product_id, 'bonzai_payment_mode', true) : '';

                    if ($product && empty($product_mode)) {
                        if (class_exists('WC_Product_Subscription') && $product instanceof WC_Product_Subscription) {
                            $product_mode = 'subscription_auto';
                        } elseif (class_exists('WC_Product_Variable_Subscription') && $product instanceof WC_Product_Variable_Subscription) {
                            $product_mode = 'subscription_auto';
                        }
                    }

                    if ($product_mode === 'subscription_monthly') {
                        $mode     = 'subscription';
                        $interval = 'month';
                    } elseif ($product_mode === 'subscription_yearly') {
                        $mode     = 'subscription';
                        $interval = 'year';
                    } elseif ($product_mode === 'subscription_auto') {
                        $mode = 'subscription';
                        if ($product && is_callable(array($product, 'get_billing_period'))) {
                            $period = (string) $product->get_billing_period();
                            if ($period === 'year') {
                                $interval = 'year';
                            } else {
                                $interval = 'month';
                            }
                        } else {
                            $interval = 'month';
                        }
                    } else {
                        $mode     = 'one_off';
                        $interval = null;
                    }

                    break;
                }
            }

            if ($product_name) {
                if ($item_count > 1) {
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    $bonzai_title = $product_name;
                }
            } else {
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => (bool) $is_vat_incl,
                'mode'         => $mode,
            );

            if ($interval && $mode === 'subscription') {
                $payload['interval'] = $interval;
            }

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            // Prefill customer identity on Bonzai checkout (optional fields).
            $first_name = method_exists($order, 'get_billing_first_name') ? (string) $order->get_billing_first_name() : '';
            $last_name  = method_exists($order, 'get_billing_last_name') ? (string) $order->get_billing_last_name() : '';
            if (!empty($first_name)) {
                $payload['firstname'] = sanitize_text_field($first_name);
            }
            if (!empty($last_name)) {
                $payload['lastname'] = sanitize_text_field($last_name);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = (string) wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            $this->log('Bonzai checkout response HTTP ' . $code_http . ' body=' . $body_txt);

            $bonzai_error_msg = '';
            if (is_array($body)) {
                if (!empty($body['message'])) {
                    $bonzai_error_msg = (string) $body['message'];
                } elseif (!empty($body['errors']) && is_array($body['errors'])) {
                    foreach ($body['errors'] as $field => $messages) {
                        if (is_array($messages) && !empty($messages)) {
                            $bonzai_error_msg = (string) $field . ': ' . (string) reset($messages);
                            break;
                        }
                    }
                }
            }

            if ($code_http < 200 || $code_http >= 300 || !is_array($body) || empty($body['checkout_url'])) {
                $note = 'Bonzai API HTTP ' . $code_http . ' -> ' . $body_txt;
                $order->add_order_note($note);

                $human_msg = 'Unable to create Bonzai payment.';
                if ($bonzai_error_msg) {
                    $human_msg .= ' Bonzai says: ' . $bonzai_error_msg;
                } else {
                    $human_msg .= ' Please try again later.';
                }

                return $this->fail_with_notice($order, $human_msg);
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                // Use WooCommerce order meta API (HPOS compatible).
                $order->update_meta_data('_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }

// Store URLs (HPOS compatible).
$order->update_meta_data('_bonzai_checkout_url', esc_url_raw($body['checkout_url']));
if (!empty($body['embed_url'])) {
    $order->update_meta_data('_bonzai_embed_url', esc_url_raw($body['embed_url']));
}

// Persist meta changes before redirecting.
$order->save();

// Inline (iframe) mode: keep the customer on the checkout page and render the Bonzai payment UI inline.
// We return a redirect to the SAME checkout URL with a hash.
if (isset($this->inline_iframe) && $this->inline_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can render inline without leaving the checkout page.
	if (function_exists('WC') && WC() && WC()->session) {
		// Reuse the existing session keys used by the "popup session" AJAX endpoint.
		WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
		WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
		WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
	}

    $checkout_url = '';
    if (!empty($_POST['bonzai_checkout_page_url'])) {
        $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
    }
    if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
        $session_url = WC()->session->get('bonzai_checkout_page_url');
        if (!empty($session_url)) {
            $checkout_url = esc_url_raw($session_url);
        }
    }
    if (empty($checkout_url)) {
        $checkout_url = wc_get_checkout_url();
    }

    return array(
        'result'   => 'success',
        'redirect' => $checkout_url . '#bonzai-inline',
    );
}

// Popup (iframe) mode: keep the customer on the checkout page and open a modal iframe.
// We return a redirect to the SAME checkout URL with a hash. This prevents a full page change,
// even on sites where WooCommerce checkout interception is unreliable.
if ($this->popup_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can open the modal without leaving the checkout page.
    if (function_exists('WC') && WC()->session) {
					// Reuse the existing session keys used by the wc-ajax endpoint (bonzai_popup_session).
					WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
					WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
					WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
    }

    // Stay on the current checkout page (works with custom checkout pages/builders).
// IMPORTANT: wp_get_referer() can be the wc-ajax endpoint (update_order_review), so we prefer an explicit
// URL passed from the checkout page (front-end) to avoid redirecting to wc-ajax URLs (which can 403).
$checkout_url = '';

// 1) Prefer the explicit URL passed from the browser.
if (!empty($_POST['bonzai_checkout_page_url'])) {
    $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
}

// 2) Fallback to session (captured during template render), which is more reliable with checkout builders.
if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
    $session_url = WC()->session->get('bonzai_checkout_page_url');
    if (!empty($session_url)) {
        $checkout_url = esc_url_raw($session_url);
    }
}

// 3) Final fallback: WooCommerce configured checkout page.
if (empty($checkout_url)) {
    $checkout_url = wc_get_checkout_url();
}

// Only allow same-origin URLs (protect against open redirects).
$home_host = parse_url(home_url('/'), PHP_URL_HOST);
$url_host  = parse_url($checkout_url, PHP_URL_HOST);
if (!$home_host || !$url_host || strtolower($home_host) !== strtolower($url_host)) {
    $checkout_url = wc_get_checkout_url();
}

// Remove any wc-ajax param if present and drop existing hash.
$checkout_url = remove_query_arg('wc-ajax', $checkout_url);
$checkout_url = preg_replace('/#.*$/', '', $checkout_url);

// Hash-only change so the customer stays on the same page.
$hash = ($this->inline_iframe === 'yes') ? '#bonzai-inline' : '#bonzai';
$checkout_url = $checkout_url . $hash;

    return array(
        'result'           => 'success',
        'redirect'         => esc_url_raw($checkout_url),
        'bonzai_wc_order'  => (int) $order->get_id(),
        'bonzai_order_key' => (string) $order->get_order_key(),
        'bonzai_thankyou'  => esc_url_raw($this->get_return_url($order)),
        'bonzai_embed_url' => esc_url_raw($iframe_url),
    );
}

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}



/**
 * Popup checkout mode (iframe)
 * Adds an endpoint under the merchant domain:
 *   /bonzai/popup/{order_id}/{order_key}
 * which renders a minimal page that opens Bonzai checkout in a full-screen modal iframe.
 *
 * This avoids relying on WooCommerce redirect interception (which varies across themes/builders/blocks).
 */

register_activation_hook(__FILE__, 'bonzai_gateway_activate');
register_deactivation_hook(__FILE__, 'bonzai_gateway_deactivate');

function bonzai_gateway_activate() {
    bonzai_gateway_add_rewrite_rules();
    flush_rewrite_rules();
}

function bonzai_gateway_deactivate() {
    flush_rewrite_rules();
}



// Persist the real checkout page URL in the WooCommerce session so we can reliably redirect back to it
// after placing the order (even when the actual checkout submission happens via wc-ajax endpoints).
add_action('template_redirect', function () {
    if (is_admin() || !function_exists('WC') || !WC() || !WC()->session) {
        return;
    }

    $is_checkout_like = function_exists('is_checkout') && is_checkout();
    $is_cartflows_checkout = isset($_GET['wcf_checkout_id']);
    $looks_like_checkout_path = isset($_SERVER['REQUEST_URI']) && (strpos($_SERVER['REQUEST_URI'], 'checkout') !== false);

    if (!$is_checkout_like && !$is_cartflows_checkout && !$looks_like_checkout_path) {
        return;
    }

    $scheme = is_ssl() ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $uri    = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

    if (empty($host)) {
        return;
    }

    $url = $scheme . '://' . $host . $uri;

    // Strip fragments and wc-ajax query param if present.
    $url = preg_replace('/#.*$/', '', $url);
    if (function_exists('remove_query_arg')) {
        $url = remove_query_arg('wc-ajax', $url);
    }

    // WC session might not be initialized on some non-standard checkout pages.
    if (function_exists('WC') && WC() && isset(WC()->session) && WC()->session) {
        WC()->session->set('bonzai_checkout_page_url', $url);
    }
}, 1);

add_action('wp_enqueue_scripts', function () {
    // Load embedded UI assets on checkout-like pages.
    if (is_admin()) return;
    if (!class_exists('WooCommerce')) return;

    $settings  = get_option('woocommerce_bonzai_settings', array());
    $inline_on = isset($settings['inline_iframe']) ? ($settings['inline_iframe'] === 'yes') : false;
    $popup_on  = isset($settings['popup_iframe']) ? ($settings['popup_iframe'] === 'yes') : false;

    // Inline has priority over popup.
    if (!$inline_on && !$popup_on) {
        return;
    }

    $plugin_url = plugin_dir_url(__FILE__);

    if ($inline_on) {
		wp_enqueue_script('bonzai-inline', $plugin_url . 'assets/bonzai-inline.js', array('jquery'), BONZAI_GATEWAY_VERSION, true);
		wp_enqueue_style('bonzai-inline-ui', $plugin_url . 'assets/bonzai-inline.css', array(), BONZAI_GATEWAY_VERSION);

		// Allow merchants to tune iframe height specifically during 3DS.
		$h = 860;
		if (isset($settings['iframe_height_3ds'])) {
			$h = absint($settings['iframe_height_3ds']);
		}
		// Defensive bounds.
		if ($h < 300) $h = 300;
		if ($h > 2000) $h = 2000;
		wp_add_inline_style('bonzai-inline-ui', '#bonzai-inline-container{--bonzai-3ds-height:' . $h . 'px;}');
        $proceed_label = bonzai_tr('Proceed to Bonzai','Procéder vers Bonzai','Proceder a Bonzai');

        wp_localize_script('bonzai-inline', 'BONZAI_INLINE', array(
			// 3DS height (px) so the front-end can force the iframe height even when 3DS
			// happens inside nested frames without URL changes or postMessage events.
			'iframe_height_3ds' => $h,
            'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
            'nonce' => wp_create_nonce('wp_rest'),
            'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
            'prepare_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
            'gateway_id'   => 'bonzai',
            'hash'         => '#bonzai-inline',
            // UX: on page refresh, create a fresh Bonzai session rather than showing a potentially stale iframe.
            'force_new_on_load' => true,
            'order_button_selector' => '#place_order',
            'i18n' => array(
                'proceed_to_bonzai' => $proceed_label,
                'loading' => bonzai_tr('Loading secure payment...','Chargement du paiement sécurisé...','Cargando el pago seguro...'),
                'error'   => bonzai_tr('Unable to load payment. Please refresh and try again.','Impossible de charger le paiement. Veuillez rafraîchir et réessayer.','No se puede cargar el pago. Actualiza e inténtalo de nuevo.'),
                'missing_email' => bonzai_tr('Please enter a valid email to display the payment form.','Veuillez saisir un e-mail valide pour afficher le formulaire de paiement.','Introduce un correo electrónico válido para mostrar el formulario de pago.'),
                'missing_terms' => bonzai_tr('Please accept the terms and conditions to proceed.','Veuillez accepter les conditions générales pour continuer.','Acepta los términos y condiciones para continuar.'),
                // Requirements copy is dynamic on the front-end depending on whether the store actually shows a terms checkbox.
                'requirements_base' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code).','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal).','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal).'),
                'requirements_with_terms' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code), and accept the terms and conditions.','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal), et accepter les conditions générales.','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal) y acepta los términos y condiciones.'),
                'missing_fields_base' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) antes de acceder al formulario de pago.'),
                'missing_fields_with_terms' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) and accept the terms and conditions before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) et accepter les conditions générales avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) y acepta los términos y condiciones antes de acceder al formulario de pago.'),
            ),
        ));
        return;
    }

    // Popup fallback.
	wp_enqueue_script('bonzai-popup', $plugin_url . 'assets/bonzai-popup.js', array('jquery'), BONZAI_GATEWAY_VERSION, true);
	wp_enqueue_style('bonzai-popup-ui', $plugin_url . 'assets/bonzai-popup.css', array(), BONZAI_GATEWAY_VERSION);
    wp_localize_script('bonzai-popup', 'BONZAI_POPUP', array(
        'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
        'nonce' => wp_create_nonce('wp_rest'),
        'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
        'i18n' => array(
            'title' => bonzai_tr('Secure payment','Paiement sécurisé','Pago seguro'),
            'close' => bonzai_tr('Close','Fermer','Cerrar'),
        ),
    ));
});

/**
 * Iframe escape hatch for WooCommerce thank-you pages.
 *
 * In certain embedded/3DS flows, the payment provider may navigate the iframe back
 * to the merchant "order received" page. With WooCommerce Blocks checkout, this
 * can cause the thank-you page to render inside the Bonzai iframe (small preview)
 * while the parent page remains on checkout.
 *
 * This snippet forces a top-level navigation whenever the order-received page is
 * loaded inside an iframe.
 */
add_action('wp_footer', function () {
    if (function_exists('is_order_received_page') && is_order_received_page()) {
        echo "\n<script>(function(){try{if(window.top&&window.top!==window.self){window.top.location.href=window.location.href;}}catch(e){/* noop */}})();</script>\n";
    }
}, 100);

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'callback' => function (\WP_REST_Request $req) {
            $order_id  = (int) $req->get_param('order_id');
            $order_key = (string) $req->get_param('order_key');

            if ($order_id <= 0 || $order_key === '') {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'missing_params'), 400);
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'order_not_found'), 404);
            }

            if (!hash_equals((string) $order->get_order_key(), $order_key)) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_key'), 403);
            }

            $status = (string) $order->get_status();
            $paid   = in_array($status, array('processing', 'completed'), true);

            return new \WP_REST_Response(array(
                'ok'       => true,
                'status'   => $status,
                'paid'     => $paid,
                'thankyou' => esc_url_raw($order->get_checkout_order_received_url()),
            ), 200);
        },
        'permission_callback' => '__return_true',
        'args' => array(
            'order_id' => array('required' => true),
            'order_key' => array('required' => true),
        ),
    ));
});

// Ensure order-status polling is never cached by page caches, reverse proxies or browser caches.
add_filter('rest_post_dispatch', function ($result, $server, $request) {
    if (!($request instanceof WP_REST_Request)) {
        return $result;
    }

    if ($request->get_route() !== '/bonzai/v1/order-status') {
        return $result;
    }

    if ($result instanceof WP_REST_Response) {
        $result->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $result->header('Pragma', 'no-cache');
    }

    return $result;
}, 10, 3);

// WooCommerce AJAX endpoint to fetch the last Bonzai embed URL stored in the session.
add_action('wc_ajax_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
add_action('wc_ajax_nopriv_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
function bonzai_wc_ajax_popup_session() {
    // Prevent reverse proxies / cache plugins from caching session-specific responses.
    if (function_exists('nocache_headers')) {
        nocache_headers();
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    if (!function_exists('WC') || !WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'));
    }

    $embed_url = WC()->session->get('bonzai_popup_iframe_url');
    $thankyou  = WC()->session->get('bonzai_popup_thankyou');
    $order_id  = WC()->session->get('bonzai_popup_order_id');

    // Backward-compat fallback (older keys).
    if (empty($embed_url)) {
        $embed_url = WC()->session->get('bonzai_last_embed_url');
    }
    if (empty($thankyou)) {
        $thankyou = WC()->session->get('bonzai_last_thankyou');
    }
    if (empty($order_id)) {
        $order_id = WC()->session->get('bonzai_last_order_id');
    }
    if (empty($embed_url)) {
        wp_send_json(array('ok' => false, 'error' => 'no_embed_url'));
    }

    wp_send_json(array(
        'ok'        => true,
        'order_id'  => (int) $order_id,
        'embed_url' => esc_url_raw($embed_url),
        'thankyou'  => esc_url_raw($thankyou),
    ));
}


// Inline embed mode: prepare (or reuse) a Bonzai checkout session WITHOUT requiring the customer
// to click the WooCommerce "Place order" button.
//
// This endpoint will:
//  - parse the checkout form fields,
//  - create (or reuse) a pending WooCommerce order linked to the current cart,
//  - call Bonzai /checkout to obtain embed_url,
//  - store embed_url + order info in the WC session for the front-end.
add_action('wc_ajax_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
add_action('wc_ajax_nopriv_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
function bonzai_wc_ajax_inline_prepare() {
    // Prevent reverse proxies / cache plugins from caching session-specific responses.
    if (function_exists('nocache_headers')) {
        nocache_headers();
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    $force_new = isset($_POST['force_new']) && (int) $_POST['force_new'] === 1;
    if ( $force_new && WC()->session ) {
    WC()->session->__unset('bonzai_popup_iframe_url');
    WC()->session->__unset('bonzai_popup_thankyou');
    WC()->session->__unset('bonzai_popup_order_id');
    WC()->session->__unset('bonzai_popup_order_key');
    }
    if (!function_exists('WC') || !WC() || !WC()->cart) {
        wp_send_json(array('ok' => false, 'error' => 'woocommerce_unavailable'), 500);
    }
    if (!WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'), 500);
    }

    $gateway = bonzai_get_gateway_instance();
    if (!$gateway || !is_object($gateway) || !method_exists($gateway, 'get_option')) {
        wp_send_json(array('ok' => false, 'error' => 'gateway_unavailable'), 500);
    }

    // Only operate in inline iframe mode.
    $inline_on = ($gateway->get_option('inline_iframe', 'no') === 'yes');
    if (!$inline_on) {
        wp_send_json(array('ok' => false, 'error' => 'inline_disabled'), 400);
    }

    $force_new = false;
    if (isset($_POST['force_new'])) {
        $force_new = ((int) wp_unslash($_POST['force_new'])) === 1;
    }

    // If explicitly requested, drop any previously prepared session/order linkage so we create a fresh payment.
    if ($force_new) {
        WC()->session->set('bonzai_inline_fp', '');
        WC()->session->set('bonzai_popup_iframe_url', '');
        WC()->session->set('bonzai_inline_wc_order_id', 0);
        WC()->session->set('bonzai_inline_wc_order_key', '');
    }

    $raw = '';
    if (isset($_POST['checkout_data'])) {
        $raw = (string) wp_unslash($_POST['checkout_data']);
    }

    $posted = array();
    if ($raw !== '') {
        wp_parse_str($raw, $posted);
    }

    // Checkout Blocks compatibility: there is no classic checkout form serialization.
    // Allow key fields to be sent directly.
    if (empty($posted) || (!isset($posted['billing_email']) && isset($_POST['billing_email']))) {
        foreach (array(
            'billing_email',
            'billing_first_name',
            'billing_last_name',
            'billing_postcode',
            'billing_address_1',
            'billing_city',
            'billing_country',
            'billing_state',
            'terms'
        ) as $k) {
            if (isset($_POST[$k]) && !isset($posted[$k])) {
                $posted[$k] = (string) wp_unslash($_POST[$k]);
            }
        }
    }

    // Ensure payment method is set to Bonzai for the created order.
    $posted['payment_method'] = 'bonzai';

    $email = '';
    if (isset($posted['billing_email'])) {
        $email = sanitize_email((string) $posted['billing_email']);
    }
    if (!$email || !is_email($email)) {
        wp_send_json(array('ok' => false, 'error' => 'missing_email'), 400);
    }

    $first = isset($posted['billing_first_name']) ? sanitize_text_field((string) $posted['billing_first_name']) : '';
    $last  = isset($posted['billing_last_name']) ? sanitize_text_field((string) $posted['billing_last_name']) : '';
    $postcode = isset($posted['billing_postcode']) ? sanitize_text_field((string) $posted['billing_postcode']) : '';
    $address1 = isset($posted['billing_address_1']) ? sanitize_text_field((string) $posted['billing_address_1']) : '';
    $city = isset($posted['billing_city']) ? sanitize_text_field((string) $posted['billing_city']) : '';
    $country = isset($posted['billing_country']) ? sanitize_text_field((string) $posted['billing_country']) : '';
    $state = isset($posted['billing_state']) ? sanitize_text_field((string) $posted['billing_state']) : '';

    // Enforce required checkout fields for Bonzai.
    // IMPORTANT: Not all countries require a state/region (e.g. FR). We only require it when
    // WooCommerce defines states for the selected country.
    $needs_state = false;
    if ($country && function_exists('WC') && WC()->countries && method_exists(WC()->countries, 'get_states')) {
        $states = WC()->countries->get_states($country);
        $needs_state = !empty($states);
    }

    if ($first === '' || $last === '' || $address1 === '' || $postcode === '' || $city === '' || $country === '' || ($needs_state && $state === '')) {
        wp_send_json(array('ok' => false, 'error' => 'missing_required_fields'), 400);
    }

    // Enforce Terms & Conditions acceptance only if the store requires it.
    // Some stores don't show the checkbox at all (or disable it). In that case we must not block.
    $terms_required = false;
    if (function_exists('wc_terms_and_conditions_checkbox_enabled')) {
        $terms_required = (bool) wc_terms_and_conditions_checkbox_enabled();
    } else {
        // Best-effort fallback for older WC: require only if a terms page exists.
        if (function_exists('wc_get_page_id')) {
            $terms_required = (wc_get_page_id('terms') > 0);
        } else {
            $terms_required = false;
        }
    }

    if ($terms_required) {
        // WooCommerce classic usually sends terms=on. Blocks may send 1/true.
        $terms_ok = false;
        if (isset($posted['terms'])) {
            $t = (string) $posted['terms'];
            $terms_ok = in_array($t, array('1', 'true', 'on', 'yes'), true);
        }
        if (!$terms_ok) {
            wp_send_json(array('ok' => false, 'error' => 'missing_terms'), 400);
        }
    }

    $cart_hash = is_callable(array(WC()->cart, 'get_cart_hash')) ? (string) WC()->cart->get_cart_hash() : '';
    $total     = (float) WC()->cart->get_total('edit');
    $currency  = get_woocommerce_currency();
    $force_currency = strtoupper(trim((string) $gateway->get_option('force_currency', '')));
    $target_currency = $force_currency ? $force_currency : $currency;
    if (!in_array($target_currency, array('EUR', 'USD'), true)) {
        $target_currency = 'EUR';
    }

    $fingerprint = md5(wp_json_encode(array(
        'cart' => $cart_hash,
        'email' => $email,
        'first' => $first,
        'last' => $last,
        'postcode' => $postcode,
        'total' => round($total, 2),
        'currency' => $target_currency,
    )));

    // Reuse an existing prepared session if it matches the current fingerprint.
    $prev_fp = (string) WC()->session->get('bonzai_inline_fp');
    $prev_embed = (string) WC()->session->get('bonzai_popup_iframe_url');
    $prev_order_id = (int) WC()->session->get('bonzai_inline_wc_order_id');
    $prev_order_key = (string) WC()->session->get('bonzai_inline_wc_order_key');
    if (!$force_new && $prev_fp && $prev_fp === $fingerprint && $prev_embed && $prev_order_id > 0 && $prev_order_key) {
        wp_send_json(array(
            'ok'        => true,
            'reused'    => true,
            'order_id'  => $prev_order_id,
            'order_key' => $prev_order_key,
            'embed_url' => esc_url_raw($prev_embed),
        ));
    }

    // Create or reuse a pending Woo order tied to the cart.
    $wc_order = null;
    $existing_id = $force_new ? 0 : (int) WC()->session->get('bonzai_inline_wc_order_id');
    if ($existing_id > 0) {
        $candidate = wc_get_order($existing_id);
        if ($candidate && method_exists($candidate, 'get_status')) {
            $status = (string) $candidate->get_status();
            $is_paid = method_exists($candidate, 'is_paid') ? (bool) $candidate->is_paid() : in_array($status, array('processing', 'completed'), true);
            $candidate_cart = (string) $candidate->get_meta('_bonzai_cart_hash', true);
            if (!$is_paid && in_array($status, array('pending', 'failed', 'on-hold'), true) && $candidate_cart === $cart_hash) {
                $wc_order = $candidate;
            }
        }
    }

    if (!$wc_order) {
        try {
            if (!WC()->checkout()) {
                wp_send_json(array('ok' => false, 'error' => 'checkout_unavailable'), 500);
            }
            // create_order adds cart line items automatically.
            $new_id = WC()->checkout()->create_order($posted);
            $wc_order = $new_id ? wc_get_order($new_id) : null;
        } catch (Exception $e) {
            wp_send_json(array('ok' => false, 'error' => 'order_create_failed', 'message' => $e->getMessage()), 400);
        }
    }

    if (!$wc_order) {
        wp_send_json(array('ok' => false, 'error' => 'order_not_created'), 500);
    }

    // Update billing fields on the reused order (or the new one).
    if (method_exists($wc_order, 'set_billing_email')) $wc_order->set_billing_email($email);
    if (method_exists($wc_order, 'set_billing_first_name')) $wc_order->set_billing_first_name($first);
    if (method_exists($wc_order, 'set_billing_last_name')) $wc_order->set_billing_last_name($last);
    if (method_exists($wc_order, 'set_billing_postcode')) $wc_order->set_billing_postcode($postcode);
    $wc_order->update_meta_data('_bonzai_cart_hash', $cart_hash);
    $wc_order->save();

    // Call Bonzai to create a checkout session.
    $api_token = trim((string) $gateway->get_option('api_token'));
    $product_uuid = trim((string) $gateway->get_option('product_uuid'));
    if ($api_token === '' || $product_uuid === '') {
        wp_send_json(array('ok' => false, 'error' => 'missing_settings'), 500);
    }

    $amount = (float) $wc_order->get_total();
    if ($amount <= 0) {
        wp_send_json(array('ok' => false, 'error' => 'invalid_amount'), 400);
    }

    // Always rely on WooCommerce's native return URL (order received page).
    // Add wc_order for our redirect bridge / iframe-safe navigation logic.
    $redirect_url = add_query_arg(
        array('wc_order' => $wc_order->get_id()),
        $wc_order->get_checkout_order_received_url()
    );

    $is_vat_incl = ((string) $gateway->get_option('is_vat_incl_default', 'yes') === 'yes');

    $bonzai_title = 'WooCommerce Order #' . $wc_order->get_order_number();
    $items = $wc_order->get_items('line_item');
    if (is_array($items) && !empty($items)) {
        foreach ($items as $item) {
            $bonzai_title = (string) $item->get_name();
            break;
        }
    }

    $payload = array(
        'amount'       => round($amount, 2),
        'currency'     => $target_currency,
        'title'        => $bonzai_title,
        'redirect_url' => $redirect_url,
        'metadata'     => array(
            'wc_order_id' => $wc_order->get_id(),
            'site'        => home_url(),
        ),
        'is_vat_incl'  => (bool) $is_vat_incl,
        'mode'         => 'one_off',
        'email'        => $email,
    );

    if ($first !== '') $payload['firstname'] = $first;
    if ($last !== '')  $payload['lastname']  = $last;
    if ($postcode !== '') $payload['postal_code'] = $postcode;

    if (method_exists($gateway, 'log')) {
        // noop: keep compatibility if gateway has log method in future.
    }

    $resp = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type'  => 'application/json',
        ),
        'body'    => wp_json_encode($payload),
        'timeout' => 20,
    ));

    if (is_wp_error($resp)) {
        wp_send_json(array('ok' => false, 'error' => 'bonzai_api_error', 'message' => $resp->get_error_message()), 502);
    }

    $http = (int) wp_remote_retrieve_response_code($resp);
    $body_txt = (string) wp_remote_retrieve_body($resp);
    $body = json_decode($body_txt, true);

    if ($http < 200 || $http >= 300 || !is_array($body) || (empty($body['embed_url']) && empty($body['checkout_url']))) {
        wp_send_json(array('ok' => false, 'error' => 'bonzai_bad_response', 'http' => $http, 'body' => $body), 502);
    }

    $iframe_url = !empty($body['embed_url']) ? (string) $body['embed_url'] : (string) $body['checkout_url'];

    // Persist linkage on the order.
    if (!empty($body['order_id'])) {
        $wc_order->update_meta_data('_bonzai_order_id', sanitize_text_field((string) $body['order_id']));
    }
    if (!empty($body['checkout_url'])) {
        $wc_order->update_meta_data('_bonzai_checkout_url', esc_url_raw((string) $body['checkout_url']));
    }
    if (!empty($body['embed_url'])) {
        $wc_order->update_meta_data('_bonzai_embed_url', esc_url_raw((string) $body['embed_url']));
    }
    $wc_order->save();

    // Store for the frontend.
    WC()->session->set('bonzai_inline_fp', $fingerprint);
    WC()->session->set('bonzai_inline_wc_order_id', (int) $wc_order->get_id());
    WC()->session->set('bonzai_inline_wc_order_key', (string) $wc_order->get_order_key());
    WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
    WC()->session->set('bonzai_popup_thankyou', esc_url_raw($wc_order->get_checkout_order_received_url()));
    WC()->session->set('bonzai_popup_order_id', (int) $wc_order->get_id());

    wp_send_json(array(
        'ok'        => true,
        'reused'    => false,
        'order_id'  => (int) $wc_order->get_id(),
        'order_key' => (string) $wc_order->get_order_key(),
        'embed_url' => esc_url_raw($iframe_url),
    ));
}


add_action('init', 'bonzai_gateway_add_rewrite_rules');

function bonzai_gateway_add_rewrite_rules() {
    $popup_base = 'bonzai/popup';
    $popup_base = ltrim($popup_base, '/');

    // Accept alnum, underscore, and hyphen in order key.
    add_rewrite_rule('^' . preg_quote($popup_base, '/') . '/([0-9]+)/([a-zA-Z0-9_\-]+)/?$', 'index.php?bonzai_popup=1&bonzai_order_id=$matches[1]&bonzai_order_key=$matches[2]', 'top');
}

add_filter('query_vars', function($vars) {
    $vars[] = 'bonzai_popup';
    $vars[] = 'bonzai_order_id';
    $vars[] = 'bonzai_order_key';
    return $vars;
});

add_action('template_redirect', function() {
    if (get_query_var('bonzai_popup')) {
        bonzai_render_popup_page();
        exit;
    }
});

/**
 * Renders the popup page. It loads the Bonzai embed URL inside an iframe.
 * If embed URL is missing, it falls back to checkout URL.
 */
function bonzai_render_popup_page() {
    if (!function_exists('wc_get_order')) {
        status_header(500);
        echo 'WooCommerce not available.';
        return;
    }

    // Prevent WP canonical redirects from altering signed URLs.
    remove_filter('template_redirect', 'redirect_canonical');

    $order_id  = absint(get_query_var('bonzai_order_id'));
    $order_key = (string) get_query_var('bonzai_order_key');

    $order = $order_id ? wc_get_order($order_id) : null;
    if (!$order) {
        status_header(404);
        echo 'Invalid WooCommerce order.';
        return;
    }

    if (!$order_key || $order_key !== $order->get_order_key()) {
        status_header(403);
        echo 'Invalid order key.';
        return;
    }

    $embed_url    = (string) $order->get_meta('_bonzai_embed_url', true);
    $checkout_url = (string) $order->get_meta('_bonzai_checkout_url', true);

    $target_url = $embed_url ? $embed_url : $checkout_url;
    if (!$target_url) {
        status_header(400);
        echo 'Missing Bonzai checkout URL.';
        return;
    }

    // Security: only allow bonzai.pro and subdomains.
    $extracted = bonzai_extract_bonzai_target($target_url);
    if (!$extracted) {
        status_header(400);
        echo 'Invalid Bonzai checkout URL.';
        return;
    }

    $iframe_src = esc_url($target_url);

    header('Content-Type: text/html; charset=utf-8');
    ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Secure payment</title>
  <style>
    html, body { height: 100%; margin: 0; padding: 0; background: #0b0f14; font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif; }
    .bz-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.72); display: flex; align-items: center; justify-content: center; z-index: 999999; }
    .bz-modal { width: min(1100px, 96vw); height: min(760px, 92vh); background: #0b0f14; border-radius: 12px; overflow: hidden; box-shadow: 0 12px 48px rgba(0,0,0,0.55); position: relative; }
    .bz-topbar { height: 44px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; background: rgba(255,255,255,0.06); color: #fff; }
    .bz-topbar .title { font-size: 14px; opacity: 0.9; }
    .bz-close { background: rgba(255,255,255,0.12); border: 0; color: #fff; padding: 8px 10px; border-radius: 8px; cursor: pointer; }
    .bz-frame { width: 100%; height: calc(100% - 44px); border: 0; display: block; background: #fff; }
    .bz-fallback { position: fixed; inset: 0; display:none; align-items:center; justify-content:center; color:#fff; padding:24px; text-align:center; }
    .bz-fallback a { color: #fff; text-decoration: underline; }
  </style>
</head>
<body>
  <div class="bz-backdrop" id="bz_backdrop">
    <div class="bz-modal">
      <div class="bz-topbar">
        <div class="title">Paiement sécurisé</div>
        <button class="bz-close" type="button" id="bz_close">Fermer</button>
      </div>
      <iframe class="bz-frame" id="bz_iframe" src="<?php echo $iframe_src; ?>" allow="payment *; fullscreen *" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>

  <div class="bz-fallback" id="bz_fallback">
    <div>
      <div style="font-size:18px; margin-bottom:8px;">Fenêtre de paiement fermée</div>
      <div style="opacity:0.85; margin-bottom:18px;">Vous pouvez réessayer ou revenir à la boutique.</div>
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>">Retour</a>
      </div>
    </div>
  </div>

  <script>
    (function(){
      var closeBtn = document.getElementById('bz_close');
      var backdrop = document.getElementById('bz_backdrop');
      var fallback = document.getElementById('bz_fallback');

      function closeModal(){
        backdrop.style.display = 'none';
        fallback.style.display = 'flex';
      }

      closeBtn.addEventListener('click', function(){ closeModal(); });

      document.addEventListener('keydown', function(e){
        if (e && e.key === 'Escape') closeModal();
      });
    })();
  </script>
</body>
</html>
<?php
}

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            if (!function_exists('wc_get_order')) {
                return new WP_REST_Response(array('error' => 'woocommerce_unavailable'), 500);
            }

            $order_id  = absint($request->get_param('order_id'));
            $order_key = sanitize_text_field((string) $request->get_param('order_key'));

            $order = wc_get_order($order_id);
            if (!$order || !$order_key || !hash_equals($order->get_order_key(), $order_key)) {
                return new WP_REST_Response(array('paid' => false, 'valid' => false), 200);
            }

            $status = $order->get_status();
            $paid = in_array($status, array('processing', 'completed'), true);

            return new WP_REST_Response(array(
                'valid'       => true,
                'paid'        => $paid,
                'status'      => $status,
                'thankyou_url' => $paid ? $order->get_checkout_order_received_url() : null,
            ), 200);
        },
    ));
});

function bonzai_rewrite_location($location) {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base . '/');

    $location = (string) $location;

    // Keep the current proxied Bonzai host in redirects so all subsequent requests keep targeting the right subdomain.
    $current_host = 'www.bonzai.pro';
    if (isset($_GET['bh'])) {
        $candidate = strtolower(sanitize_text_field((string) $_GET['bh']));
        // Allow bonzai.pro and any subdomain (e.g. pay.bonzai.pro). Note: '.bonzai.pro' is 11 chars.
        $is_bonzai = ($candidate === 'bonzai.pro') || (substr($candidate, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $current_host = $candidate;
        }
    }

    // Absolute URL to a Bonzai domain: rewrite to our proxy and preserve that host as bh.
    $parts = wp_parse_url($location);
    if (is_array($parts) && !empty($parts['host'])) {
        $h = strtolower((string) $parts['host']);
        // Allow bonzai.pro and any subdomain.
        $is_bonzai = ($h === 'bonzai.pro') || (substr($h, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $p = isset($parts['path']) ? ltrim((string) $parts['path'], '/') : '';
            $q = isset($parts['query']) && $parts['query'] !== '' ? ('?' . (string) $parts['query']) : '';
            $u = $proxy_root . $p . $q;
            return add_query_arg('bh', $h, $u);
        }
    }

    // Relative redirects: keep them inside our proxy and preserve current bh.
    if (strpos($location, '/') === 0) {
        $u = $proxy_root . ltrim($location, '/');
        return add_query_arg('bh', $current_host, $u);
    }

    return $location;
}

function bonzai_rewrite_set_cookie($cookie_line) {
    $cookie_line = (string) $cookie_line;

    // Drop Domain attribute so cookie becomes first party
    $cookie_line = preg_replace('/;\s*Domain=[^;]+/i', '', $cookie_line);

    // Ensure Path is root
    if (stripos($cookie_line, '; path=') === false) {
        $cookie_line .= '; Path=/';
    }

    // Ensure SameSite for modern browsers
    if (stripos($cookie_line, 'samesite=') === false) {
        $cookie_line .= '; SameSite=Lax';
    }

    return $cookie_line;
}

function bonzai_rewrite_body_urls($body, $bonzai_host = 'www.bonzai.pro') {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base);

    // Rewrite any Bonzai absolute URL (any subdomain) to our proxy, while preserving the originating host via bh.
    $body = preg_replace_callback(
        '#https://([a-z0-9.-]*bonzai\.pro)(/[^\"\'\s<]*)?#i',
        function ($m) use ($proxy_root) {
            $host = strtolower($m[1]);
            $path = isset($m[2]) && $m[2] !== '' ? $m[2] : '/';
            $u = $proxy_root . $path;
            return add_query_arg('bh', $host, $u);
        },
        $body
    );

    // Rewrite absolute root paths in common attributes
    $body = preg_replace_callback('/\b(href|src|action)=([\"\'])\/(?!\/)([^\"\']*)\2/i', function($m) use ($proxy_root, $bonzai_host) {
        $u = $proxy_root . '/' . $m[3];
        $u = add_query_arg('bh', $bonzai_host, $u);
        return $m[1] . '=' . $m[2] . $u . $m[2];
    }, $body);

    return $body;
}

function getallheaders_safe() {
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        if (is_array($h)) return $h;
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
        if (strpos($name, 'HTTP_') === 0) {
            $key = str_replace('_', '-', substr($name, 5));
            $headers[$key] = $value;
        }
    }
    return $headers;
}


add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});


add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return isset($gws['bonzai']) ? $gws['bonzai'] : null;
}

function bonzai_verify_token(WP_REST_Request $request, $gateway) {
    $configured = trim($gateway->get_option('webhook_token'));
    if ($configured === '') return false;
    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

function bonzai_find_wc_order_from_payload(array $evt) {
    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    $email = $evt['user']['email'] ?? '';
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 1,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    return null;
}

function bonzai_handle_webhook(WP_REST_Request $request) {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return new WP_REST_Response(array('ok'=>false,'msg'=>'gateway not loaded'), 503);

    if (!bonzai_verify_token($request, $gw)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);
    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning('[Bonzai] Webhook received without wc_order_id: ' . $raw, array('source'=>'bonzai_gateway'));
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    switch ($type) {
        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted -> payment confirmed.');
            } else {
                if ($order->get_status() !== 'completed') {
                    $order->update_status('completed', 'Bonzai: product_access_granted -> completed.');
                }
            }
            break;

        case 'product_access_revoked':
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);


add_action('woocommerce_product_options_general_product_data', 'bonzai_product_fields');

function bonzai_product_fields() {
    echo '<div class="options_group">';

    woocommerce_wp_select(array(
        'id'          => 'bonzai_is_vat_incl',
        'label'       => 'Bonzai VAT handling',
        'description' => 'Override Bonzai VAT handling for this product. If Inherit, gateway default is used.',
        'desc_tip'    => true,
        'options'     => array(
            ''     => 'Inherit from gateway setting',
            'yes'  => 'Amount includes VAT',
            'no'   => 'Amount excludes VAT',
        ),
    ));

    woocommerce_wp_select(array(
        'id'          => 'bonzai_payment_mode',
        'label'       => 'Bonzai payment mode',
        'description' => 'Choose how this product should be charged in Bonzai.',
        'desc_tip'    => true,
        'options'     => array(
            ''                     => 'Inherit or auto detect',
            'one_off'              => 'One off payment',
            'subscription_monthly' => 'Subscription monthly',
            'subscription_yearly'  => 'Subscription yearly',
        ),
    ));

    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'bonzai_save_product_fields');

function bonzai_save_product_fields($post_id) {
    if (isset($_POST['bonzai_is_vat_incl'])) {
        $value = wc_clean(wp_unslash($_POST['bonzai_is_vat_incl']));
        if (!in_array($value, array('', 'yes', 'no'), true)) $value = '';
        update_post_meta($post_id, 'bonzai_is_vat_incl', $value);
    }

    if (isset($_POST['bonzai_payment_mode'])) {
        $mode = wc_clean(wp_unslash($_POST['bonzai_payment_mode']));
        if (!in_array($mode, array('', 'one_off', 'subscription_monthly', 'subscription_yearly'), true)) $mode = '';
        update_post_meta($post_id, 'bonzai_payment_mode', $mode);
    }
}


function bonzai_api_retrieve_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_no_order_id', 'Missing Bonzai order_id');
    }

    $api_token = trim($gateway->api_token);
    if ($api_token === '') {
        return new WP_Error('bonzai_no_token', 'Missing Bonzai API token');
    }

    $url = 'https://www.bonzai.pro/api/v1/orders/' . rawurlencode($bonzai_order_id);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ),
        'timeout' => max(5, (int) $gateway->timeout),
    ));

    if (is_wp_error($response)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order error: ' . $response->get_error_message());
        }
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body_txt = (string) wp_remote_retrieve_body($response);
    $body = json_decode($body_txt, true);

    if ($code !== 200 || !is_array($body)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order HTTP ' . $code . ' body=' . $body_txt);
        }
        return new WP_Error('bonzai_bad_response', 'Unexpected response from Bonzai retrieve order', array(
            'code' => $code,
            'body' => $body_txt,
        ));
    }

    return $body;
}

function bonzai_store_last_retrieve_payload(WC_Order $order, array $api_order) {
    // Store retrieve info using order meta API for HPOS compatibility.
    $order->update_meta_data('_bonzai_last_retrieve_payload', wp_json_encode($api_order));
    $order->update_meta_data('_bonzai_last_retrieve_at', current_time('mysql'));
    $order->save();
}

function bonzai_extract_timeline(array $payload) {
    $events = array();

    // 1) If there is a real timeline field, use it (future-proof)
    if (!empty($payload['timeline']) && is_array($payload['timeline'])) {
        foreach ($payload['timeline'] as $ev) {
            if (!is_array($ev)) continue;

            $date = $ev['date'] ?? ($ev['created_at'] ?? '');
            if (!$date) continue;

            $events[] = array(
                'date'    => (string) $date,
                'type'    => (string) ($ev['type'] ?? ($ev['event'] ?? 'event')),
                'message' => (string) ($ev['message'] ?? ($ev['label'] ?? '')),
            );
        }
    }

    // 2) Fallback: build timeline from accesses[]
    if (empty($events) && !empty($payload['accesses']) && is_array($payload['accesses'])) {
        foreach ($payload['accesses'] as $a) {
            if (!is_array($a)) continue;

            $id = isset($a['id']) ? (string) $a['id'] : '';

            if (!empty($a['created_at'])) {
                $events[] = array(
                    'date'    => (string) $a['created_at'],
                    'type'    => 'access',
                    'message' => 'Access created' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['updated_at']) && ($a['updated_at'] !== ($a['created_at'] ?? null))) {
                $events[] = array(
                    'date'    => (string) $a['updated_at'],
                    'type'    => 'access',
                    'message' => 'Access updated' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['deleted_at'])) {
                $events[] = array(
                    'date'    => (string) $a['deleted_at'],
                    'type'    => 'access',
                    'message' => 'Access deleted' . ($id ? " (#$id)" : ''),
                );
            }
        }
    }

    // Sort ASC by date
    usort($events, function($x, $y){
        $dx = strtotime((string)($x['date'] ?? '')) ?: 0;
        $dy = strtotime((string)($y['date'] ?? '')) ?: 0;
        return $dx <=> $dy;
    });

    return $events;
}

function bonzai_render_history_html(array $payload, $bonzai_order_id = '') {
    $has_access = array_key_exists('has_access', $payload) ? ($payload['has_access'] ? 'true' : 'false') : 'null';
    $intent_status = $payload['intent_status'] ?? ($payload['order']['intent_status'] ?? null);
    $subscription_status = $payload['subscription_status'] ?? ($payload['order']['subscription_status'] ?? null);

    $timeline = bonzai_extract_timeline($payload);

    ob_start();
    ?>
    <div style="padding:12px;">
        <div style="margin-bottom:10px;">
            <div><strong>Bonzai order_id:</strong> <?php echo esc_html($bonzai_order_id ?: ''); ?></div>
            <div><strong>has_access:</strong> <?php echo esc_html($has_access); ?></div>
            <div><strong>intent_status:</strong> <?php echo esc_html($intent_status !== null ? (string) $intent_status : 'null'); ?></div>
            <div><strong>subscription_status:</strong> <?php echo esc_html($subscription_status !== null ? (string) $subscription_status : 'null'); ?></div>
        </div>

        <h3 style="margin:0 0 8px 0;">Timeline</h3>

        <?php if (empty($timeline)) : ?>
            <p>No timeline data found in this Retrieve payload. Raw payload is available below.</p>
        <?php else : ?>
            <table class="widefat striped" style="margin-top:8px;">
                <thead>
                    <tr>
                        <th style="width:180px;">Date</th>
                        <th style="width:220px;">Type</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($timeline as $evt) : ?>
                    <tr>
                        <td><?php echo esc_html($evt['date']); ?></td>
                        <td><?php echo esc_html($evt['type']); ?></td>
                        <td><?php echo esc_html($evt['message']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <details style="margin-top:10px;">
            <summary>Raw payload</summary>
            <pre style="white-space:pre-wrap;"><?php echo esc_html(wp_json_encode($payload, JSON_PRETTY_PRINT)); ?></pre>
        </details>
    </div>
    <?php
    return ob_get_clean();
}

function bonzai_sync_wc_order_with_bonzai(WC_Order $order, array $api_order) {

    // Support plusieurs formats de réponse possibles
    $has_access = null;
    if (array_key_exists('has_access', $api_order)) {
        $has_access = (bool) $api_order['has_access'];
    } elseif (isset($api_order['order']) && is_array($api_order['order']) && array_key_exists('has_access', $api_order['order'])) {
        $has_access = (bool) $api_order['order']['has_access'];
    }

    $intent_status = $api_order['intent_status'] ?? ($api_order['order']['intent_status'] ?? null);
    $subscription_status = $api_order['subscription_status'] ?? ($api_order['order']['subscription_status'] ?? null);

    // Normalisation simple
    $intent_status_norm = is_string($intent_status) ? strtolower(trim($intent_status)) : null;
    $subscription_status_norm = is_string($subscription_status) ? strtolower(trim($subscription_status)) : null;

    $order->add_order_note(sprintf(
        'Bonzai sync: intent_status=%s, subscription_status=%s, has_access=%s',
        $intent_status_norm !== null ? $intent_status_norm : 'null',
        $subscription_status_norm !== null ? $subscription_status_norm : 'null',
        $has_access === null ? 'null' : ($has_access ? 'true' : 'false')
    ));

    // Heuristique paiement complété
    $payment_completed =
        ($intent_status_norm === 'completed')
        || ($intent_status_norm === 'complete')
        || ($intent_status_norm === 'succeeded')
        || ($intent_status_norm === 'paid');

    // 1) Access actif: on force completed même si c'était refunded
    if ($has_access === true) {
        if ($order->get_status() !== 'completed') {
            // payment_complete peut être bloquant selon l'état, donc on force le statut
            $order->update_status('completed', 'Bonzai sync: access active.');
        }
        return;
    }

    // 2) Access inactif
    if ($has_access === false) {

        // Si paiement jamais complété: on évite de mettre refunded sur un test non payé
        if (!$payment_completed && !$order->is_paid()) {
            // Laisser tel quel, ou marquer cancelled si vous voulez
            $order->add_order_note('Bonzai sync: access inactive and payment not completed. No status change.');
            return;
        }

        // Si paiement a existé: refunded
        if ($order->get_status() !== 'cancelled') {
            $order->update_status('cancelled', 'Bonzai sync: access inactive after payment.');
        }
        return;
    }

    // 3) Cas indéterminé: on ne touche pas au statut
    $order->add_order_note('Bonzai sync: unable to determine access state. No status change.');
}


add_action('init', 'bonzai_register_cron_event');

function bonzai_register_cron_event() {
    if (!wp_next_scheduled('bonzai_cron_order_sync')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'bonzai_cron_order_sync');
    }
}

add_action('bonzai_cron_order_sync', 'bonzai_run_cron_order_sync');

function bonzai_run_cron_order_sync() {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return;

    $mode = $gw->order_sync_enabled ?? 'no';
    if ($mode === 'no') return;

    $hour_config = isset($gw->order_sync_hour) ? (int) $gw->order_sync_hour : 3;
    $day_config  = isset($gw->order_sync_day) ? strtolower($gw->order_sync_day) : 'monday';

    $now      = current_datetime();
    $hour_now = (int) $now->format('G');
    $day_now  = strtolower($now->format('l'));

    if ($hour_now !== $hour_config) return;

    if ($mode === 'daily') {
        $today = $now->format('Y-m-d');
        $last  = get_option('bonzai_sync_last_daily');
        if ($last === $today) return;
        update_option('bonzai_sync_last_daily', $today);
    } elseif ($mode === 'weekly') {
        if ($day_now !== $day_config) return;
        $yearweek = $now->format('o-W');
        $last     = get_option('bonzai_sync_last_weekly');
        if ($last === $yearweek) return;
        update_option('bonzai_sync_last_weekly', $yearweek);
    } else {
        return;
    }

    if (!empty($gw->debug)) {
        $gw->log('Starting automatic Bonzai order sync via cron.');
    }

    $orders = wc_get_orders(array(
        'limit'        => -1,
        'meta_key'     => '_bonzai_order_id',
        'meta_compare' => 'EXISTS',
        'status'       => array('pending','on-hold','processing','completed','refunded','cancelled','failed'),
        'return'       => 'objects',
    ));

    if (empty($orders)) {
        if (!empty($gw->debug)) $gw->log('Automatic sync: no orders with Bonzai order_id found.');
        return;
    }

    foreach ($orders as $order) {
        $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
        if (!$bonzai_order_id) continue;

        $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
        if (is_wp_error($api_order)) {
            if (!empty($gw->debug)) {
                $gw->log('Automatic sync error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
            }
            $order->add_order_note('Bonzai automatic sync error: ' . $api_order->get_error_message());
            continue;
        }

        bonzai_store_last_retrieve_payload($order, $api_order);
        bonzai_sync_wc_order_with_bonzai($order, $api_order);
    }

    if (!empty($gw->debug)) {
        $gw->log('Automatic Bonzai order sync finished.');
    }
}


add_action('admin_menu', 'bonzai_register_admin_page');

function bonzai_register_admin_page() {
    add_submenu_page(
        'woocommerce',
        'Bonzai Order Sync',
        'Bonzai Order Sync',
        'manage_woocommerce',
        'bonzai_order_sync',
        'bonzai_render_order_sync_page'
    );
}

function bonzai_render_order_sync_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to access this page.');
    }

    $gw = bonzai_get_gateway_instance();
    if (!$gw) {
        echo '<div class="notice notice-error"><p>Bonzai gateway is not loaded.</p></div>';
        return;
    }

    $orders       = array();
    $search_email = '';
    $message      = '';
    $message_type = 'info';

    if (isset($_POST['bonzai_search_email']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'search') {
        check_admin_referer('bonzai_search_orders');
        $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
            if (empty($orders)) {
                $message = 'No orders found for this email.';
                $message_type = 'warning';
            }
        } else {
            $message = 'Please enter a valid email address.';
            $message_type = 'error';
        }
    }

    if (isset($_POST['bonzai_sync_order_id']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'sync') {
        check_admin_referer('bonzai_sync_single_order');

        $order_id = absint($_POST['bonzai_sync_order_id']);
        $search_email = isset($_POST['bonzai_search_email']) ? sanitize_email(wp_unslash($_POST['bonzai_search_email'])) : '';
        $order = wc_get_order($order_id);

        if ($order) {
            $o = wc_get_order($order_id);
            $bonzai_order_id = $o ? $o->get_meta('_bonzai_order_id', true) : '';
            if (!$bonzai_order_id) {
                $message = 'This order does not have a Bonzai order_id. It cannot be synced.';
                $message_type = 'error';
            } else {
                $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
                if (is_wp_error($api_order)) {
                    $message = 'Error while retrieving order from Bonzai: ' . esc_html($api_order->get_error_message());
                    $message_type = 'error';
                    $order->add_order_note('Bonzai manual sync error: ' . $api_order->get_error_message());
                } else {
                    bonzai_store_last_retrieve_payload($order, $api_order);
                    bonzai_sync_wc_order_with_bonzai($order, $api_order);
                    $message = 'Bonzai order synced successfully for WooCommerce order #' . $order_id . '.';
                    $message_type = 'success';
                }
            }
        } else {
            $message = 'Invalid WooCommerce order ID.';
            $message_type = 'error';
        }

        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
        }
    }

    $notice_class = 'notice notice-info';
    if ($message_type === 'success') $notice_class = 'notice notice-success';
    if ($message_type === 'warning') $notice_class = 'notice notice-warning';
    if ($message_type === 'error')   $notice_class = 'notice notice-error';

    echo '<div class="wrap"><h1>Bonzai Order Sync</h1>';

    if ($message) {
        echo '<div class="' . esc_attr($notice_class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    echo '<h2>Search orders by customer email</h2>';
    echo '<form method="post">';
    wp_nonce_field('bonzai_search_orders');
    echo '<input type="hidden" name="bonzai_action" value="search" />';
    echo '<p><label for="bonzai_search_email">Customer email:</label> ';
    echo '<input type="email" id="bonzai_search_email" name="bonzai_search_email" value="' . esc_attr($search_email) . '" size="40" />';
    submit_button('Search orders', 'secondary', 'submit', false);
    echo '</p></form>';

    if (!empty($orders)) {
        echo '<h2>Orders for ' . esc_html($search_email) . '</h2>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total</th><th>Bonzai order_id</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $order) {
            $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
            $payload_exists = (bool) $order->get_meta('_bonzai_last_retrieve_payload', true);

            echo '<tr>';
            echo '<td><a href="' . esc_url(get_edit_post_link($order->get_id())) . '">#' . esc_html($order->get_id()) . '</a></td>';
            echo '<td>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : '') . '</td>';
            echo '<td>' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            $total_html = wp_kses_post(
                wc_price($order->get_total(), array('currency' => $order->get_currency()))
            );

            if ($order->has_status('refunded')) {
                $zero_html = wp_kses_post(
                    wc_price(0, array('currency' => $order->get_currency()))
                );

                echo '<td>'
                    . '<del>' . $total_html . '</del> '
                    . '<ins>' . $zero_html . '</ins>'
                    . '</td>';
            } else {
                echo '<td>' . $total_html . '</td>';
            }
            echo '<td>' . esc_html($bonzai_order_id ? $bonzai_order_id : '') . '</td>';

            echo '<td>';
            if ($bonzai_order_id) {
                echo '<form method="post" style="display:inline-block; margin-right:8px;">';
                wp_nonce_field('bonzai_sync_single_order');
                echo '<input type="hidden" name="bonzai_action" value="sync" />';
                echo '<input type="hidden" name="bonzai_search_email" value="' . esc_attr($search_email) . '" />';
                echo '<input type="hidden" name="bonzai_sync_order_id" value="' . esc_attr($order->get_id()) . '" />';
                submit_button('Sync with Bonzai', 'primary', 'submit', false);
                echo '</form>';

                if ($payload_exists) {
                    echo '<button type="button" class="button bonzai_history_btn" data_order_id="' . esc_attr($order->get_id()) . '">History</button>';
                } else {
                    echo '<span style="margin-left:6px; color:#666;">No history yet</span>';
                }

            } else {
                echo 'No Bonzai order_id';
            }
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    $nonce = wp_create_nonce('bonzai_history_nonce');
    $ajax_url = admin_url('admin-ajax.php');

    echo '
<div id="bonzai_history_modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:99999;">
  <div style="background:#fff; width:90%; max-width:1100px; margin:40px auto; border-radius:6px; overflow:hidden;">
    <div style="padding:12px 16px; border-bottom:1px solid #ddd; display:flex; justify-content:space-between; align-items:center;">
      <div style="font-size:16px; font-weight:600;">Bonzai Retrieve History</div>
      <button type="button" class="button" id="bonzai_history_close">Close</button>
    </div>
    <div id="bonzai_history_meta" style="padding:8px 16px; border-bottom:1px solid #eee; color:#444;"></div>
    <div id="bonzai_history_content" style="max-height:70vh; overflow:auto;"></div>
  </div>
</div>

<script type="text/javascript">
(function($){
  function openModal(){ $("#bonzai_history_modal").show(); }
  function closeModal(){
    $("#bonzai_history_modal").hide();
    $("#bonzai_history_content").html("");
    $("#bonzai_history_meta").text("");
  }

  $(document).on("click", "#bonzai_history_close", function(){ closeModal(); });
  $(document).on("click", "#bonzai_history_modal", function(e){
    if (e.target === this) closeModal();
  });

  $(document).on("click", ".bonzai_history_btn", function(){
    var orderId = $(this).attr("data_order_id");
    $("#bonzai_history_content").html("<div style=\'padding:12px;\'>Loading...</div>");
    $("#bonzai_history_meta").text("");
    openModal();

    $.post("' . esc_js($ajax_url) . '", {
      action: "bonzai_get_order_history",
      nonce: "' . esc_js($nonce) . '",
      order_id: orderId
    })
    .done(function(resp){
      if (!resp || !resp.success) {
        var msg = (resp && resp.data && resp.data.message) ? resp.data.message : "Unknown error";
        $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>" + msg + "</div>");
        return;
      }
      if (resp.data && resp.data.last_retrieve_at) {
        $("#bonzai_history_meta").text("Last retrieve at: " + resp.data.last_retrieve_at);
      }
      $("#bonzai_history_content").html(resp.data.html || "<div style=\'padding:12px;\'>No data</div>");
    })
    .fail(function(){
      $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>Request failed</div>");
    });
  });
})(jQuery);
</script>
';

    echo '</div>';
}

add_action('wp_ajax_bonzai_get_order_history', 'bonzai_ajax_get_order_history');

function bonzai_ajax_get_order_history() {
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    check_ajax_referer('bonzai_history_nonce', 'nonce');

    $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
    if (!$order_id) {
        wp_send_json_error(array('message' => 'Missing order_id'), 400);
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(array('message' => 'Invalid WooCommerce order'), 404);
    }

    $payload_json = $order->get_meta('_bonzai_last_retrieve_payload', true);
    if (!$payload_json) {
        wp_send_json_error(array('message' => 'No stored Retrieve payload for this order. Run Sync first.'), 404);
    }

    $payload = json_decode($payload_json, true);
    if (!is_array($payload)) {
        wp_send_json_error(array('message' => 'Stored payload is invalid JSON'), 500);
    }

    $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
    $html = bonzai_render_history_html($payload, $bonzai_order_id);

    $last_at = (string) $order->get_meta('_bonzai_last_retrieve_at', true);

    wp_send_json_success(array(
        'html' => $html,
        'last_retrieve_at' => $last_at,
    ));
}

/**
 * Validate and parse a Bonzai checkout URL.
 *
 * Security goal: avoid turning the popup endpoint into an open redirect/iframe loader.
 * We only allow HTTPS URLs to bonzai.pro and its subdomains.
 *
 * @param string $url
 * @return array|null Parsed URL parts when valid, otherwise null.
 */
function bonzai_extract_bonzai_target($url) {
    $url = trim((string) $url);
    if ($url === '') {
        return null;
    }

    // Only allow absolute HTTPS URLs.
    $parts = wp_parse_url($url);
    if (!is_array($parts)) {
        return null;
    }

    $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
    if ($scheme !== 'https') {
        return null;
    }

    $host = isset($parts['host']) ? strtolower($parts['host']) : '';
    if ($host === '') {
        return null;
    }

    // Allow bonzai.pro and any subdomain *.bonzai.pro (including pay.bonzai.pro).
    if ($host === 'bonzai.pro' || $host === 'www.bonzai.pro') {
        return $parts;
    }

    // Note: '.bonzai.pro' length is 11.
    if (substr($host, -11) === '.bonzai.pro') {
        return $parts;
    }

    return null;
}
