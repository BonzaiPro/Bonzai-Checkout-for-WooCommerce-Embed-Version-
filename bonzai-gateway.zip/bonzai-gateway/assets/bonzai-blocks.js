/* global wc, wp */
(function () {
  'use strict';

  if (!window.wc || !wc.wcBlocksRegistry || !wc.wcSettings || !window.wp || !wp.element) {
    return;
  }

  var el = wp.element.createElement;
  var useEffect = wp.element.useEffect;
  var useMemo = wp.element.useMemo;
  var useRef = wp.element.useRef;
  var useState = wp.element.useState;
  var decodeEntities = (wp.htmlEntities && wp.htmlEntities.decodeEntities) ? wp.htmlEntities.decodeEntities : function (s) { return s; };

  var settings = wc.wcSettings.getSetting('bonzai_data', {});
  var labelText = decodeEntities(settings.title || 'Bonzai');

  function isValidEmail(email) {
    return !!email && /.+@.+\..+/.test(String(email));
  }

  function buildFingerprint(data) {
    // Best-effort fingerprint for deduping within one page view.
    return [data.email, data.first, data.last, data.postcode, data.total, data.currency].join('|');
  }

  function selectCartStore() {
    try {
      if (window.wp && wp.data && wp.data.select) {
        return wp.data.select('wc/store/cart');
      }
    } catch (e) {}
    return null;
  }

  function getCustomerDataFromStore() {
    var store = selectCartStore();
    if (!store || !store.getCustomerData) return {};
    try {
      return store.getCustomerData() || {};
    } catch (e) {}
    return {};
  }

  function getCartDataFromStore() {
    var store = selectCartStore();
    if (!store || !store.getCartData) return {};
    try {
      return store.getCartData() || {};
    } catch (e) {}
    return {};
  }

  function getEmailFromAny(props) {
    // Preferred source: Cart store customer data.
    var customer = getCustomerDataFromStore();
    var b = customer.billingAddress || {};
    if (b.email) return b.email;

    // Fallbacks: some integrations pass billing in props.
    var billing = (props && props.billing) ? props.billing : {};
    var addr = billing.billingAddress || {};
    return addr.email || billing.email || '';
  }

  function getBillingAddressFromAny(props) {
    var customer = getCustomerDataFromStore();
    if (customer.billingAddress) return customer.billingAddress;

    var billing = (props && props.billing) ? props.billing : {};
    return billing.billingAddress || {};
  }

  function findTermsCheckbox() {
    try {
      return document.querySelector('#wc-block-checkout__terms, input[name="terms"], #terms, input[id*="terms"][type="checkbox"]');
    } catch (e) {}
    return null;
  }

  function termsAccepted() {
    var el = findTermsCheckbox();
    if (!el) return true;
    return !!el.checked;
  }

  function stateFieldIsPresent() {
    try {
      // Blocks uses various ids depending on field configuration.
      var el = document.querySelector('select[id*="billing-state"], input[id*="billing-state"], select[name="billing_state"], input[name="billing_state"], select[id*="billing_state"], input[id*="billing_state"]');
      if (!el) return false;
      // Ignore hidden/disabled.
      if (el.disabled) return false;
      var style = window.getComputedStyle(el);
      return style && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
    } catch (e) {}
    return false;
  }

  function getTotalsFromAny(props) {
    // Preferred: cart store data.
    var cart = getCartDataFromStore();
    var totals = cart.totals || {};
    var total = totals.total_price || totals.total || '';
    var currency = totals.currency_code || totals.currency || '';

    // Fallbacks: some props include totals/currency.
    var billing = (props && props.billing) ? props.billing : {};
    if (!total && billing.cartTotal && typeof billing.cartTotal.value !== 'undefined') {
      total = billing.cartTotal.value;
    }
    if (!currency && billing.currency && billing.currency.code) {
      currency = billing.currency.code;
    }
    return { total: total, currency: currency };
  }

  function Content(props) {
    var prepareUrl = settings.prepare_ajax || '';
    var restUrl = settings.rest || '';
    var restNonce = settings.nonce || '';
    var i18n = settings.i18n || {};

    var iframeRef = useRef(null);
    var pollRef = useRef(null);
    var lastFpRef = useRef('');
    var lastOrderRef = useRef({ id: 0, key: '' });

    var _useState = useState('idle');
    var state = _useState[0];
    var setState = _useState[1];
    var _useState2 = useState('');
    var errorMsg = _useState2[0];
    var setErrorMsg = _useState2[1];
    var _useState3 = useState('');
    var embedUrl = _useState3[0];
    var setEmbedUrl = _useState3[1];

    var active = (props && props.activePaymentMethod) ? (props.activePaymentMethod === 'bonzai') : true;

    var snap = useMemo(function () {
      var email = getEmailFromAny(props);
      var addr = getBillingAddressFromAny(props);
      var totals = getTotalsFromAny(props);
      return {
        email: String(email || '').trim(),
        first: String(addr.first_name || addr.firstName || '').trim(),
        last: String(addr.last_name || addr.lastName || '').trim(),
        postcode: String(addr.postcode || addr.postal_code || '').trim(),
        address1: String(addr.address_1 || addr.address1 || '').trim(),
        city: String(addr.city || '').trim(),
        country: String(addr.country || '').trim(),
        state: String(addr.state || '').trim(),
        terms: termsAccepted(),
        termsExists: !!findTermsCheckbox(),
        stateRequired: stateFieldIsPresent(),
        total: totals.total,
        currency: totals.currency
      };
    }, [props]);

    // Hide the default Blocks "Place order" button when Bonzai is selected.
    useEffect(function () {
      try {
        var btn = document.querySelector('.wc-block-components-checkout-place-order-button');
        if (btn) {
          btn.style.display = active ? 'none' : '';
          btn.disabled = !!active;
        }
      } catch (e) {}
    }, [active]);

    function stopPolling() {
      if (pollRef.current) {
        window.clearInterval(pollRef.current);
        pollRef.current = null;
      }
    }

    function startPolling(orderId, orderKey) {
      if (!restUrl || !orderId || !orderKey) return;
      if (pollRef.current) return;

      pollRef.current = window.setInterval(function () {
        // Fallback: if the Bonzai iframe navigates back to a same-origin URL (e.g. WooCommerce thank-you),
        // break out of the embed immediately. This covers cases where Bonzai completes payment and loads
        // the merchant thank-you page inside the iframe while the Woo order status is still pending.
        try {
          if (iframeRef.current && iframeRef.current.contentWindow && iframeRef.current.contentWindow.location) {
            var href = String(iframeRef.current.contentWindow.location.href || '');
            if (href && href.indexOf(window.location.origin) === 0) {
              stopPolling();
              window.location.href = href;
              return;
            }
          }
        } catch (e) {
          // Cross-origin while still on Bonzai; ignore.
        }

        var url = restUrl + '?order_id=' + encodeURIComponent(orderId) + '&order_key=' + encodeURIComponent(orderKey);
        fetch(url, {
          method: 'GET',
          credentials: 'same-origin',
          headers: restNonce ? { 'X-WP-Nonce': restNonce } : {}
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (!res) return;

            var paid = false;
            var thankyou = '';
            if (res.ok) {
              paid = !!res.paid;
              thankyou = res.thankyou || '';
            } else if (typeof res.valid !== 'undefined') {
              paid = !!res.paid;
              thankyou = res.thankyou_url || '';
            }

            if (paid && thankyou) {
              stopPolling();
              window.location.href = thankyou;
            }
          })
          .catch(function () { /* silent */ });
      }, 2000);
    }

    function shouldForceNewOnThisLoad() {
      // New session on refresh: use sessionStorage flag (one per page view).
      try {
        var k = 'bonzai_force_new_once';
        if (window.sessionStorage && !sessionStorage.getItem(k)) {
          sessionStorage.setItem(k, '1');
          return true;
        }
      } catch (e) {}
      return false;
    }

    function prepare() {
      if (!active) return;
      if (!prepareUrl) {
        setState('error');
        setErrorMsg('Configuration Bonzai invalide (prepare endpoint manquant).');
        return;
      }

      if (!isValidEmail(snap.email)) {
        setState('idle');
        setErrorMsg('');
        setEmbedUrl('');
        stopPolling();
        return;
      }

      // Require identity + address before showing payment.
      // State is only required when the store actually shows the state/region field.
      // Terms are only required when the store shows a terms checkbox.
      if (!snap.first || !snap.last || !snap.address1 || !snap.postcode || !snap.city || !snap.country || (snap.stateRequired && !snap.state) || (snap.termsExists && !snap.terms)) {
        setState('error');
        var baseMsg = i18n.requirements_base || 'To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code).';
        var termsMsg = i18n.requirements_with_terms || (baseMsg + ' Please accept the terms and conditions to proceed.');
        setErrorMsg(snap.termsExists || settings.terms_required ? termsMsg : baseMsg);
        setEmbedUrl('');
        stopPolling();
        return;
      }

      var fp = buildFingerprint(snap);
      if (lastFpRef.current && fp === lastFpRef.current && embedUrl) {
        return;
      }

      setState('loading');
      setErrorMsg('');

      var body = new URLSearchParams();
      body.append('force_new', shouldForceNewOnThisLoad() ? '1' : '0');
      // Blocks: send identity explicitly (no classic checkout form serialization available).
      body.append('billing_email', snap.email);
      body.append('billing_first_name', snap.first);
      body.append('billing_last_name', snap.last);
      body.append('billing_postcode', snap.postcode);
      body.append('billing_address_1', snap.address1);
      body.append('billing_city', snap.city);
      body.append('billing_country', snap.country);
      body.append('billing_state', snap.state);
      if (snap.termsExists || settings.terms_required) {
        body.append('terms', snap.terms ? '1' : '0');
      }
      // Keep compatibility with the server expecting checkout_data (optional).
      body.append('checkout_data', '');

      fetch(prepareUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString()
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res || !res.ok || !res.embed_url) {
            var msg = i18n.error || 'Unable to load payment. Please refresh and try again.';
            if (res && res.error === 'missing_email') {
              msg = i18n.missing_email || msg;
            }
            setState('error');
            setErrorMsg(msg);
            setEmbedUrl('');
            return;
          }

          lastFpRef.current = fp;
          lastOrderRef.current = { id: parseInt(res.order_id || 0, 10) || 0, key: String(res.order_key || '') };

          // Force reload even if the same URL is reused to avoid "Processing" stuck states.
          var url = String(res.embed_url);
          var sep = url.indexOf('#') === -1 ? '#' : '&';
          url = url + sep + 'r=' + Date.now();

          setEmbedUrl(url);
          setState('iframe_loading');
        })
        .catch(function () {
          setState('error');
          setErrorMsg(i18n.error || 'Unable to load payment. Please refresh and try again.');
          setEmbedUrl('');
        });
    }

    // Prepare when selected and when relevant billing data changes.
    useEffect(function () {
      if (!active) {
        stopPolling();
        return;
      }
      // Debounce a bit to avoid spamming while typing.
      var t = window.setTimeout(prepare, 650);
      return function () { window.clearTimeout(t); };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
      active,
      snap.email,
      snap.first,
      snap.last,
      snap.address1,
      snap.city,
      snap.country,
      snap.state,
      snap.postcode,
      snap.terms,
      snap.termsExists,
      snap.stateRequired
    ]);

    // Attach iframe load handler.
    useEffect(function () {
      var iframe = iframeRef.current;
      if (!iframe) return;

      function onLoad() {
        setState('ready');
        var o = lastOrderRef.current || { id: 0, key: '' };
        if (o.id && o.key) {
          startPolling(o.id, o.key);
        }
      }

      iframe.addEventListener('load', onLoad);
      return function () {
        iframe.removeEventListener('load', onLoad);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [embedUrl]);

    // Cleanup on unmount.
    useEffect(function () {
      return function () { stopPolling(); };
    }, []);

    // Render
    var desc = decodeEntities(settings.description || '');

    return el(
      'div',
      { id: 'bonzai-inline-container' },
      desc ? el('div', { style: { marginBottom: '8px' } }, desc) : null,
      state === 'loading' || state === 'iframe_loading'
        ? el('div', { id: 'bonzai-inline-loading' }, i18n.loading || 'Loading secure payment...')
        : null,
      state === 'error'
        ? el('div', { id: 'bonzai-inline-error' }, errorMsg)
        : null,
      embedUrl
        ? el('iframe', {
            id: 'bonzai-inline-iframe',
            ref: iframeRef,
            title: 'Bonzai secure payment',
            src: embedUrl,
            style: { display: state === 'ready' ? 'block' : 'none' },
            allow: 'payment *; clipboard-write *'
          })
        : null,
      // Helper text: Blocks still shows its own Place Order button; we guide the shopper.
      el('div', { style: { marginTop: '8px', fontSize: '13px', opacity: 0.85 } }, i18n.complete_payment || 'Complete payment above to finish your order.')
    );
  }

  function Label(props) {
    var PaymentMethodLabel = props && props.components ? props.components.PaymentMethodLabel : null;
    if (PaymentMethodLabel) {
      return el(PaymentMethodLabel, { text: labelText });
    }
    return el('span', null, labelText);
  }

  wc.wcBlocksRegistry.registerPaymentMethod({
    name: 'bonzai',
    paymentMethodId: 'bonzai',
    label: el(Label, null),
    ariaLabel: labelText,
    content: el(Content, null),
    edit: el('div', null, decodeEntities(settings.description || '')),
    canMakePayment: function () { return true; },
    supports: {
      features: settings.supports || ['products']
    },
    // Optional: update the CTA label for the block checkout.
    placeOrderButtonLabel: labelText
  });
})();
