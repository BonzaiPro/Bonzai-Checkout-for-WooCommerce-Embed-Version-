/* global jQuery, BONZAI_INLINE */
(function ($) {
  'use strict';

  var cfg = window.BONZAI_INLINE || {};
  var gatewayId = cfg.gateway_id || 'bonzai';
  var hashFlag = cfg.hash || '#bonzai-inline';
  var prepareUrl = cfg.prepare_ajax || null;
  var restUrl = cfg.rest || null;
  var restNonce = cfg.nonce || null;

  var prepareTimer = null;
  var pollTimer = null;
  var lastPreparedFp = null;
  var lastEmbedUrl = null;
  var lastOrder = { id: 0, key: '' };

  // IMPORTANT: force a brand new Bonzai session once per page load
  var forceNewNextPrepare = true;

  // i18n / UX copy (English as requested)
  var copy = (cfg && cfg.i18n) ? cfg.i18n : {};
  // Base requirements (terms may or may not exist depending on the store configuration)
  var requirementsBase = copy.requirements_base ||
    'To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, state, postal code).';
  var requirementsWithTerms = copy.requirements_with_terms ||
    (requirementsBase + ' If a terms & conditions checkbox is shown, you must accept it before proceeding.');

  var missingFieldsBase = copy.missing_fields_base ||
    'Please complete the required fields (First name, Last name, Email, street address, state, postal code) before accessing the payment form.';
  var missingFieldsWithTerms = copy.missing_fields_with_terms ||
    (missingFieldsBase + ' If a terms & conditions checkbox is shown, you must accept it to proceed.');

  // WooCommerce order button selectors (classic + blocks). We hide/disable them when Bonzai is selected.
  var orderButtonSelector = cfg.order_button_selector || '#place_order';
  var blocksOrderButtonSelector = '.wc-block-components-checkout-place-order-button, .wc-block-checkout__actions .wc-block-components-button';

  // Terms checkbox selectors (classic + blocks)
  var termsSelectors = [
    '#terms',
    'input[name="terms"]',
    '#wc-block-checkout__terms',
    'input[id*="terms"][type="checkbox"]'
  ].join(',');

  function getPaymentBox() {
    return $('.payment_box.payment_method_' + gatewayId).first();
  }

  function ensureContainer() {
    var box = getPaymentBox();
    if (!box.length) return null;

    var c = box.find('#bonzai-inline-container');
    if (c.length) return c;

    c = $('<div id="bonzai-inline-container" class="is-hidden"></div>');
    c.append('<div id="bonzai-inline-loading" style="display:none"></div>');
    c.append('<div id="bonzai-inline-error" style="display:none"></div>');
    c.append('<iframe id="bonzai-inline-iframe" title="Bonzai secure payment" allow="payment *; clipboard-write *" style="display:none;"></iframe>');
    box.append(c);

    bindIframeEvents();
    return c;
  }

  function showLoading(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-loading').show().text(msg || (copy.loading || 'Loading secure payment...'));
  }

  function showError(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-error').show().text(msg || (copy.error || 'Unable to load payment. Please refresh and try again.'));
  }

  function showIframe(url) {
    var c = ensureContainer();
    if (!c) return;

    var $iframe = c.find('#bonzai-inline-iframe');
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-error').hide().text('');

    // Always show loader until iframe really loads
    c.find('#bonzai-inline-loading').show().text(copy.loading || 'Loading secure payment...');

    // reset 3DS class; it will be re-evaluated on load
    $iframe.removeClass('is-3ds').hide();

    // Hard reload without breaking signature: only append a fragment
    var finalUrl = url;
    if (finalUrl.indexOf('#') === -1) {
      finalUrl += '#t=' + Date.now();
    } else {
      finalUrl += '&t=' + Date.now();
    }

    // Avoid reusing an already stuck iframe: always re-set src on prepare
    $iframe.attr('src', finalUrl);
  }

  function hideContainer() {
    var c = ensureContainer();
    if (!c) return;
    c.addClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-iframe').hide();
  }

  function isGatewaySelected() {
    return $('input[name="payment_method"]:checked').val() === gatewayId;
  }

  function getCheckoutForm() {
    var $form = $('form.checkout');
    if ($form.length) return $form;

    $form = $('form').filter(function () {
      return $(this).find('input[name="payment_method"]').length > 0;
    }).first();

    return $form.length ? $form : null;
  }

  function getFieldValue(selectors) {
    var val = '';
    selectors.split(',').forEach(function (sel) {
      sel = $.trim(sel);
      if (!sel) return;
      var $el = $(sel).first();
      if ($el.length && $el.val() !== undefined && $el.val() !== null) {
        val = String($el.val());
      }
    });
    return $.trim(val);
  }

  function getCheckoutSnapshot() {
    var email = getFieldValue('#billing_email, input[name="billing_email"]');
    var first = getFieldValue('#billing_first_name, input[name="billing_first_name"]');
    var last = getFieldValue('#billing_last_name, input[name="billing_last_name"]');
    var postcode = getFieldValue('#billing_postcode, input[name="billing_postcode"]');
    var address1 = getFieldValue('#billing_address_1, input[name="billing_address_1"]');
    var city = getFieldValue('#billing_city, input[name="billing_city"]');
    var country = getFieldValue('#billing_country, select[name="billing_country"], input[name="billing_country"]');
    var state = getFieldValue('#billing_state, select[name="billing_state"], input[name="billing_state"]');

    // State is not required in all countries. We approximate this by checking whether the field
    // is visible and marked as required by WooCommerce validation classes/attributes.
    var $stateEl = $('#billing_state, select[name="billing_state"], input[name="billing_state"]').first();
    var statePresent = $stateEl.length > 0;
    var stateVisible = statePresent && $stateEl.is(':visible') && !$stateEl.prop('disabled');
    var stateRequired = false;
    if (stateVisible) {
      var $stateRow = $stateEl.closest('.form-row');
      stateRequired = !!($stateEl.prop('required') || $stateEl.attr('aria-required') === 'true' || $stateRow.hasClass('validate-required') || $stateRow.hasClass('woocommerce-validated') && $stateRow.hasClass('validate-required'));
    }

    // Terms: only enforce if a terms checkbox exists on the page.
    var $terms = $(termsSelectors).first();
    var termsPresent = $terms.length > 0;
    var termsAccepted = termsPresent ? !!$terms.prop('checked') : true;

    return {
      email: email,
      first: first,
      last: last,
      postcode: postcode,
      address1: address1,
      city: city,
      country: country,
      state: state,
      stateRequired: stateRequired,
      termsPresent: termsPresent,
      termsAccepted: termsAccepted
    };
  }

  function isValidEmail(email) {
    return !!email && /.+@.+\..+/.test(email);
  }

  function computeFp(snapshot) {
    return [snapshot.email, snapshot.first, snapshot.last, snapshot.address1, snapshot.city, snapshot.country, snapshot.state, snapshot.postcode].join('|');
  }

  function hasRequiredFields(snap) {
    if (!snap) return false;
    if (!isValidEmail(snap.email)) return false;
    if (!snap.first || !snap.last) return false;
    if (!snap.address1 || !snap.city || !snap.country || !snap.postcode) return false;
    if (snap.stateRequired && !snap.state) return false;
    // Only enforce terms acceptance if a terms checkbox is actually present.
    if (snap.termsPresent && !snap.termsAccepted) return false;
    return true;
  }

  function toggleOrderButtons() {
    var hide = isGatewaySelected();

    // Classic checkout button
    var $btn = $(orderButtonSelector);
    if ($btn.length) {
      if (hide) {
        $btn.prop('disabled', true).attr('aria-disabled', 'true').hide();
      } else {
        $btn.prop('disabled', false).removeAttr('aria-disabled').show();
      }
    }

    // Blocks checkout button (best-effort)
    var $bbtn = $(blocksOrderButtonSelector);
    if ($bbtn.length) {
      if (hide) {
        $bbtn.prop('disabled', true).attr('aria-disabled', 'true').hide();
      } else {
        $bbtn.prop('disabled', false).removeAttr('aria-disabled').show();
      }
    }
  }

  function isLikely3dsUrl(url) {
    if (!url) return false;
    return /3ds|secure|authentication|acs|challenge/i.test(url);
  }

  function update3dsClass($iframe) {
    var src = String($iframe.attr('src') || '');
    if (isLikely3dsUrl(src)) $iframe.addClass('is-3ds');
    else $iframe.removeClass('is-3ds');
  }

  function bindIframeEvents() {
    var c = ensureContainer();
    if (!c) return;
    var $iframe = c.find('#bonzai-inline-iframe');

    if ($iframe.data('bonzaiBound')) return;
    $iframe.data('bonzaiBound', true);

    $iframe.on('load', function () {
      // iframe loaded: hide loader and show iframe
      update3dsClass($iframe);
      c.find('#bonzai-inline-loading').hide();
      $iframe.show();
    });
  }

  function prepareSession() {
    if (!prepareUrl) {
      showError('Configuration Bonzai invalide (prepare endpoint manquant).');
      return;
    }

    var snap = getCheckoutSnapshot();

    // Gate access to the payment form: require full identity + address + terms.
    if (!snap || !snap.email) {
      hideContainer();
      return;
    }
    if (!hasRequiredFields(snap)) {
      // Keep the container visible with clear instructions.
      showError(snap.termsPresent ? missingFieldsWithTerms : missingFieldsBase);
      return;
    }

    var fp = computeFp(snap);

    // If we already have a fresh embed for same identity and we are not forcing new
    if (!forceNewNextPrepare && lastPreparedFp && fp === lastPreparedFp && lastEmbedUrl) {
      showIframe(lastEmbedUrl);
      return;
    }

    var $form = getCheckoutForm();
    if (!$form) {
      showError('Formulaire de paiement introuvable.');
      return;
    }

    showLoading(copy.loading || 'Loading secure payment...');

    $.ajax({
      url: prepareUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        checkout_data: $form.serialize(),
        force_new: forceNewNextPrepare ? 1 : 0
      }
    }).done(function (res) {
      // After first call, stop forcing new sessions
      forceNewNextPrepare = false;

      if (!res || !res.ok || !res.embed_url) {
        var msg = copy.error || 'Unable to load payment. Please refresh and try again.';
        if (res && res.error === 'missing_email') msg = copy.missing_email || missingFieldsMsg;
        if (res && res.error === 'missing_required_fields') msg = missingFieldsMsg;
        if (res && res.error === 'missing_terms') msg = copy.missing_terms || 'Please accept the terms and conditions to proceed.';
        showError(msg);
        return;
      }

      lastPreparedFp = fp;
      lastEmbedUrl = res.embed_url;
      lastOrder.id = parseInt(res.order_id || 0, 10) || 0;
      lastOrder.key = String(res.order_key || '');

      try {
        if (window.location.hash !== hashFlag) window.location.hash = hashFlag;
      } catch (e) {}

      showIframe(res.embed_url);
      startPolling();
    }).fail(function () {
      showError(copy.error || 'Unable to load payment. Please refresh and try again.');
    });
  }

  function startPolling() {
    if (!restUrl || !lastOrder.id || !lastOrder.key) return;
    if (pollTimer) return;

    pollTimer = window.setInterval(function () {
      // Fallback: if the Bonzai iframe navigates back to a same-origin URL (e.g. WooCommerce thank-you),
      // break out of the embed immediately. This covers cases where Bonzai completes payment and loads
      // the merchant thank-you page inside the iframe while the Woo order status is still pending.
      try {
        var $ifr = $('#bonzai-inline-iframe');
        if ($ifr.length && $ifr[0].contentWindow && $ifr[0].contentWindow.location) {
          var href = String($ifr[0].contentWindow.location.href || '');
          if (href && href.indexOf(window.location.origin) === 0) {
            window.clearInterval(pollTimer);
            pollTimer = null;
            window.location.href = href;
            return;
          }
        }
      } catch (e) {
        // Cross-origin while still on Bonzai; ignore.
      }

      $.ajax({
        url: restUrl,
        method: 'GET',
        dataType: 'json',
        headers: restNonce ? { 'X-WP-Nonce': restNonce } : {},
        data: { order_id: lastOrder.id, order_key: lastOrder.key }
      }).done(function (res) {
        if (!res) return;

        var paid = false;
        var thankyou = '';

        if (res.ok) {
          paid = !!res.paid;
          thankyou = res.thankyou || '';
        } else if (res.valid !== undefined) {
          paid = !!res.paid;
          thankyou = res.thankyou_url || '';
        }

        if (paid && thankyou) {
          window.clearInterval(pollTimer);
          pollTimer = null;
          window.location.href = thankyou;
        }
      });
    }, 2000);
  }

  function schedulePrepare() {
    // Hide/disable the default WooCommerce order button when Bonzai is selected.
    toggleOrderButtons();
    if (!isGatewaySelected()) {
      hideContainer();
      return;
    }
    if (prepareTimer) window.clearTimeout(prepareTimer);
    prepareTimer = window.setTimeout(function () {
      prepareSession();
    }, 550);
  }

  function bindEvents() {
    ensureContainer();

    $(document.body).on('updated_checkout', function () {
      ensureContainer();
      // Do not force new here; just prepare if needed
      schedulePrepare();
    });

    $(document.body).on('change', 'input[name="payment_method"]', function () {
      toggleOrderButtons();
      if (!isGatewaySelected()) {
        hideContainer();
        lastPreparedFp = null;
        lastEmbedUrl = null;
        lastOrder = { id: 0, key: '' };
        forceNewNextPrepare = true; // next time user comes back, create a fresh session
        if (pollTimer) {
          window.clearInterval(pollTimer);
          pollTimer = null;
        }
        return;
      }
      // When user selects Bonzai, create a fresh session
      forceNewNextPrepare = true;
      schedulePrepare();
    });

    $(document.body).on(
      'input change',
      '#billing_first_name, #billing_last_name, #billing_email, #billing_postcode, #billing_address_1, #billing_city, #billing_country, #billing_state, input[name="billing_first_name"], input[name="billing_last_name"], input[name="billing_email"], input[name="billing_postcode"], input[name="billing_address_1"], input[name="billing_city"], select[name="billing_country"], input[name="billing_country"], select[name="billing_state"], input[name="billing_state"]',
      function () {
        schedulePrepare();
      }
    );

    // Terms acceptance must trigger re-check.
    $(document.body).on('change', termsSelectors, function () {
      schedulePrepare();
    });

    // Prevent the classic checkout from submitting when Bonzai is selected.
    // The payment is completed inside the Bonzai iframe; the WooCommerce button is hidden/disabled.
    $(document).on('submit', 'form.checkout', function (e) {
      if (!isGatewaySelected()) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      schedulePrepare();
      return false;
    });

    // If address changes affect totals, let Woo recompute then prepare
    $(document.body).on(
      'input change',
      '#billing_country, #billing_state, #billing_city, #billing_address_1, #billing_address_2, input[name="billing_country"], input[name="billing_state"], input[name="billing_city"], input[name="billing_address_1"], input[name="billing_address_2"]',
      function () {
        if (!isGatewaySelected()) return;
        $(document.body).trigger('update_checkout');
      }
    );

    // On page load: if Bonzai is already selected, force a fresh session once
    if (isGatewaySelected()) {
      forceNewNextPrepare = true;
      schedulePrepare();
    }
  }

  $(function () {
    bindEvents();
  });
})(jQuery);
