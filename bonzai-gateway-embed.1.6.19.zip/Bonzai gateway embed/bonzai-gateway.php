<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks and order sync.
Requires Plugins: woocommerce
Version: 1.6.19
Author: Ramy
*/

if (!defined('ABSPATH')) exit;

// Used for cache-busting static assets (CSS/JS) when the plugin is updated.
if (!defined('BONZAI_GATEWAY_VERSION')) {
    define('BONZAI_GATEWAY_VERSION', '1.6.19');
}

/**
 * WooCommerce dependency guard.
 *
 * WordPress doesn't provide a strict "block install" mechanism, but we can:
 * - declare a dependency (UI support on recent WP)
 * - prevent activation without WooCommerce
 * - avoid fatal errors if WooCommerce is deactivated later
 */
function bonzai_is_woocommerce_available() {
    return class_exists('WooCommerce') && class_exists('WC_Payment_Gateway');
}

function bonzai_wc_missing_notice() {
    if (!is_admin()) return;
    if (!current_user_can('activate_plugins')) return;

    echo '<div class="notice notice-error"><p>'
        . esc_html__('Bonzai Payment Gateway requires WooCommerce to be installed and active.', 'bonzai-gateway')
        . '</p></div>';
}

register_activation_hook(__FILE__, function () {
    // On activation, ensure WooCommerce is active.
    if (!bonzai_is_woocommerce_available()) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            esc_html__('Bonzai Payment Gateway requires WooCommerce to be installed and active.', 'bonzai-gateway'),
            esc_html__('Plugin dependency missing', 'bonzai-gateway'),
            array('back_link' => true)
        );
    }
});

/**
 * Default gateway description.
 *
 * Important: some merchant setups (notably Checkout Blocks) can break client-side rendering
 * if a gateway returns a non-string/empty payload for certain fields. To be defensive, we
 * always provide a non-empty, human-readable description when the merchant leaves the field blank.
 */
function bonzai_default_gateway_description() {
    return bonzai_tr(
        'The Bonzai checkout will open after you enter your details.',
        "Le paiement Bonzai s'ouvrira après avoir saisi vos informations.",
        'El checkout de Bonzai se abrirá después de introducir tus datos.'
    );
}

/**
 * Lightweight runtime translations for EN/FR/ES.
 * This plugin supports .mo files via load_plugin_textdomain, but many merchants do not ship them.
 * The helper below ensures that core Bonzai-facing strings are translated based on the site locale.
 */
function bonzai_get_locale() {
    $loc = function_exists('determine_locale') ? determine_locale() : get_locale();
    $loc = strtolower((string) $loc);
    if (strpos($loc, 'fr') === 0) return 'fr';
    if (strpos($loc, 'es') === 0) return 'es';
    return 'en';
}
function bonzai_tr($en, $fr, $es) {
    $loc = bonzai_get_locale();
    if ($loc === 'fr') return $fr;
    if ($loc === 'es') return $es;
    return $en;
}

function bonzai_inflow_sdk_locale() {
    $supported = array('en-US', 'fr-FR');
    $locale = str_replace('_', '-', (string) (function_exists('determine_locale') ? determine_locale() : get_locale()));
    $lang = strtolower(substr($locale, 0, 2));
    $normalized = ($lang === 'fr') ? 'fr-FR' : 'en-US';
    return (string) apply_filters('bonzai_inflow_sdk_locale', $normalized, $locale, $supported);
}

// Load translations (optional .mo files under /languages).
add_action('init', function () {
    load_plugin_textdomain('bonzai-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

// If the buyer returns with a wc_order param after paying on Bonzai, redirect to WooCommerce thank-you page.
add_action('template_redirect', function () {
    if (!function_exists('wc_get_order')) return;

    $order_id = 0;
    if (isset($_GET['wc_order'])) {
        $order_id = (int) $_GET['wc_order'];
    } elseif (isset($_GET['order_id'])) {
        $order_id = (int) $_GET['order_id'];
    }

    if ($order_id <= 0) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Only redirect when the order is paid to avoid looping on pending payments.
    if (method_exists($order, 'is_paid') && $order->is_paid()) {
        $thankyou = $order->get_checkout_order_received_url();

        // Bonzai may return the buyer inside an iframe (inline embed / some 3DS flows). A plain redirect would
        // only navigate the iframe, so we force a top-level navigation when possible.
        $thankyou_esc = esc_url($thankyou);

        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));

        echo '<!doctype html><html><head><meta charset="' . esc_attr(get_bloginfo('charset')) . '">';
        echo '<meta http-equiv="refresh" content="0;url=' . $thankyou_esc . '">';
        echo '<title>' . esc_html__('Redirecting…', 'bonzai-gateway') . '</title></head><body>';
        echo '<script>(function(){try{if(window.top&&window.top!==window){window.top.location.href=' . json_encode($thankyou_esc) . ';}else{window.location.href=' . json_encode($thankyou_esc) . ';}}catch(e){window.location.href=' . json_encode($thankyou_esc) . ';}})();</script>';
        echo '<a href="' . $thankyou_esc . '">' . esc_html__('Continue', 'bonzai-gateway') . '</a>';
        echo '</body></html>';
        exit;
    }
}, 1);

// WooCommerce Blocks support (Checkout Block).
// Without this, the Bonzai gateway may not appear when merchants use the block based checkout.
add_action('woocommerce_blocks_loaded', function () {
    if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
        return;
    }

    // Register Bonzai payment method type for Blocks.
    add_action('woocommerce_blocks_payment_method_type_registration', function ($payment_method_registry) {
        if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
            return;
        }

        if (!class_exists('WC_Gateway_Bonzai_Blocks')) {
            class WC_Gateway_Bonzai_Blocks extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {

                protected $name = 'bonzai';

                public function initialize() {
                    $this->settings = get_option('woocommerce_bonzai_settings', array());
                }

                public function is_active() {
                    $enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'no';
                    return $enabled === 'yes';
                }

                public function get_payment_method_script_handles() {
                    $handle = 'bonzai-gateway-blocks';

                    if (!wp_script_is($handle, 'registered')) {
                        wp_register_script(
                            $handle,
                            plugins_url('assets/bonzai-blocks.js', __FILE__),
                            array('wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-data'),
						(file_exists(plugin_dir_path(__FILE__) . 'assets/bonzai-blocks.js')
                            ? (string) filemtime(plugin_dir_path(__FILE__) . 'assets/bonzai-blocks.js')
                            : BONZAI_GATEWAY_VERSION),
                            true
                        );
                    }

                    return array($handle);
                }

                public function get_payment_method_data() {
                    $title = isset($this->settings['title']) && $this->settings['title'] !== '' ? $this->settings['title'] : 'Bonzai';
                    $description = isset($this->settings['description']) ? (string) $this->settings['description'] : '';
                    $engine = bonzai_payment_engine($this->settings);
                    // Defensive: a blank description can cause some checkout UIs to misbehave.
                    if (trim($description) === '') {
                        $description = bonzai_default_gateway_description();
                    }

                    $terms_required = false;
                    if (function_exists('wc_terms_and_conditions_checkbox_enabled')) {
                        $terms_required = (bool) wc_terms_and_conditions_checkbox_enabled();
                    } elseif (function_exists('wc_get_page_id')) {
                        $terms_required = (wc_get_page_id('terms') > 0);
                    }

                    return array(
                        'title'       => $title,
                        'description' => $description,
                        // Declare support for Blocks.
                        'supports'    => array('products'),
                        // Endpoints and security.
                        'prepare_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
                        'rest'         => esc_url_raw(rest_url('bonzai/v1/order-status')),
                        'nonce'        => wp_create_nonce('wp_rest'),
                        'ajax_token'   => bonzai_get_or_create_ajax_token(),
                        'iframe_height_3ds' => isset($this->settings['iframe_height_3ds']) ? absint($this->settings['iframe_height_3ds']) : 860,
                        'payment_engine' => $engine,
                        'inflow' => array(
                            'enabled' => $engine === 'inflow_sdk',
                            'sdk_script_url' => bonzai_inflow_sdk_script_url($this->settings),
                            'fallback_iframe' => bonzai_inflow_fallback_iframe($this->settings),
                            'locale' => bonzai_inflow_sdk_locale(),
                        ),
                        'terms_required' => $terms_required,
                        // i18n
                        'i18n' => array(
                            'loading' => bonzai_tr('Loading secure payment...','Chargement du paiement sécurisé...','Cargando el pago seguro...'),
                            'error'   => bonzai_tr('Unable to load payment. Please refresh and try again.','Impossible de charger le paiement. Veuillez rafraîchir et réessayer.','No se puede cargar el pago. Actualiza e inténtalo de nuevo.'),
                            'missing_email' => bonzai_tr('Please enter a valid email to display the payment form.','Veuillez saisir un e-mail valide pour afficher le formulaire de paiement.','Introduce un correo electrónico válido para mostrar el formulario de pago.'),
                            'missing_terms' => bonzai_tr('Please accept the terms and conditions to proceed.','Veuillez accepter les conditions générales pour continuer.','Acepta los términos y condiciones para continuar.'),
                            // Requirements copy is dynamic on the front-end depending on whether the store actually shows a terms checkbox.
                            'requirements_base' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code).','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal).','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal).'),
                            'requirements_with_terms' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code), and accept the terms and conditions.','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal), et accepter les conditions générales.','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal) y acepta los términos y condiciones.'),
                            'missing_fields_base' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) antes de acceder al formulario de pago.'),
                            'missing_fields_with_terms' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) and accept the terms and conditions before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) et accepter les conditions générales avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) y acepta los términos y condiciones antes de acceder al formulario de pago.'),
                            'sdk_unavailable' => bonzai_tr('Unable to initialize secure payment. Falling back to standard form.','Impossible d’initialiser le paiement sécurisé. Retour au formulaire standard.','No se pudo inicializar el pago seguro. Volviendo al formulario estándar.'),
                            'complete_payment' => bonzai_tr('Complete payment above to finish your order.','Terminez le paiement ci-dessus pour finaliser votre commande.','Completa el pago arriba para finalizar tu pedido.'),
                        ),
                    );
                }
            }
        }

        $payment_method_registry->register(new WC_Gateway_Bonzai_Blocks());
    });
});

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    // Hard dependency on WooCommerce. If WC is missing (or was deactivated after this plugin
    // was enabled), we must not define WC-dependent classes (prevents fatal errors).
    if (!bonzai_is_woocommerce_available()) {
        add_action('admin_notices', 'bonzai_wc_missing_notice');
        return;
    }

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = bonzai_tr('Bonzai', 'Bonzai', 'Bonzai');
            $this->method_description = bonzai_tr('Pay through Bonzai Checkout.', 'Payer via Bonzai Checkout.', 'Pagar a través de Bonzai Checkout.');
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->title               = $this->get_option('title');
            $this->description         = (string) $this->get_option('description');
            if (trim($this->description) === '') {
                $this->description = bonzai_default_gateway_description();
            }
            $this->enabled             = $this->get_option('enabled');
            $this->api_token           = trim($this->get_option('api_token'));
            $this->product_uuid        = trim($this->get_option('product_uuid'));
            // Redirect is handled by WooCommerce's native return URL (order received page).
            // Custom redirect URLs are intentionally not supported to prevent iframe-level redirects
            // and to keep behaviour consistent across Checkout Blocks and classic checkout.
			$this->popup_iframe       = $this->get_option('popup_iframe', 'yes');
			// Inline iframe embed inside WooCommerce checkout (no modal).
			$this->inline_iframe      = $this->get_option('inline_iframe', 'no');
			// Inline mode: iframe height during 3DS challenge (in px). Used by CSS variable.
			$this->iframe_height_3ds  = absint($this->get_option('iframe_height_3ds', 860));
            $this->debug               = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout             = absint($this->get_option('timeout', 20));
            $this->force_currency      = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount          = floatval($this->get_option('min_amount', 0));
            $this->webhook_token       = trim($this->get_option('webhook_token', ''));
            $this->is_vat_incl_default = $this->get_option('is_vat_incl_default', 'yes');
            $this->order_sync_enabled  = $this->get_option('order_sync_enabled', 'no');
            $this->order_sync_hour     = intval($this->get_option('order_sync_hour', 3));
            $this->order_sync_day      = strtolower($this->get_option('order_sync_day', 'monday'));

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        /**
         * Ensure required gateway settings are always sane.
         *
         * Merchants can save an empty Description in the gateway settings. In some themes / Blocks
         * setups, an empty description has been observed to break the checkout rendering.
         * We therefore normalize it to a translated default on save.
         */
        public function process_admin_options() {
            $saved = parent::process_admin_options();

            // Normalise saved options defensively.
            $key = $this->get_option_key();
            $opt = get_option($key, array());
            if (!is_array($opt)) {
                $opt = array();
            }

            // Title fallback (shouldn't happen but keep it safe).
            if (!isset($opt['title']) || trim((string) $opt['title']) === '') {
                $opt['title'] = bonzai_tr('Pay with BNZ', 'Payer avec BNZ', 'Pagar con BNZ');
            }

            // Description: prevent empty payloads.
            if (!isset($opt['description']) || trim((string) $opt['description']) === '') {
                $opt['description'] = bonzai_default_gateway_description();
            }

            update_option($key, $opt);
            return $saved;
        }

        public function init_form_fields() {
            $base_webhook_url = rest_url('bonzai/v1/webhook');

            
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => bonzai_tr('Enable', 'Activer', 'Habilitar'),
                    'type'    => 'checkbox',
                    'label'   => bonzai_tr('Enable Bonzai Checkout', 'Activer Bonzai Checkout', 'Habilitar Bonzai Checkout'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => bonzai_tr('Title', 'Titre', 'Título'),
                    'type'        => 'text',
                    'description' => bonzai_tr('Displayed title during checkout.', 'Titre affiché au moment du paiement.', 'Título mostrado durante el pago.'),
                    'default'     => bonzai_tr('Pay with BNZ', 'Payer avec BNZ', 'Pagar con BNZ'),
                ),
                'description' => array(
                    'title'       => bonzai_tr('Description', 'Description', 'Descripción'),
                    'type'        => 'textarea',
                    'default'     => bonzai_default_gateway_description(),
                    // Hint the admin UI that this field should not be left blank.
                    'custom_attributes' => array('required' => 'required'),
                ),
                'api_token' => array(
                    'title'       => bonzai_tr('API Token', 'Jeton API', 'Token API'),
                    'type'        => 'password',
                    'description' => bonzai_tr(
                        'Your Bonzai API token (Bonzai Premium dashboard → API Tokens).',
                        'Votre jeton API Bonzai (tableau de bord Bonzai Premium → API Tokens).',
                        'Tu token API de Bonzai (panel de Bonzai Premium → API Tokens).'
                    ),
                ),
                'product_uuid' => array(
                    'title'       => bonzai_tr('Bonzai Product UUID', 'UUID du produit Bonzai', 'UUID del producto Bonzai'),
                    'type'        => 'text',
                    'description' => bonzai_tr(
                        'The Bonzai product UUID used for all WooCommerce purchases.',
                        'UUID du produit Bonzai utilisé pour tous les achats WooCommerce.',
                        'UUID del producto Bonzai usado para todas las compras de WooCommerce.'
                    ),
                ),

                'payment_engine' => array(
                    'title'       => bonzai_tr('Payment engine', 'Moteur de paiement', 'Motor de pago'),
                    'type'        => 'select',
                    'default'     => 'iframe_legacy',
                    'options'     => array(
                        'iframe_legacy' => bonzai_tr('Legacy Bonzai iframe', 'Iframe Bonzai historique', 'Iframe Bonzai heredado'),
                        'inflow_sdk'    => bonzai_tr('Modern Inflow SDK (recommended)', 'SDK Inflow moderne (recommandé)', 'SDK Inflow moderno (recomendado)'),
                    ),
                    'description' => bonzai_tr(
                        'Choose how payment is rendered inside checkout. Inflow SDK reduces iframe-in-iframe friction during 3DS.',
                        'Choisissez comment le paiement est affiché dans le checkout. Le SDK Inflow réduit la friction iframe-dans-iframe pendant le 3DS.',
                        'Elige cómo se muestra el pago en checkout. El SDK de Inflow reduce la fricción de iframe dentro de iframe durante 3DS.'
                    ),
                ),
                'inflow_start_base_url' => array(
                    'title'       => bonzai_tr('Inflow start API base URL', 'URL de base API start Inflow', 'URL base API start de Inflow'),
                    'type'        => 'text',
                    'default'     => 'https://app.squidpay.io/api/v1',
                    'description' => bonzai_tr(
                        'Base URL used to start an order after checkout creation. Keep default unless instructed by Bonzai/Squidpay.',
                        'URL de base utilisée pour démarrer une commande après création checkout. Gardez la valeur par défaut sauf instruction Bonzai/Squidpay.',
                        'URL base para iniciar una orden tras crear el checkout. Mantén el valor por defecto salvo indicación de Bonzai/Squidpay.'
                    ),
                ),
                'inflow_sdk_script_url' => array(
                    'title'       => bonzai_tr('Inflow SDK script URL', 'URL du script SDK Inflow', 'URL del script SDK de Inflow'),
                    'type'        => 'text',
                    'default'     => 'https://cdn.jsdelivr.net/npm/@inflow_pay/sdk@latest/dist/sdk.umd.js',
                    'description' => bonzai_tr(
                        'Public SDK URL loaded on checkout when Inflow mode is enabled.',
                        'URL publique du SDK chargée sur checkout quand le mode Inflow est activé.',
                        'URL pública del SDK cargada en checkout cuando Inflow está activado.'
                    ),
                ),
                'inflow_fallback_iframe' => array(
                    'title'   => bonzai_tr('Fallback behavior', 'Comportement de secours', 'Comportamiento de respaldo'),
                    'type'    => 'checkbox',
                    'label'   => bonzai_tr('Fallback to legacy iframe if Inflow start fails', 'Revenir à l’iframe historique si le start Inflow échoue', 'Volver al iframe heredado si falla el inicio de Inflow'),
                    'default' => 'yes',
                ),
                'popup_iframe' => array(
                    'title'       => bonzai_tr('Popup (iframe) mode', 'Mode popup (iframe)', 'Modo popup (iframe)'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Open Bonzai checkout in a modal popup (iframe)', 'Ouvrir le checkout Bonzai dans une popup modale (iframe)', 'Abrir el checkout de Bonzai en un modal (iframe)'),
                    'description' => bonzai_tr(
                        'After placing the order, the customer is redirected to a minimal page that immediately opens Bonzai checkout in a modal iframe. This improves conversion on desktop and many mobile browsers, but 3DS flows may still cause a full-page navigation depending on the bank/browser.',
                        "Après avoir passé la commande, le client est redirigé vers une page minimale qui ouvre immédiatement le checkout Bonzai dans une iframe modale. Cela améliore la conversion sur desktop et de nombreux navigateurs mobiles, mais certains parcours 3DS peuvent encore provoquer une navigation plein écran selon la banque/le navigateur.",
                        'Después de realizar el pedido, el cliente es redirigido a una página mínima que abre inmediatamente el checkout de Bonzai en un iframe modal. Esto mejora la conversión en escritorio y muchos navegadores móviles, pero algunos flujos 3DS aún pueden provocar una navegación a pantalla completa según el banco/navegador.'
                    ),
                    'default'     => 'no',
                ),

                'inline_iframe' => array(
                    'title'       => bonzai_tr('Inline embed (iframe) mode', 'Mode embed inline (iframe)', 'Modo incrustado en línea (iframe)'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Render Bonzai checkout inline inside WooCommerce checkout (no popup)', 'Intégrer le checkout Bonzai directement dans le checkout WooCommerce (sans popup)', 'Mostrar el checkout de Bonzai incrustado dentro del checkout de WooCommerce (sin popup)'),
                    'description' => bonzai_tr(
                        'If enabled, the Bonzai payment portal is embedded directly in the payment section (iframe). This mode disables the modal popup behaviour and keeps the customer on the checkout page. Note: some 3DS flows can still navigate the iframe to a full-page challenge depending on issuer/browser.',
                        "Si activé, le portail de paiement Bonzai est intégré directement dans la section paiement (iframe). Ce mode désactive la popup modale et maintient le client sur la page de paiement. Note : certains parcours 3DS peuvent encore naviguer l'iframe vers un challenge plein écran selon l’émetteur/le navigateur.",
                        'Si está activado, el portal de pago de Bonzai se incrusta directamente en la sección de pago (iframe). Este modo desactiva el comportamiento de popup modal y mantiene al cliente en la página de checkout. Nota: algunos flujos 3DS aún pueden navegar el iframe a un desafío de pantalla completa según el emisor/navegador.'
                    ),
                    'default'     => 'yes',
                ),

				'iframe_height_3ds' => array(
					'title'       => bonzai_tr('Iframe height during 3DS (px)', 'Hauteur de l’iframe pendant 3DS (px)', 'Altura del iframe durante 3DS (px)'),
					'type'        => 'number',
					'description' => bonzai_tr(
						'When the bank 3D Secure challenge is shown inside the embedded iframe, the plugin increases the iframe height. Set the height in pixels (e.g. 860).',
						'Quand le challenge 3D Secure de la banque est affiché dans l’iframe intégrée, le plugin augmente la hauteur de l’iframe. Définissez la hauteur en pixels (ex : 860).',
						'Cuando se muestra el desafío 3D Secure del banco dentro del iframe incrustado, el plugin aumenta la altura del iframe. Define la altura en píxeles (p.ej. 860).'
					),
					'default'     => '860',
					'custom_attributes' => array('min' => '300', 'max' => '2000', 'step' => '10'),
				),

                'force_currency' => array(
                    'title'       => bonzai_tr('Currency sent to Bonzai', 'Devise envoyée à Bonzai', 'Moneda enviada a Bonzai'),
                    'type'        => 'select',
                    'description' => bonzai_tr(
                        'If empty, WooCommerce currency will be used. Bonzai supports EUR or USD.',
                        'Si vide, la devise WooCommerce sera utilisée. Bonzai supporte EUR ou USD.',
                        'Si está vacío, se usará la moneda de WooCommerce. Bonzai admite EUR o USD.'
                    ),
                    'default'     => '',
                    'options'     => array(
                        ''    => bonzai_tr('Use WooCommerce currency', 'Utiliser la devise WooCommerce', 'Usar la moneda de WooCommerce'),
                        'EUR' => bonzai_tr('Force EUR', 'Forcer EUR', 'Forzar EUR'),
                        'USD' => bonzai_tr('Force USD', 'Forcer USD', 'Forzar USD'),
                    ),
                ),
                'min_amount' => array(
                    'title'       => bonzai_tr('Minimum amount', 'Montant minimum', 'Importe mínimo'),
                    'type'        => 'number',
                    'description' => bonzai_tr(
                        'Minimum cart total required to enable this payment method. Set 0 to disable.',
                        "Total minimum du panier requis pour activer ce moyen de paiement. Mettre 0 pour désactiver.",
                        'Total mínimo del carrito requerido para habilitar este método de pago. Ponga 0 para desactivar.'
                    ),
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => bonzai_tr('API Request Timeout (seconds)', "Délai d'expiration API (secondes)", 'Tiempo de espera de la API (segundos)'),
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => bonzai_tr('Debug Logs', 'Logs de debug', 'Registros de depuración'),
                    'type'        => 'checkbox',
                    'label'       => bonzai_tr('Enable logs (WooCommerce → Status → Logs)', 'Activer les logs (WooCommerce → Statut → Logs)', 'Habilitar logs (WooCommerce → Estado → Logs)'),
                    'default'     => 'no',
                ),

                'is_vat_incl_default' => array(
                    'title'       => bonzai_tr('Amounts include VAT?', 'Montants TTC ?', '¿Importes incluyen IVA?'),
                    'type'        => 'select',
                    'description' => bonzai_tr(
                        'Default VAT handling for Bonzai amounts. Can be overridden per product.',
                        'Gestion TVA par défaut pour les montants Bonzai. Peut être surchargée par produit.',
                        'Gestión de IVA por defecto para importes Bonzai. Se puede sobrescribir por producto.'
                    ),
                    'default'     => 'yes',
                    'options'     => array(
                        'yes' => bonzai_tr('Yes, prices include VAT', 'Oui, prix TTC', 'Sí, los precios incluyen IVA'),
                        'no'  => bonzai_tr('No, prices are excl. VAT', 'Non, prix HT', 'No, los precios no incluyen IVA'),
                    ),
                ),

                'order_sync_title' => array(
                    'title'       => bonzai_tr('Automatic Bonzai order sync', 'Synchronisation automatique des commandes Bonzai', 'Sincronización automática de pedidos Bonzai'),
                    'type'        => 'title',
                    'description' => bonzai_tr(
                        'Automatically call Bonzai Retrieve an order to keep WooCommerce orders in sync.',
                        'Appelle automatiquement Bonzai “Retrieve an order” pour garder les commandes WooCommerce synchronisées.',
                        'Llama automáticamente a Bonzai “Retrieve an order” para mantener los pedidos de WooCommerce sincronizados.'
                    ),
                ),
                'order_sync_enabled' => array(
                    'title'       => bonzai_tr('Automatic sync frequency', 'Fréquence de synchronisation', 'Frecuencia de sincronización'),
                    'type'        => 'select',
                    'default'     => 'no',
                    'options'     => array(
                        'no'     => bonzai_tr('Disabled', 'Désactivé', 'Desactivado'),
                        'daily'  => bonzai_tr('Daily', 'Quotidien', 'Diaria'),
                        'weekly' => bonzai_tr('Weekly', 'Hebdomadaire', 'Semanal'),
                    ),
                ),
                'order_sync_hour' => array(
                    'title'       => bonzai_tr('Sync hour (0 to 23)', 'Heure de sync (0 à 23)', 'Hora de sincronización (0 a 23)'),
                    'type'        => 'number',
                    'default'     => '3',
                    'custom_attributes' => array('min' => '0', 'max' => '23', 'step' => '1'),
                    'description' => bonzai_tr(
                        'Hour of the day (server time) when the automatic sync should run.',
                        "Heure de la journée (heure serveur) à laquelle la synchronisation doit s'exécuter.",
                        'Hora del día (hora del servidor) en la que debe ejecutarse la sincronización.'
                    ),
                ),
                'order_sync_day' => array(
                    'title'       => bonzai_tr('Sync weekday (weekly sync)', 'Jour de sync (hebdomadaire)', 'Día de sincronización (semanal)'),
                    'type'        => 'select',
                    'default'     => 'monday',
                    'options'     => array(
                        'monday'    => bonzai_tr('Monday', 'Lundi', 'Lunes'),
                        'tuesday'   => bonzai_tr('Tuesday', 'Mardi', 'Martes'),
                        'wednesday' => bonzai_tr('Wednesday', 'Mercredi', 'Miércoles'),
                        'thursday'  => bonzai_tr('Thursday', 'Jeudi', 'Jueves'),
                        'friday'    => bonzai_tr('Friday', 'Vendredi', 'Viernes'),
                        'saturday'  => bonzai_tr('Saturday', 'Samedi', 'Sábado'),
                        'sunday'    => bonzai_tr('Sunday', 'Dimanche', 'Domingo'),
                    ),
                ),

                'webhook_title' => array(
                    'title'       => bonzai_tr('Bonzai Webhooks', 'Webhooks Bonzai', 'Webhooks de Bonzai'),
                    'type'        => 'title',
                    'description' => bonzai_tr(
                        'Bonzai sends product_access_granted and product_access_revoked. Secured using a token.',
                        'Bonzai envoie product_access_granted et product_access_revoked. Sécurisé via un token.',
                        'Bonzai envía product_access_granted y product_access_revoked. Asegurado mediante un token.'
                    ),
                ),
                'webhook_token' => array(
                    'title'       => bonzai_tr('Webhook Token', 'Token de webhook', 'Token de webhook'),
                    'type'        => 'text',
                    'description' => bonzai_tr(
                        'Use Generate token, then click Save changes. Paste the webhook URL in Bonzai Premium Webhooks.',
                        'Utilisez “Générer un token”, puis cliquez sur “Enregistrer les modifications”. Collez ensuite l’URL du webhook dans Bonzai Premium Webhooks.',
                        'Use “Generar token”, luego haga clic en “Guardar cambios”. Pegue la URL del webhook en Bonzai Premium Webhooks.'
                    ),
                ),
                'webhook_url' => array(
                    'title'       => bonzai_tr('Webhook URL', 'URL du webhook', 'URL del webhook'),
                    'type'        => 'title',
                    'description' =>
                        '<div style="margin:6px 0 10px 0;">' .
                        '<code id="bonzai_webhook_url_preview" data_base_url="' . esc_attr($base_webhook_url) . '">' .
                        esc_html($base_webhook_url) .
                        '</code>' .
                        '</div>' .
                        '<div style="font-size:12px; color:#444;">' . esc_html(bonzai_tr('Paste this URL in Bonzai Premium Webhooks.', 'Collez cette URL dans Bonzai Premium Webhooks.', 'Pegue esta URL en Bonzai Premium Webhooks.')) . '</div>',
                ),
            );

}

        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai_gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function admin_options() {
            parent::admin_options();
            ?>
            <script type="text/javascript">
            (function($){
                $(function(){
                    var $tokenField = $('#woocommerce_bonzai_webhook_token');
                    if (!$tokenField.length) return;

var bonzaiGenerateTokenLabel = <?php echo wp_json_encode( bonzai_tr('Generate token', 'Générer un token', 'Generar token') ); ?>;
                    var $btn = $('<button type="button" class="button" style="margin-left:8px;"></button>').text(bonzaiGenerateTokenLabel);
                    $btn.insertAfter($tokenField);

                    var $preview = $('#bonzai_webhook_url_preview');
                    var baseUrl  = $preview.attr('data_base_url') || $preview.text();

                    function updatePreview() {
                        var token = $.trim($tokenField.val());
                        var url = baseUrl;
                        if (token) {
                            url += '?token=' + encodeURIComponent(token);
                        } else {
                            url += '?token=YOUR_TOKEN';
                        }
                        $preview.text(url);
                    }

                    $btn.on('click', function(e){
                        e.preventDefault();

                        var token = '';
                        while (token.length < 32) {
                            token += Math.random().toString(36).substring(2);
                        }
                        token = token.substring(0, 32);

                        $tokenField.val(token);
                        $tokenField.trigger('change');
                        updatePreview();

                        var $form = $tokenField.closest('form');
                        if ($form.length) {
                            $form.trigger('change');
                        }
                    });

                    $tokenField.on('input change', updatePreview);
                    updatePreview();
                });
            })(jQuery);
            </script>
            <?php
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) {
                $currency = 'EUR';
            }

            $email = $order->get_billing_email() ?: '';
            // Always rely on WooCommerce's native return URL (order received page).
            // We also add wc_order for our redirect bridge / iframe-safe navigation logic.
            $redirect_url = add_query_arg(
                array('wc_order' => $order->get_id()),
                $order->get_checkout_order_received_url()
            );

            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            $is_vat_incl = ($this->is_vat_incl_default === 'yes');
            $mode        = 'one_off';
            $interval    = null;

            if ($item_count > 0 && is_array($items)) {
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    $product_id   = $item->get_product_id();
                    $product      = $product_id ? wc_get_product($product_id) : null;

                    if ($product_id) {
                        $override_vat = get_post_meta($product_id, 'bonzai_is_vat_incl', true);
                        if ($override_vat === 'yes') $is_vat_incl = true;
                        if ($override_vat === 'no')  $is_vat_incl = false;
                    }

                    $product_mode = $product_id ? get_post_meta($product_id, 'bonzai_payment_mode', true) : '';

                    if ($product && empty($product_mode)) {
                        if (class_exists('WC_Product_Subscription') && $product instanceof WC_Product_Subscription) {
                            $product_mode = 'subscription_auto';
                        } elseif (class_exists('WC_Product_Variable_Subscription') && $product instanceof WC_Product_Variable_Subscription) {
                            $product_mode = 'subscription_auto';
                        }
                    }

                    if ($product_mode === 'subscription_monthly') {
                        $mode     = 'subscription';
                        $interval = 'month';
                    } elseif ($product_mode === 'subscription_yearly') {
                        $mode     = 'subscription';
                        $interval = 'year';
                    } elseif ($product_mode === 'subscription_auto') {
                        $mode = 'subscription';
                        if ($product && is_callable(array($product, 'get_billing_period'))) {
                            $period = (string) $product->get_billing_period();
                            if ($period === 'year') {
                                $interval = 'year';
                            } else {
                                $interval = 'month';
                            }
                        } else {
                            $interval = 'month';
                        }
                    } else {
                        $mode     = 'one_off';
                        $interval = null;
                    }

                    break;
                }
            }

            if ($product_name) {
                if ($item_count > 1) {
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    $bonzai_title = $product_name;
                }
            } else {
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => (bool) $is_vat_incl,
                'mode'         => $mode,
            );

            if ($interval && $mode === 'subscription') {
                $payload['interval'] = $interval;
            }

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            // Prefill customer identity on Bonzai checkout (optional fields).
            $first_name = method_exists($order, 'get_billing_first_name') ? (string) $order->get_billing_first_name() : '';
            $last_name  = method_exists($order, 'get_billing_last_name') ? (string) $order->get_billing_last_name() : '';
            if (!empty($first_name)) {
                $payload['firstname'] = sanitize_text_field($first_name);
            }
            if (!empty($last_name)) {
                $payload['lastname'] = sanitize_text_field($last_name);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = (string) wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            $this->log('Bonzai checkout response HTTP ' . $code_http . ' body=' . $body_txt);

            $bonzai_error_msg = '';
            if (is_array($body)) {
                if (!empty($body['message'])) {
                    $bonzai_error_msg = (string) $body['message'];
                } elseif (!empty($body['errors']) && is_array($body['errors'])) {
                    foreach ($body['errors'] as $field => $messages) {
                        if (is_array($messages) && !empty($messages)) {
                            $bonzai_error_msg = (string) $field . ': ' . (string) reset($messages);
                            break;
                        }
                    }
                }
            }

            if ($code_http < 200 || $code_http >= 300 || !is_array($body) || empty($body['checkout_url'])) {
                $note = 'Bonzai API HTTP ' . $code_http . ' -> ' . $body_txt;
                $order->add_order_note($note);

                $human_msg = 'Unable to create Bonzai payment.';
                if ($bonzai_error_msg) {
                    $human_msg .= ' Bonzai says: ' . $bonzai_error_msg;
                } else {
                    $human_msg .= ' Please try again later.';
                }

                return $this->fail_with_notice($order, $human_msg);
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                // Use WooCommerce order meta API (HPOS compatible).
                $order->update_meta_data('_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }
            if (!empty($body['squidpay_order_id'])) {
                $order->update_meta_data('_bonzai_squidpay_order_id', sanitize_text_field($body['squidpay_order_id']));
                $order->add_order_note('Bonzai: squidpay_order_id linked ' . $body['squidpay_order_id']);
            }

// Store URLs (HPOS compatible).
$order->update_meta_data('_bonzai_checkout_url', esc_url_raw($body['checkout_url']));
if (!empty($body['embed_url'])) {
    $order->update_meta_data('_bonzai_embed_url', esc_url_raw($body['embed_url']));
}

// Persist meta changes before redirecting.
$order->save();

// Inline (iframe) mode: keep the customer on the checkout page and render the Bonzai payment UI inline.
// We return a redirect to the SAME checkout URL with a hash.
if (isset($this->inline_iframe) && $this->inline_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can render inline without leaving the checkout page.
	if (function_exists('WC') && WC() && WC()->session) {
		// Reuse the existing session keys used by the "popup session" AJAX endpoint.
		WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
		WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
		WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
	}

    $checkout_url = '';
    if (!empty($_POST['bonzai_checkout_page_url'])) {
        $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
    }
    if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
        $session_url = WC()->session->get('bonzai_checkout_page_url');
        if (!empty($session_url)) {
            $checkout_url = esc_url_raw($session_url);
        }
    }
    if (empty($checkout_url)) {
        $checkout_url = wc_get_checkout_url();
    }

    return array(
        'result'   => 'success',
        'redirect' => $checkout_url . '#bonzai-inline',
    );
}

// Popup (iframe) mode: keep the customer on the checkout page and open a modal iframe.
// We return a redirect to the SAME checkout URL with a hash. This prevents a full page change,
// even on sites where WooCommerce checkout interception is unreliable.
if ($this->popup_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can open the modal without leaving the checkout page.
    if (function_exists('WC') && WC()->session) {
					// Reuse the existing session keys used by the wc-ajax endpoint (bonzai_popup_session).
					WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
					WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
					WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
    }

    // Stay on the current checkout page (works with custom checkout pages/builders).
// IMPORTANT: wp_get_referer() can be the wc-ajax endpoint (update_order_review), so we prefer an explicit
// URL passed from the checkout page (front-end) to avoid redirecting to wc-ajax URLs (which can 403).
$checkout_url = '';

// 1) Prefer the explicit URL passed from the browser.
if (!empty($_POST['bonzai_checkout_page_url'])) {
    $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
}

// 2) Fallback to session (captured during template render), which is more reliable with checkout builders.
if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
    $session_url = WC()->session->get('bonzai_checkout_page_url');
    if (!empty($session_url)) {
        $checkout_url = esc_url_raw($session_url);
    }
}

// 3) Final fallback: WooCommerce configured checkout page.
if (empty($checkout_url)) {
    $checkout_url = wc_get_checkout_url();
}

// Only allow same-origin URLs (protect against open redirects).
$home_host = parse_url(home_url('/'), PHP_URL_HOST);
$url_host  = parse_url($checkout_url, PHP_URL_HOST);
if (!$home_host || !$url_host || strtolower($home_host) !== strtolower($url_host)) {
    $checkout_url = wc_get_checkout_url();
}

// Remove any wc-ajax param if present and drop existing hash.
$checkout_url = remove_query_arg('wc-ajax', $checkout_url);
$checkout_url = preg_replace('/#.*$/', '', $checkout_url);

// Hash-only change so the customer stays on the same page.
$hash = ($this->inline_iframe === 'yes') ? '#bonzai-inline' : '#bonzai';
$checkout_url = $checkout_url . $hash;

    return array(
        'result'           => 'success',
        'redirect'         => esc_url_raw($checkout_url),
        'bonzai_wc_order'  => (int) $order->get_id(),
        'bonzai_order_key' => (string) $order->get_order_key(),
        'bonzai_thankyou'  => esc_url_raw($this->get_return_url($order)),
        'bonzai_embed_url' => esc_url_raw($iframe_url),
    );
}

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}

/**
 * Popup checkout mode (iframe)
 * Adds an endpoint under the merchant domain:
 *   /bonzai/popup/{order_id}/{order_key}
 * which renders a minimal page that opens Bonzai checkout in a full-screen modal iframe.
 *
 * This avoids relying on WooCommerce redirect interception (which varies across themes/builders/blocks).
 */

register_activation_hook(__FILE__, 'bonzai_gateway_activate');
register_deactivation_hook(__FILE__, 'bonzai_gateway_deactivate');

function bonzai_gateway_activate() {
    bonzai_gateway_add_rewrite_rules();
    flush_rewrite_rules();
}

function bonzai_gateway_deactivate() {
    flush_rewrite_rules();
}

// Persist the real checkout page URL in the WooCommerce session so we can reliably redirect back to it
// after placing the order (even when the actual checkout submission happens via wc-ajax endpoints).
add_action('template_redirect', function () {
    if (is_admin() || !function_exists('WC') || !WC() || !WC()->session) {
        return;
    }

    $is_checkout_like = function_exists('is_checkout') && is_checkout();
    $is_cartflows_checkout = isset($_GET['wcf_checkout_id']);
    $looks_like_checkout_path = isset($_SERVER['REQUEST_URI']) && (strpos($_SERVER['REQUEST_URI'], 'checkout') !== false);

    if (!$is_checkout_like && !$is_cartflows_checkout && !$looks_like_checkout_path) {
        return;
    }

    $scheme = is_ssl() ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $uri    = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

    if (empty($host)) {
        return;
    }

    $url = $scheme . '://' . $host . $uri;

    // Strip fragments and wc-ajax query param if present.
    $url = preg_replace('/#.*$/', '', $url);
    if (function_exists('remove_query_arg')) {
        $url = remove_query_arg('wc-ajax', $url);
    }

    // WC session might not be initialized on some non-standard checkout pages.
    if (function_exists('WC') && WC() && isset(WC()->session) && WC()->session) {
        WC()->session->set('bonzai_checkout_page_url', $url);
    }
}, 1);

add_action('wp_enqueue_scripts', function () {
    // Load embedded UI assets on checkout-like pages.
    if (is_admin()) return;
    if (!class_exists('WooCommerce')) return;

    $settings  = get_option('woocommerce_bonzai_settings', array());
    $inline_on = isset($settings['inline_iframe']) ? ($settings['inline_iframe'] === 'yes') : false;
    $popup_on  = isset($settings['popup_iframe']) ? ($settings['popup_iframe'] === 'yes') : false;

    // Inline has priority over popup.
    if (!$inline_on && !$popup_on) {
        return;
    }

    $plugin_url = plugin_dir_url(__FILE__);

    if ($inline_on) {
		$payment_engine = bonzai_payment_engine($settings);
		$inline_js_ver = file_exists(plugin_dir_path(__FILE__) . 'assets/bonzai-inline.js')
            ? (string) filemtime(plugin_dir_path(__FILE__) . 'assets/bonzai-inline.js')
            : BONZAI_GATEWAY_VERSION;
		wp_enqueue_script('bonzai-inline', $plugin_url . 'assets/bonzai-inline.js', array('jquery'), $inline_js_ver, true);
		wp_enqueue_style('bonzai-inline-ui', $plugin_url . 'assets/bonzai-inline.css', array(), BONZAI_GATEWAY_VERSION);

		// Allow merchants to tune iframe height specifically during 3DS.
		$h = 860;
		if (isset($settings['iframe_height_3ds'])) {
			$h = absint($settings['iframe_height_3ds']);
		}
		// Defensive bounds.
		if ($h < 300) $h = 300;
		if ($h > 2000) $h = 2000;
		wp_add_inline_style('bonzai-inline-ui', '#bonzai-inline-container{--bonzai-3ds-height:' . $h . 'px;}');
        $proceed_label = bonzai_tr('Proceed to Bonzai','Procéder vers Bonzai','Proceder a Bonzai');

        wp_localize_script('bonzai-inline', 'BONZAI_INLINE', array(
			// 3DS height (px) so the front-end can force the iframe height even when 3DS
			// happens inside nested frames without URL changes or postMessage events.
			'iframe_height_3ds' => $h,
            'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
            'nonce' => wp_create_nonce('wp_rest'),
            'ajax_token' => bonzai_get_or_create_ajax_token(),
            'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
            'prepare_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
            'gateway_id'   => 'bonzai',
            'hash'         => '#bonzai-inline',
            'payment_engine' => $payment_engine,
            'inflow' => array(
                'enabled' => $payment_engine === 'inflow_sdk',
                'sdk_script_url' => bonzai_inflow_sdk_script_url($settings),
                'fallback_iframe' => bonzai_inflow_fallback_iframe($settings),
                'locale' => bonzai_inflow_sdk_locale(),
            ),
            // UX: on page refresh, create a fresh Bonzai session rather than showing a potentially stale iframe.
            'force_new_on_load' => true,
            'order_button_selector' => '#place_order',
            'i18n' => array(
                'proceed_to_bonzai' => $proceed_label,
                'loading' => bonzai_tr('Loading secure payment...','Chargement du paiement sécurisé...','Cargando el pago seguro...'),
                'error'   => bonzai_tr('Unable to load payment. Please refresh and try again.','Impossible de charger le paiement. Veuillez rafraîchir et réessayer.','No se puede cargar el pago. Actualiza e inténtalo de nuevo.'),
                'missing_email' => bonzai_tr('Please enter a valid email to display the payment form.','Veuillez saisir un e-mail valide pour afficher le formulaire de paiement.','Introduce un correo electrónico válido para mostrar el formulario de pago.'),
                'missing_terms' => bonzai_tr('Please accept the terms and conditions to proceed.','Veuillez accepter les conditions générales pour continuer.','Acepta los términos y condiciones para continuar.'),
                // Requirements copy is dynamic on the front-end depending on whether the store actually shows a terms checkbox.
                'requirements_base' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code).','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal).','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal).'),
                'requirements_with_terms' => bonzai_tr('To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, city, country, postal code), and accept the terms and conditions.','Pour accéder au paiement Bonzai, veuillez renseigner votre prénom, nom, e-mail et votre adresse de facturation complète (rue, ville, pays, code postal), et accepter les conditions générales.','Para acceder al pago de Bonzai, completa tu nombre, apellidos, correo electrónico y la dirección de facturación completa (calle, ciudad, país, código postal) y acepta los términos y condiciones.'),
                'missing_fields_base' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) antes de acceder al formulario de pago.'),
                'missing_fields_with_terms' => bonzai_tr('Please complete the required fields (First name, Last name, Email, street address, city, country, postal code) and accept the terms and conditions before accessing the payment form.','Veuillez compléter les champs obligatoires (prénom, nom, e-mail, adresse, ville, pays, code postal) et accepter les conditions générales avant d’accéder au formulaire de paiement.','Completa los campos obligatorios (nombre, apellidos, correo, dirección, ciudad, país, código postal) y acepta los términos y condiciones antes de acceder al formulario de pago.'),
                'sdk_unavailable' => bonzai_tr('Unable to initialize secure payment. Falling back to standard form.','Impossible d’initialiser le paiement sécurisé. Retour au formulaire standard.','No se pudo inicializar el pago seguro. Volviendo al formulario estándar.'),
            ),
        ));
        return;
    }

    // Popup fallback.
	wp_enqueue_script('bonzai-popup', $plugin_url . 'assets/bonzai-popup.js', array('jquery'), BONZAI_GATEWAY_VERSION, true);
	wp_enqueue_style('bonzai-popup-ui', $plugin_url . 'assets/bonzai-popup.css', array(), BONZAI_GATEWAY_VERSION);
    wp_localize_script('bonzai-popup', 'BONZAI_POPUP', array(
        'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_token' => bonzai_get_or_create_ajax_token(),
        'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
        'i18n' => array(
            'title' => bonzai_tr('Secure payment','Paiement sécurisé','Pago seguro'),
            'close' => bonzai_tr('Close','Fermer','Cerrar'),
        ),
    ));
});

/**
 * Iframe escape hatch for WooCommerce thank-you pages.
 *
 * In certain embedded/3DS flows, the payment provider may navigate the iframe back
 * to the merchant "order received" page. With WooCommerce Blocks checkout, this
 * can cause the thank-you page to render inside the Bonzai iframe (small preview)
 * while the parent page remains on checkout.
 *
 * This snippet forces a top-level navigation whenever the order-received page is
 * loaded inside an iframe.
 */
add_action('wp_footer', function () {
    if (function_exists('is_order_received_page') && is_order_received_page()) {
        echo "\n<script>(function(){try{if(window.top&&window.top!==window.self){window.top.location.href=window.location.href;}}catch(e){/* noop */}})();</script>\n";
    }
}, 100);

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'callback' => function (\WP_REST_Request $req) {
            $order_id  = (int) $req->get_param('order_id');
            $order_key = (string) $req->get_param('order_key');

            if ($order_id <= 0 || $order_key === '') {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'missing_params'), 400);
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'order_not_found'), 404);
            }

            if (!hash_equals((string) $order->get_order_key(), $order_key)) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_key'), 403);
            }

            $status = (string) $order->get_status();
            $paid   = in_array($status, array('processing', 'completed'), true);

            return new \WP_REST_Response(array(
                'ok'       => true,
                'status'   => $status,
                'paid'     => $paid,
                'thankyou' => esc_url_raw($order->get_checkout_order_received_url()),
            ), 200);
        },
        'permission_callback' => '__return_true',
        'args' => array(
            'order_id' => array('required' => true),
            'order_key' => array('required' => true),
        ),
    ));
});

// Ensure order-status polling is never cached by page caches, reverse proxies or browser caches.
add_filter('rest_post_dispatch', function ($result, $server, $request) {
    if (!($request instanceof WP_REST_Request)) {
        return $result;
    }

    if ($request->get_route() !== '/bonzai/v1/order-status') {
        return $result;
    }

    if ($result instanceof WP_REST_Response) {
        $result->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $result->header('Pragma', 'no-cache');
    }

    return $result;
}, 10, 3);

// WooCommerce AJAX endpoint to fetch the last Bonzai embed URL stored in the session.
add_action('wc_ajax_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
add_action('wc_ajax_nopriv_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
function bonzai_wc_ajax_popup_session() {
    // Prevent reverse proxies / cache plugins from caching session-specific responses.
    if (function_exists('nocache_headers')) {
        nocache_headers();
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    if (!function_exists('WC') || !WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'));
    }
    if (!bonzai_verify_ajax_request_token()) {
        wp_send_json(array('ok' => false, 'error' => 'invalid_ajax_token'), 403);
    }

    $embed_url = WC()->session->get('bonzai_popup_iframe_url');
    $thankyou  = WC()->session->get('bonzai_popup_thankyou');
    $order_id  = WC()->session->get('bonzai_popup_order_id');
    $engine    = (string) WC()->session->get('bonzai_payment_engine');
    $inflow_public_key = (string) WC()->session->get('bonzai_inflow_public_key');
    $inflow_payment_id = (string) WC()->session->get('bonzai_inflow_payment_id');

    // Backward-compat fallback (older keys).
    if (empty($embed_url)) {
        $embed_url = WC()->session->get('bonzai_last_embed_url');
    }
    if (empty($thankyou)) {
        $thankyou = WC()->session->get('bonzai_last_thankyou');
    }
    if (empty($order_id)) {
        $order_id = WC()->session->get('bonzai_last_order_id');
    }
    if ($engine === '' && $order_id) {
        $order = wc_get_order((int) $order_id);
        if ($order) {
            $engine = (string) $order->get_meta('_bonzai_payment_engine', true);
            if ($inflow_public_key === '') {
                $inflow_public_key = (string) $order->get_meta('_bonzai_inflow_public_key', true);
            }
            if ($inflow_payment_id === '') {
                $inflow_payment_id = (string) $order->get_meta('_bonzai_inflow_payment_id', true);
            }
        }
    }
    if ($engine === '') {
        $engine = 'iframe_legacy';
    }
    if (empty($embed_url)) {
        if ($engine === 'inflow_sdk' && $inflow_public_key !== '' && $inflow_payment_id !== '') {
            wp_send_json(array(
                'ok' => true,
                'order_id' => (int) $order_id,
                'engine' => 'inflow_sdk',
                'inflowpay_public_key' => $inflow_public_key,
                'inflowpay_payment_id' => $inflow_payment_id,
                'thankyou' => esc_url_raw($thankyou),
            ));
        }
        wp_send_json(array('ok' => false, 'error' => 'no_embed_url'));
    }

    $response = array(
        'ok'        => true,
        'order_id'  => (int) $order_id,
        'engine'    => $engine,
        'embed_url' => esc_url_raw($embed_url),
        'thankyou'  => esc_url_raw($thankyou),
    );
    if ($engine === 'inflow_sdk' && $inflow_public_key !== '' && $inflow_payment_id !== '') {
        $response['inflowpay_public_key'] = $inflow_public_key;
        $response['inflowpay_payment_id'] = $inflow_payment_id;
    }
    wp_send_json($response);
}

// Inline embed mode: prepare (or reuse) a Bonzai checkout session WITHOUT requiring the customer
// to click the WooCommerce "Place order" button.
//
// This endpoint will:
//  - parse the checkout form fields,
//  - create (or reuse) a pending WooCommerce order linked to the current cart,
//  - call Bonzai /checkout to obtain embed_url,
//  - store embed_url + order info in the WC session for the front-end.
add_action('wc_ajax_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
add_action('wc_ajax_nopriv_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
function bonzai_wc_ajax_inline_prepare() {
    // Prevent reverse proxies / cache plugins from caching session-specific responses.
    if (function_exists('nocache_headers')) {
        nocache_headers();
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    $force_new = isset($_POST['force_new']) && (int) wp_unslash($_POST['force_new']) === 1;
    if ($force_new && function_exists('WC') && WC() && WC()->session) {
    WC()->session->__unset('bonzai_popup_iframe_url');
    WC()->session->__unset('bonzai_popup_thankyou');
    WC()->session->__unset('bonzai_popup_order_id');
    WC()->session->__unset('bonzai_popup_order_key');
    }
    if (!function_exists('WC') || !WC() || !WC()->cart) {
        wp_send_json(array('ok' => false, 'error' => 'woocommerce_unavailable'), 500);
    }
    if (!WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'), 500);
    }
    if (!bonzai_verify_ajax_request_token()) {
        wp_send_json(array('ok' => false, 'error' => 'invalid_ajax_token'), 403);
    }

    $gateway = bonzai_get_gateway_instance();
    if (!$gateway || !is_object($gateway) || !method_exists($gateway, 'get_option')) {
        wp_send_json(array('ok' => false, 'error' => 'gateway_unavailable'), 500);
    }

    // Only operate in inline iframe mode.
    $inline_on = ($gateway->get_option('inline_iframe', 'no') === 'yes');
    if (!$inline_on) {
        wp_send_json(array('ok' => false, 'error' => 'inline_disabled'), 400);
    }

    $force_new = false;
    if (isset($_POST['force_new'])) {
        $force_new = ((int) wp_unslash($_POST['force_new'])) === 1;
    }

    // If explicitly requested, drop any previously prepared session/order linkage so we create a fresh payment.
    if ($force_new) {
        WC()->session->set('bonzai_inline_fp', '');
        WC()->session->set('bonzai_popup_iframe_url', '');
        WC()->session->set('bonzai_inline_wc_order_id', 0);
        WC()->session->set('bonzai_inline_wc_order_key', '');
    }

    $raw = '';
    if (isset($_POST['checkout_data'])) {
        $raw = (string) wp_unslash($_POST['checkout_data']);
    }

    $posted = array();
    if ($raw !== '') {
        wp_parse_str($raw, $posted);
    }

    // Checkout Blocks compatibility: there is no classic checkout form serialization.
    // Allow key fields to be sent directly.
    if (empty($posted) || (!isset($posted['billing_email']) && isset($_POST['billing_email']))) {
        foreach (array(
            'billing_email',
            'billing_first_name',
            'billing_last_name',
            'billing_postcode',
            'billing_address_1',
            'billing_city',
            'billing_country',
            'billing_state',
            'terms'
        ) as $k) {
            if (isset($_POST[$k]) && !isset($posted[$k])) {
                $posted[$k] = (string) wp_unslash($_POST[$k]);
            }
        }
    }

    // Ensure payment method is set to Bonzai for the created order.
    $posted['payment_method'] = 'bonzai';

    $email = '';
    if (isset($posted['billing_email'])) {
        $email = sanitize_email((string) $posted['billing_email']);
    }
    if (!$email || !is_email($email)) {
        wp_send_json(array('ok' => false, 'error' => 'missing_email'), 400);
    }

    $first = isset($posted['billing_first_name']) ? sanitize_text_field((string) $posted['billing_first_name']) : '';
    $last  = isset($posted['billing_last_name']) ? sanitize_text_field((string) $posted['billing_last_name']) : '';
    $postcode = isset($posted['billing_postcode']) ? sanitize_text_field((string) $posted['billing_postcode']) : '';
    $address1 = isset($posted['billing_address_1']) ? sanitize_text_field((string) $posted['billing_address_1']) : '';
    $city = isset($posted['billing_city']) ? sanitize_text_field((string) $posted['billing_city']) : '';
    $country = isset($posted['billing_country']) ? sanitize_text_field((string) $posted['billing_country']) : '';
    $country = strtoupper((string) preg_replace('/[^A-Za-z]/', '', $country));
    if (strlen($country) > 2) {
        $country = substr($country, 0, 2);
    }
    if ($country === '' && function_exists('WC') && WC() && WC()->customer && method_exists(WC()->customer, 'get_billing_country')) {
        $country = strtoupper((string) preg_replace('/[^A-Za-z]/', (string) WC()->customer->get_billing_country()));
    }
    if ($country === '' && function_exists('WC') && WC() && WC()->countries && method_exists(WC()->countries, 'get_base_country')) {
        $country = strtoupper((string) preg_replace('/[^A-Za-z]/', (string) WC()->countries->get_base_country()));
    }
    if (strlen($country) > 2) {
        $country = substr($country, 0, 2);
    }
    $state = isset($posted['billing_state']) ? sanitize_text_field((string) $posted['billing_state']) : '';

    // Enforce required checkout fields for Bonzai.
    // IMPORTANT: Not all countries require a state/region (e.g. FR). We only require it when
    // WooCommerce defines states for the selected country.
    $needs_state = false;
    if ($country && function_exists('WC') && WC()->countries && method_exists(WC()->countries, 'get_states')) {
        $states = WC()->countries->get_states($country);
        $needs_state = !empty($states);
    }

    if ($first === '' || $last === '' || $address1 === '' || $postcode === '' || $city === '' || $country === '' || ($needs_state && $state === '')) {
        wp_send_json(array('ok' => false, 'error' => 'missing_required_fields'), 400);
    }

    // Enforce Terms & Conditions acceptance only if the store requires it.
    // Some stores don't show the checkbox at all (or disable it). In that case we must not block.
    $terms_required = false;
    if (function_exists('wc_terms_and_conditions_checkbox_enabled')) {
        $terms_required = (bool) wc_terms_and_conditions_checkbox_enabled();
    } else {
        // Best-effort fallback for older WC: require only if a terms page exists.
        if (function_exists('wc_get_page_id')) {
            $terms_required = (wc_get_page_id('terms') > 0);
        } else {
            $terms_required = false;
        }
    }

    if ($terms_required) {
        // WooCommerce classic usually sends terms=on. Blocks may send 1/true.
        $terms_ok = false;
        if (isset($posted['terms'])) {
            $t = (string) $posted['terms'];
            $terms_ok = in_array($t, array('1', 'true', 'on', 'yes'), true);
        }
        if (!$terms_ok) {
            wp_send_json(array('ok' => false, 'error' => 'missing_terms'), 400);
        }
    }

    $cart_hash = is_callable(array(WC()->cart, 'get_cart_hash')) ? (string) WC()->cart->get_cart_hash() : '';
    $total     = (float) WC()->cart->get_total('edit');
    $currency  = get_woocommerce_currency();
    $force_currency = strtoupper(trim((string) $gateway->get_option('force_currency', '')));
    $target_currency = $force_currency ? $force_currency : $currency;
    if (!in_array($target_currency, array('EUR', 'USD'), true)) {
        $target_currency = 'EUR';
    }

    $fingerprint = md5(wp_json_encode(array(
        'cart' => $cart_hash,
        'email' => $email,
        'first' => $first,
        'last' => $last,
        'country' => $country,
        'postcode' => $postcode,
        'total' => round($total, 2),
        'currency' => $target_currency,
    )));

    bonzai_log_event('info', 'inline_prepare:start', array(
        'force_new' => $force_new ? 1 : 0,
        'cart_hash' => $cart_hash,
        'email_hash' => substr(hash('sha256', strtolower((string) $email)), 0, 12),
        'currency' => $target_currency,
        'engine_requested' => bonzai_payment_engine($gateway),
    ), $gateway);

    // Reuse an existing prepared session if it matches the current fingerprint.
    $prev_fp = (string) WC()->session->get('bonzai_inline_fp');
    $prev_embed = (string) WC()->session->get('bonzai_popup_iframe_url');
    $prev_engine = (string) WC()->session->get('bonzai_payment_engine');
    $prev_inflow_public_key = (string) WC()->session->get('bonzai_inflow_public_key');
    $prev_inflow_payment_id = (string) WC()->session->get('bonzai_inflow_payment_id');
    $prev_order_id = (int) WC()->session->get('bonzai_inline_wc_order_id');
    $prev_order_key = (string) WC()->session->get('bonzai_inline_wc_order_key');
    $has_reusable_iframe = ($prev_embed !== '');
    $has_reusable_inflow = ($prev_engine === 'inflow_sdk' && $prev_inflow_public_key !== '' && $prev_inflow_payment_id !== '');
    if (!$force_new && $prev_fp && $prev_fp === $fingerprint && ($has_reusable_iframe || $has_reusable_inflow) && $prev_order_id > 0 && $prev_order_key) {
        $reused_order = wc_get_order($prev_order_id);
        $reused_engine = $reused_order ? (string) $reused_order->get_meta('_bonzai_payment_engine', true) : 'iframe_legacy';
        $reused_public_key = $reused_order ? (string) $reused_order->get_meta('_bonzai_inflow_public_key', true) : '';
        $reused_payment_id = $reused_order ? (string) $reused_order->get_meta('_bonzai_inflow_payment_id', true) : '';
        if ($reused_engine === 'inflow_sdk') {
            if ($reused_public_key === '') {
                $reused_public_key = $prev_inflow_public_key;
            }
            if ($reused_payment_id === '') {
                $reused_payment_id = $prev_inflow_payment_id;
            }
        }

        $response = array(
            'ok'        => true,
            'reused'    => true,
            'order_id'  => $prev_order_id,
            'order_key' => $prev_order_key,
            'engine'    => $reused_engine === 'inflow_sdk' ? 'inflow_sdk' : 'iframe_legacy',
            'embed_url' => $prev_embed !== '' ? esc_url_raw($prev_embed) : '',
        );
        if ($reused_engine === 'inflow_sdk' && $reused_public_key !== '' && $reused_payment_id !== '') {
            $response['inflowpay_public_key'] = $reused_public_key;
            $response['inflowpay_payment_id'] = $reused_payment_id;
        }
        bonzai_log_event('info', 'inline_prepare:reused_session', array(
            'woo_order_id' => $prev_order_id,
            'engine' => $response['engine'],
            'has_embed' => !empty($response['embed_url']) ? 1 : 0,
        ), $gateway);
        wp_send_json($response);
    }

    // Create or reuse a pending Woo order tied to the cart.
    $wc_order = null;
    $existing_id = $force_new ? 0 : (int) WC()->session->get('bonzai_inline_wc_order_id');
    if ($existing_id > 0) {
        $candidate = wc_get_order($existing_id);
        if ($candidate && method_exists($candidate, 'get_status')) {
            $status = (string) $candidate->get_status();
            $is_paid = method_exists($candidate, 'is_paid') ? (bool) $candidate->is_paid() : in_array($status, array('processing', 'completed'), true);
            $candidate_cart = (string) $candidate->get_meta('_bonzai_cart_hash', true);
            if (!$is_paid && in_array($status, array('pending', 'failed', 'on-hold'), true) && $candidate_cart === $cart_hash) {
                $wc_order = $candidate;
            }
        }
    }

    if (!$wc_order) {
        try {
            if (!WC()->checkout()) {
                wp_send_json(array('ok' => false, 'error' => 'checkout_unavailable'), 500);
            }
            // create_order adds cart line items automatically.
            $new_id = WC()->checkout()->create_order($posted);
            $wc_order = $new_id ? wc_get_order($new_id) : null;
        } catch (Exception $e) {
            wp_send_json(array('ok' => false, 'error' => 'order_create_failed', 'message' => $e->getMessage()), 400);
        }
    }

    if (!$wc_order) {
        wp_send_json(array('ok' => false, 'error' => 'order_not_created'), 500);
    }

    // Update billing fields on the reused order (or the new one).
    if (method_exists($wc_order, 'set_billing_email')) $wc_order->set_billing_email($email);
    if (method_exists($wc_order, 'set_billing_first_name')) $wc_order->set_billing_first_name($first);
    if (method_exists($wc_order, 'set_billing_last_name')) $wc_order->set_billing_last_name($last);
    if (method_exists($wc_order, 'set_billing_postcode')) $wc_order->set_billing_postcode($postcode);
    if ($country !== '' && method_exists($wc_order, 'set_billing_country')) $wc_order->set_billing_country($country);
    $wc_order->update_meta_data('_bonzai_cart_hash', $cart_hash);
    $wc_order->save();

    // Call Bonzai to create a checkout session.
    $api_token = trim((string) $gateway->get_option('api_token'));
    $product_uuid = trim((string) $gateway->get_option('product_uuid'));
    if ($api_token === '' || $product_uuid === '') {
        wp_send_json(array('ok' => false, 'error' => 'missing_settings'), 500);
    }

    $amount = (float) $wc_order->get_total();
    if ($amount <= 0) {
        wp_send_json(array('ok' => false, 'error' => 'invalid_amount'), 400);
    }

    // Always rely on WooCommerce's native return URL (order received page).
    // Add wc_order for our redirect bridge / iframe-safe navigation logic.
    $redirect_url = add_query_arg(
        array('wc_order' => $wc_order->get_id()),
        $wc_order->get_checkout_order_received_url()
    );

    $is_vat_incl = ((string) $gateway->get_option('is_vat_incl_default', 'yes') === 'yes');

    $bonzai_title = 'WooCommerce Order #' . $wc_order->get_order_number();
    $items = $wc_order->get_items('line_item');
    if (is_array($items) && !empty($items)) {
        foreach ($items as $item) {
            $bonzai_title = (string) $item->get_name();
            break;
        }
    }

    $payload = array(
        'amount'       => round($amount, 2),
        'currency'     => $target_currency,
        'title'        => $bonzai_title,
        'redirect_url' => $redirect_url,
        'metadata'     => array(
            'wc_order_id' => $wc_order->get_id(),
            'site'        => home_url(),
        ),
        'is_vat_incl'  => (bool) $is_vat_incl,
        'mode'         => 'one_off',
        'email'        => $email,
    );

    if ($first !== '') $payload['firstname'] = $first;
    if ($last !== '')  $payload['lastname']  = $last;
    if ($postcode !== '') $payload['postal_code'] = $postcode;
    if ($country !== '') $payload['country'] = $country;

    if (method_exists($gateway, 'log')) {
        // noop: keep compatibility if gateway has log method in future.
    }

    bonzai_log_event('info', 'inline_prepare:checkout_request', array(
        'woo_order_id' => (int) $wc_order->get_id(),
        'payload_keys' => implode(',', array_keys($payload)),
        'has_firstname' => isset($payload['firstname']) ? 1 : 0,
        'has_lastname' => isset($payload['lastname']) ? 1 : 0,
        'has_postal_code' => isset($payload['postal_code']) ? 1 : 0,
        'country' => (string) ($payload['country'] ?? ''),
    ), $gateway);

    $resp = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type'  => 'application/json',
        ),
        'body'    => wp_json_encode($payload),
        'timeout' => 20,
    ));

    if (is_wp_error($resp)) {
        bonzai_log_event('error', 'inline_prepare:checkout_request_failed', array(
            'woo_order_id' => (int) $wc_order->get_id(),
            'error' => $resp->get_error_message(),
            'product_uuid' => $product_uuid,
        ), $gateway, true);
        wp_send_json(array('ok' => false, 'error' => 'bonzai_api_error', 'message' => $resp->get_error_message()), 502);
    }

    $http = (int) wp_remote_retrieve_response_code($resp);
    $body_txt = (string) wp_remote_retrieve_body($resp);
    $body = json_decode($body_txt, true);
    if (!is_array($body)) {
        $body = array();
    }

    $embed_url = !empty($body['embed_url']) ? bonzai_sanitize_checkout_url((string) $body['embed_url']) : '';
    $checkout_url = !empty($body['checkout_url']) ? bonzai_sanitize_checkout_url((string) $body['checkout_url']) : '';
    $has_iframe_target = ($embed_url !== '' || $checkout_url !== '');
    $bonzai_order_id = bonzai_extract_bonzai_order_id($body);
    $squidpay_order_id = bonzai_extract_squidpay_order_id($body);
    $start_order_id = bonzai_extract_checkout_order_id($body);
    bonzai_log_event('info', 'inline_prepare:checkout_response', array(
        'woo_order_id' => (int) $wc_order->get_id(),
        'http' => $http,
        'bonzai_order_id' => $bonzai_order_id,
        'squidpay_order_id' => $squidpay_order_id,
        'start_order_id' => $start_order_id,
        'has_embed' => $embed_url !== '' ? 1 : 0,
        'has_checkout' => $checkout_url !== '' ? 1 : 0,
    ), $gateway);
    if ($http < 200 || $http >= 300 || (!$has_iframe_target && $start_order_id === '')) {
        bonzai_log_event('error', 'inline_prepare:checkout_bad_response', array(
            'woo_order_id' => (int) $wc_order->get_id(),
            'http' => $http,
            'start_order_id' => $start_order_id,
            'body_status' => is_array($body) ? (string) ($body['status'] ?? '') : '',
            'body_keys' => is_array($body) ? implode(',', array_keys($body)) : '',
        ), $gateway, true);
        wp_send_json(array('ok' => false, 'error' => 'bonzai_bad_response', 'http' => $http, 'body' => $body), 502);
    }

    $iframe_url = $has_iframe_target ? ($embed_url !== '' ? $embed_url : $checkout_url) : '';
    $requested_engine = bonzai_payment_engine($gateway);
    $active_engine = 'iframe_legacy';
    $inflow_public_key = '';
    $inflow_payment_id = '';
    $start_first = $first !== '' ? $first : (method_exists($wc_order, 'get_billing_first_name') ? (string) $wc_order->get_billing_first_name() : '');
    $start_last = $last !== '' ? $last : (method_exists($wc_order, 'get_billing_last_name') ? (string) $wc_order->get_billing_last_name() : '');
    $start_country = $country !== '' ? $country : (method_exists($wc_order, 'get_billing_country') ? (string) $wc_order->get_billing_country() : '');
    $start_country = strtoupper((string) preg_replace('/[^A-Za-z]/', '', $start_country));
    if (strlen($start_country) > 2) {
        $start_country = substr($start_country, 0, 2);
    }

    if ($requested_engine === 'inflow_sdk') {
        if ($start_order_id !== '') {
            bonzai_log_event('info', 'inline_prepare:inflow_start_attempt', array(
                'woo_order_id' => (int) $wc_order->get_id(),
                'start_order_id' => $start_order_id,
                'billing_country' => $start_country,
                'has_firstname' => $start_first !== '' ? 1 : 0,
                'has_lastname' => $start_last !== '' ? 1 : 0,
            ), $gateway);
            $start = bonzai_api_start_order($start_order_id, $gateway);
            if (!is_wp_error($start)) {
                $active_engine = 'inflow_sdk';
                $inflow_public_key = (string) ($start['inflowpay_public_key'] ?? '');
                $inflow_payment_id = (string) ($start['inflowpay_payment_id'] ?? '');
                bonzai_log_event('info', 'inline_prepare:inflow_start_success', array(
                    'woo_order_id' => (int) $wc_order->get_id(),
                    'start_order_id' => $start_order_id,
                ), $gateway);
            } else {
                $can_fallback_iframe = bonzai_inflow_fallback_iframe($gateway) && $has_iframe_target;
                if (!$can_fallback_iframe) {
                    $wc_order->add_order_note('Bonzai Inflow start failed (no fallback). start_order_id: ' . $start_order_id . ', bonzai_order_id: ' . ($bonzai_order_id ?: 'n/a') . ', squidpay_order_id: ' . ($squidpay_order_id ?: 'n/a') . '. Error: ' . $start->get_error_message());
                    bonzai_log_event('error', 'inline_prepare:inflow_start_failed_no_fallback', array(
                        'woo_order_id' => (int) $wc_order->get_id(),
                        'start_order_id' => $start_order_id,
                        'bonzai_order_id' => $bonzai_order_id,
                        'squidpay_order_id' => $squidpay_order_id,
                        'error' => $start->get_error_message(),
                        'error_data' => is_array($start->get_error_data()) ? $start->get_error_data() : array(),
                    ), $gateway, true);
                    wp_send_json(array(
                        'ok' => false,
                        'error' => 'inflow_start_failed',
                        'message' => $start->get_error_message(),
                    ), 502);
                }
                $wc_order->add_order_note('Bonzai Inflow start failed. Falling back to iframe. Error: ' . $start->get_error_message());
                bonzai_log_event('warning', 'inline_prepare:inflow_start_failed_fallback_to_iframe', array(
                    'woo_order_id' => (int) $wc_order->get_id(),
                    'start_order_id' => $start_order_id,
                    'error' => $start->get_error_message(),
                ), $gateway, true);
            }
        } elseif (!bonzai_inflow_fallback_iframe($gateway) || !$has_iframe_target) {
            $wc_order->add_order_note('Bonzai Inflow start skipped: missing start_order_id (squidpay_order_id/order_id) and no iframe fallback target.');
            bonzai_log_event('error', 'inline_prepare:inflow_start_skipped_missing_start_order_id', array(
                'woo_order_id' => (int) $wc_order->get_id(),
                'bonzai_order_id' => $bonzai_order_id,
                'squidpay_order_id' => $squidpay_order_id,
                'has_iframe_target' => $has_iframe_target ? 1 : 0,
            ), $gateway, true);
            wp_send_json(array(
                'ok' => false,
                'error' => 'inflow_start_failed',
                'message' => 'Missing start_order_id for inflow start.',
            ), 502);
        }
    }

    // Persist linkage on the order.
    if ($bonzai_order_id !== '') {
        $wc_order->update_meta_data('_bonzai_order_id', $bonzai_order_id);
    } elseif ($start_order_id !== '') {
        // Backward compatibility if Bonzai no longer returns order_id.
        $wc_order->update_meta_data('_bonzai_order_id', $start_order_id);
    }
    if ($squidpay_order_id !== '') {
        $wc_order->update_meta_data('_bonzai_squidpay_order_id', $squidpay_order_id);
    } else {
        $wc_order->delete_meta_data('_bonzai_squidpay_order_id');
    }
    if ($checkout_url !== '') {
        $wc_order->update_meta_data('_bonzai_checkout_url', esc_url_raw($checkout_url));
    }
    if ($embed_url !== '') {
        $wc_order->update_meta_data('_bonzai_embed_url', esc_url_raw($embed_url));
    }

    // Extra linkage for webhook reconciliation: Bonzai webhooks do not include order_id.
    // We store the Bonzai product UUID and buyer email so we can reliably map access events to this WC order.
    if (!empty($product_uuid)) {
        $wc_order->update_meta_data('_bonzai_product_uuid', sanitize_text_field((string) $product_uuid));
    }
    if (!empty($email)) {
        $wc_order->update_meta_data('_bonzai_buyer_email', sanitize_email((string) $email));
    }
    $wc_order->update_meta_data('_bonzai_payment_engine_requested', $requested_engine);
    $wc_order->update_meta_data('_bonzai_payment_engine', $active_engine);
    if ($active_engine === 'inflow_sdk') {
        $wc_order->update_meta_data('_bonzai_inflow_public_key', $inflow_public_key);
        $wc_order->update_meta_data('_bonzai_inflow_payment_id', $inflow_payment_id);
    } else {
        $wc_order->delete_meta_data('_bonzai_inflow_public_key');
        $wc_order->delete_meta_data('_bonzai_inflow_payment_id');
    }

    $wc_order->save();

    // Store for the frontend.
    WC()->session->set('bonzai_inline_fp', $fingerprint);
    WC()->session->set('bonzai_inline_wc_order_id', (int) $wc_order->get_id());
    WC()->session->set('bonzai_inline_wc_order_key', (string) $wc_order->get_order_key());
    WC()->session->set('bonzai_popup_iframe_url', $iframe_url ? esc_url_raw($iframe_url) : '');
    WC()->session->set('bonzai_popup_checkout_url', $checkout_url ? esc_url_raw($checkout_url) : '');
    WC()->session->set('bonzai_popup_thankyou', esc_url_raw($wc_order->get_checkout_order_received_url()));
    WC()->session->set('bonzai_popup_order_id', (int) $wc_order->get_id());
    WC()->session->set('bonzai_payment_engine', $active_engine);
    WC()->session->set('bonzai_inflow_public_key', $inflow_public_key);
    WC()->session->set('bonzai_inflow_payment_id', $inflow_payment_id);

    $response = array(
        'ok'        => true,
        'reused'    => false,
        'order_id'  => (int) $wc_order->get_id(),
        'order_key' => (string) $wc_order->get_order_key(),
        'engine'    => $active_engine,
        'embed_url' => $iframe_url ? esc_url_raw($iframe_url) : '',
        'checkout_url' => $checkout_url ? esc_url_raw($checkout_url) : '',
    );
    if ($active_engine === 'inflow_sdk') {
        $response['inflowpay_public_key'] = $inflow_public_key;
        $response['inflowpay_payment_id'] = $inflow_payment_id;
    }
    bonzai_log_event('info', 'inline_prepare:success', array(
        'woo_order_id' => (int) $wc_order->get_id(),
        'engine' => $active_engine,
        'reused' => 0,
    ), $gateway);
    wp_send_json($response);
}

add_action('init', 'bonzai_gateway_add_rewrite_rules');

function bonzai_gateway_add_rewrite_rules() {
    $popup_base = 'bonzai/popup';
    $popup_base = ltrim($popup_base, '/');

    // Accept alnum, underscore, and hyphen in order key.
    add_rewrite_rule('^' . preg_quote($popup_base, '/') . '/([0-9]+)/([a-zA-Z0-9_\-]+)/?$', 'index.php?bonzai_popup=1&bonzai_order_id=$matches[1]&bonzai_order_key=$matches[2]', 'top');
}

add_filter('query_vars', function($vars) {
    $vars[] = 'bonzai_popup';
    $vars[] = 'bonzai_order_id';
    $vars[] = 'bonzai_order_key';
    return $vars;
});

add_action('template_redirect', function() {
    if (get_query_var('bonzai_popup')) {
        bonzai_render_popup_page();
        exit;
    }
});

/**
 * Renders the popup page. It loads the Bonzai embed URL inside an iframe.
 * If embed URL is missing, it falls back to checkout URL.
 */
function bonzai_render_popup_page() {
    if (!function_exists('wc_get_order')) {
        status_header(500);
        echo 'WooCommerce not available.';
        return;
    }

    // Prevent WP canonical redirects from altering signed URLs.
    remove_filter('template_redirect', 'redirect_canonical');

    $order_id  = absint(get_query_var('bonzai_order_id'));
    $order_key = (string) get_query_var('bonzai_order_key');

    $order = $order_id ? wc_get_order($order_id) : null;
    if (!$order) {
        status_header(404);
        echo 'Invalid WooCommerce order.';
        return;
    }

    if (!$order_key || $order_key !== $order->get_order_key()) {
        status_header(403);
        echo 'Invalid order key.';
        return;
    }

    $embed_url    = bonzai_sanitize_checkout_url((string) $order->get_meta('_bonzai_embed_url', true));
    $checkout_url = bonzai_sanitize_checkout_url((string) $order->get_meta('_bonzai_checkout_url', true));

    $target_url = $embed_url ? $embed_url : $checkout_url;
    if (!$target_url) {
        status_header(400);
        echo 'Missing Bonzai checkout URL.';
        return;
    }

    // Security: only allow bonzai.pro and subdomains.
    $extracted = bonzai_extract_bonzai_target($target_url);
    if (!$extracted) {
        status_header(400);
        echo 'Invalid Bonzai checkout URL.';
        return;
    }

    $iframe_src = esc_url($target_url);

    header('Content-Type: text/html; charset=utf-8');
    ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Secure payment</title>
  <style>
    html, body { height: 100%; margin: 0; padding: 0; background: #0b0f14; font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif; }
    .bz-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.72); display: flex; align-items: center; justify-content: center; z-index: 999999; }
    .bz-modal { width: min(1100px, 96vw); height: min(760px, 92vh); background: #0b0f14; border-radius: 12px; overflow: hidden; box-shadow: 0 12px 48px rgba(0,0,0,0.55); position: relative; }
    .bz-topbar { height: 44px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; background: rgba(255,255,255,0.06); color: #fff; }
    .bz-topbar .title { font-size: 14px; opacity: 0.9; }
    .bz-close { background: rgba(255,255,255,0.12); border: 0; color: #fff; padding: 8px 10px; border-radius: 8px; cursor: pointer; }
    .bz-frame { width: 100%; height: calc(100% - 44px); border: 0; display: block; background: #fff; }
    .bz-fallback { position: fixed; inset: 0; display:none; align-items:center; justify-content:center; color:#fff; padding:24px; text-align:center; }
    .bz-fallback a { color: #fff; text-decoration: underline; }
  </style>
</head>
<body>
  <div class="bz-backdrop" id="bz_backdrop">
    <div class="bz-modal">
      <div class="bz-topbar">
        <div class="title">Paiement sécurisé</div>
        <button class="bz-close" type="button" id="bz_close">Fermer</button>
      </div>
      <iframe class="bz-frame" id="bz_iframe" src="<?php echo $iframe_src; ?>" allow="payment *; fullscreen *" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>

  <div class="bz-fallback" id="bz_fallback">
    <div>
      <div style="font-size:18px; margin-bottom:8px;">Fenêtre de paiement fermée</div>
      <div style="opacity:0.85; margin-bottom:18px;">Vous pouvez réessayer ou revenir à la boutique.</div>
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>">Retour</a>
      </div>
    </div>
  </div>

  <script>
    (function(){
      var closeBtn = document.getElementById('bz_close');
      var backdrop = document.getElementById('bz_backdrop');
      var fallback = document.getElementById('bz_fallback');

      function closeModal(){
        backdrop.style.display = 'none';
        fallback.style.display = 'flex';
      }

      closeBtn.addEventListener('click', function(){ closeModal(); });

      document.addEventListener('keydown', function(e){
        if (e && e.key === 'Escape') closeModal();
      });
    })();
  </script>
</body>
</html>
<?php
}

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            if (!function_exists('wc_get_order')) {
                return new WP_REST_Response(array('error' => 'woocommerce_unavailable'), 500);
            }

            $order_id  = absint($request->get_param('order_id'));
            $order_key = sanitize_text_field((string) $request->get_param('order_key'));

            $order = wc_get_order($order_id);
            if (!$order || !$order_key || !hash_equals($order->get_order_key(), $order_key)) {
                return new WP_REST_Response(array('paid' => false, 'valid' => false), 200);
            }

            $status = $order->get_status();
            $paid = in_array($status, array('processing', 'completed'), true);

            return new WP_REST_Response(array(
                'valid'       => true,
                'paid'        => $paid,
                'status'      => $status,
                'thankyou_url' => $paid ? $order->get_checkout_order_received_url() : null,
            ), 200);
        },
    ));
});

function bonzai_rewrite_location($location) {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base . '/');

    $location = (string) $location;

    // Keep the current proxied Bonzai host in redirects so all subsequent requests keep targeting the right subdomain.
    $current_host = 'www.bonzai.pro';
    if (isset($_GET['bh'])) {
        $candidate = strtolower(sanitize_text_field((string) $_GET['bh']));
        // Allow bonzai.pro and any subdomain (e.g. pay.bonzai.pro). Note: '.bonzai.pro' is 11 chars.
        $is_bonzai = ($candidate === 'bonzai.pro') || (substr($candidate, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $current_host = $candidate;
        }
    }

    // Absolute URL to a Bonzai domain: rewrite to our proxy and preserve that host as bh.
    $parts = wp_parse_url($location);
    if (is_array($parts) && !empty($parts['host'])) {
        $h = strtolower((string) $parts['host']);
        // Allow bonzai.pro and any subdomain.
        $is_bonzai = ($h === 'bonzai.pro') || (substr($h, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $p = isset($parts['path']) ? ltrim((string) $parts['path'], '/') : '';
            $q = isset($parts['query']) && $parts['query'] !== '' ? ('?' . (string) $parts['query']) : '';
            $u = $proxy_root . $p . $q;
            return add_query_arg('bh', $h, $u);
        }
    }

    // Relative redirects: keep them inside our proxy and preserve current bh.
    if (strpos($location, '/') === 0) {
        $u = $proxy_root . ltrim($location, '/');
        return add_query_arg('bh', $current_host, $u);
    }

    return $location;
}

function bonzai_rewrite_set_cookie($cookie_line) {
    $cookie_line = (string) $cookie_line;

    // Drop Domain attribute so cookie becomes first party
    $cookie_line = preg_replace('/;\s*Domain=[^;]+/i', '', $cookie_line);

    // Ensure Path is root
    if (stripos($cookie_line, '; path=') === false) {
        $cookie_line .= '; Path=/';
    }

    // Ensure SameSite for modern browsers
    if (stripos($cookie_line, 'samesite=') === false) {
        $cookie_line .= '; SameSite=Lax';
    }

    return $cookie_line;
}

function bonzai_rewrite_body_urls($body, $bonzai_host = 'www.bonzai.pro') {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base);

    // Rewrite any Bonzai absolute URL (any subdomain) to our proxy, while preserving the originating host via bh.
    $body = preg_replace_callback(
        '#https://([a-z0-9.-]*bonzai\.pro)(/[^\"\'\s<]*)?#i',
        function ($m) use ($proxy_root) {
            $host = strtolower($m[1]);
            $path = isset($m[2]) && $m[2] !== '' ? $m[2] : '/';
            $u = $proxy_root . $path;
            return add_query_arg('bh', $host, $u);
        },
        $body
    );

    // Rewrite absolute root paths in common attributes
    $body = preg_replace_callback('/\b(href|src|action)=([\"\'])\/(?!\/)([^\"\']*)\2/i', function($m) use ($proxy_root, $bonzai_host) {
        $u = $proxy_root . '/' . $m[3];
        $u = add_query_arg('bh', $bonzai_host, $u);
        return $m[1] . '=' . $m[2] . $u . $m[2];
    }, $body);

    return $body;
}

function getallheaders_safe() {
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        if (is_array($h)) return $h;
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
        if (strpos($name, 'HTTP_') === 0) {
            $key = str_replace('_', '-', substr($name, 5));
            $headers[$key] = $value;
        }
    }
    return $headers;
}

add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return isset($gws['bonzai']) ? $gws['bonzai'] : null;
}

function bonzai_get_gateway_settings(): array {
    $settings = (array) get_option('woocommerce_bonzai_settings', array());
    return is_array($settings) ? $settings : array();
}

function bonzai_gateway_option($gateway_or_settings, string $key, $default = '') {
    if (is_object($gateway_or_settings) && method_exists($gateway_or_settings, 'get_option')) {
        return $gateway_or_settings->get_option($key, $default);
    }
    if (is_array($gateway_or_settings)) {
        return array_key_exists($key, $gateway_or_settings) ? $gateway_or_settings[$key] : $default;
    }
    return $default;
}

function bonzai_is_debug_enabled($gateway_or_settings = null): bool {
    if (is_object($gateway_or_settings) && method_exists($gateway_or_settings, 'get_option')) {
        return ((string) $gateway_or_settings->get_option('debug', 'no')) === 'yes';
    }
    if (is_array($gateway_or_settings)) {
        return ((string) ($gateway_or_settings['debug'] ?? 'no')) === 'yes';
    }
    $settings = bonzai_get_gateway_settings();
    return ((string) ($settings['debug'] ?? 'no')) === 'yes';
}

function bonzai_log_event(string $level, string $message, array $context = array(), $gateway_or_settings = null, bool $force = false): void {
    if (!function_exists('wc_get_logger')) {
        return;
    }
    $error_levels = array('error', 'warning', 'critical', 'alert', 'emergency');
    $is_error = in_array(strtolower($level), $error_levels, true);
    if (!$force && !$is_error && !bonzai_is_debug_enabled($gateway_or_settings)) {
        return;
    }
    $logger = wc_get_logger();
    $ctx = array_merge(array('source' => 'bonzai_gateway_embed'), $context);
    $logger->log($level, $message, $ctx);
}

function bonzai_get_or_create_ajax_token(): string {
    if (!function_exists('WC') || !WC() || !WC()->session) {
        return '';
    }
    $token = (string) WC()->session->get('bonzai_ajax_token');
    if ($token === '') {
        $token = wp_generate_password(32, false, false);
        WC()->session->set('bonzai_ajax_token', $token);
    }
    return $token;
}

function bonzai_verify_ajax_request_token(): bool {
    $provided = '';
    if (isset($_REQUEST['bonzai_token'])) {
        $provided = sanitize_text_field((string) wp_unslash($_REQUEST['bonzai_token']));
    } elseif (isset($_SERVER['HTTP_X_BONZAI_TOKEN'])) {
        $provided = sanitize_text_field((string) wp_unslash($_SERVER['HTTP_X_BONZAI_TOKEN']));
    }

    if ($provided !== '' && function_exists('WC') && WC() && WC()->session) {
        $expected = bonzai_get_or_create_ajax_token();
        if ($expected !== '' && hash_equals($expected, $provided)) {
            return true;
        }
    }

    // Fallback for cached checkout pages: accept WP REST nonce when explicitly provided.
    $nonce = '';
    if (isset($_REQUEST['bonzai_nonce'])) {
        $nonce = sanitize_text_field((string) wp_unslash($_REQUEST['bonzai_nonce']));
    } elseif (isset($_SERVER['HTTP_X_WP_NONCE'])) {
        $nonce = sanitize_text_field((string) wp_unslash($_SERVER['HTTP_X_WP_NONCE']));
    }
    if ($nonce !== '' && wp_verify_nonce($nonce, 'wp_rest')) {
        return true;
    }

    return false;
}

function bonzai_sanitize_checkout_url(string $url): string {
    $clean = esc_url_raw($url, array('https'));
    if ($clean === '') {
        return '';
    }
    $parts = wp_parse_url($clean);
    if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme']) || strtolower((string) $parts['scheme']) !== 'https') {
        return '';
    }
    return $clean;
}

function bonzai_extract_checkout_order_id(array $body): string {
    $squidpay = bonzai_extract_squidpay_order_id($body);
    if ($squidpay !== '') {
        return $squidpay;
    }
    return bonzai_extract_bonzai_order_id($body);
}

function bonzai_extract_squidpay_order_id(array $body): string {
    $candidates = array(
        $body['squidpay_order_id'] ?? '',
        (is_array($body['order'] ?? null) ? ($body['order']['squidpay_order_id'] ?? '') : ''),
    );

    foreach ($candidates as $candidate) {
        $value = trim((string) sanitize_text_field((string) $candidate));
        if ($value !== '') {
            return $value;
        }
    }
    return '';
}

function bonzai_extract_bonzai_order_id(array $body): string {
    $candidates = array(
        $body['order_id'] ?? '',
        (is_array($body['order'] ?? null) ? ($body['order']['id'] ?? '') : ''),
        (is_array($body['order'] ?? null) ? ($body['order']['order_id'] ?? '') : ''),
    );

    foreach ($candidates as $candidate) {
        $value = trim((string) sanitize_text_field((string) $candidate));
        if ($value !== '') {
            return $value;
        }
    }
    return '';
}

function bonzai_payment_engine($gateway_or_settings): string {
    $engine = sanitize_key((string) bonzai_gateway_option($gateway_or_settings, 'payment_engine', 'iframe_legacy'));
    if (!in_array($engine, array('iframe_legacy', 'inflow_sdk'), true)) {
        $engine = 'iframe_legacy';
    }
    return $engine;
}

function bonzai_inflow_sdk_script_url($gateway_or_settings): string {
    $fallback = 'https://cdn.jsdelivr.net/npm/@inflow_pay/sdk@latest/dist/sdk.umd.js';
    $raw = trim((string) bonzai_gateway_option(
        $gateway_or_settings,
        'inflow_sdk_script_url',
        $fallback
    ));
    if ($raw === '') {
        $raw = $fallback;
    }
    // Backward compatibility: older default path now returns 404 on jsDelivr.
    if (strpos($raw, '@inflow_pay/sdk') !== false) {
        $raw = str_replace('/dist/index.umd.js', '/dist/sdk.umd.js', $raw);
    }
    $url = bonzai_sanitize_checkout_url($raw);
    return $url !== '' ? $url : $fallback;
}

function bonzai_inflow_fallback_iframe($gateway_or_settings): bool {
    return ((string) bonzai_gateway_option($gateway_or_settings, 'inflow_fallback_iframe', 'yes')) === 'yes';
}

function bonzai_inflow_start_base_url($gateway_or_settings): string {
    $fallback = 'https://app.squidpay.io/api/v1';
    $base = trim((string) bonzai_gateway_option($gateway_or_settings, 'inflow_start_base_url', $fallback));
    if ($base === '') {
        $base = $fallback;
    }
    $parts = wp_parse_url($base);
    if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme']) || strtolower((string) $parts['scheme']) !== 'https') {
        $base = $fallback;
    }
    return untrailingslashit($base);
}

function bonzai_inflow_extract_error_message(array $json): string {
    $candidates = array(
        $json['message'] ?? '',
        $json['error'] ?? '',
        $json['detail'] ?? '',
        (is_array($json['data'] ?? null) ? ($json['data']['message'] ?? '') : ''),
        (is_array($json['data'] ?? null) ? ($json['data']['error'] ?? '') : ''),
        (is_array($json['meta'] ?? null) ? ($json['meta']['message'] ?? '') : ''),
    );
    foreach ($candidates as $candidate) {
        $msg = trim((string) $candidate);
        if ($msg !== '') {
            return sanitize_text_field($msg);
        }
    }
    return '';
}

function bonzai_inflow_response_preview(string $txt, array $json): string {
    if (!empty($json)) {
        $encoded = wp_json_encode($json);
        if (is_string($encoded) && $encoded !== '') {
            $txt = $encoded;
        }
    }
    $clean = trim((string) wp_strip_all_tags($txt));
    if ($clean === '') {
        return '';
    }
    if (strlen($clean) > 300) {
        $clean = substr($clean, 0, 300) . '...';
    }
    return $clean;
}

function bonzai_api_start_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_inflow_missing_order_id', 'Missing Bonzai order id');
    }

    $api_token = trim((string) bonzai_gateway_option($gateway, 'api_token', ''));
    if ($api_token === '') {
        return new WP_Error('bonzai_inflow_missing_token', 'Missing API token');
    }

    $url = bonzai_inflow_start_base_url($gateway) . '/order/' . rawurlencode($bonzai_order_id) . '/start';
    $timeout = max(5, (int) bonzai_gateway_option($gateway, 'timeout', 20));
    $max_attempts = 3;

    for ($attempt = 1; $attempt <= $max_attempts; $attempt++) {
        bonzai_log_event('info', 'inflow_start:request', array(
            'order_id' => $bonzai_order_id,
            'url' => $url,
            'attempt' => $attempt,
            'payload_keys' => '',
        ), $gateway);

        $resp = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_token,
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
            ),
            // Guillaume (Bonzai) confirmed /start should be called without parameters.
            // We send an empty JSON object, not an empty array.
            'body'    => '{}',
            'timeout' => $timeout,
        ));

        if (is_wp_error($resp)) {
            bonzai_log_event('warning', 'inflow_start:network_error', array(
                'order_id' => $bonzai_order_id,
                'attempt' => $attempt,
                'error' => $resp->get_error_message(),
            ), $gateway, true);
            if ($attempt < $max_attempts) {
                usleep($attempt * 250000);
                continue;
            }
            return new WP_Error('bonzai_inflow_http_error', 'Inflow start network error: ' . $resp->get_error_message(), array(
                'order_id' => $bonzai_order_id,
                'url' => $url,
                'attempts' => $attempt,
            ));
        }

        $http = (int) wp_remote_retrieve_response_code($resp);
        $txt = (string) wp_remote_retrieve_body($resp);
        $json = json_decode($txt, true);
        if (!is_array($json)) {
            $json = array();
        }
        $remote_error = bonzai_inflow_extract_error_message($json);
        $response_keys = !empty($json) ? implode(',', array_keys($json)) : '';
        $response_preview = bonzai_inflow_response_preview($txt, $json);

        bonzai_log_event('info', 'inflow_start:response', array(
            'order_id' => $bonzai_order_id,
            'attempt' => $attempt,
            'http' => $http,
            'status' => (string) ($json['status'] ?? ''),
            'remote_error' => $remote_error,
            'response_keys' => $response_keys,
            'response_preview' => $response_preview,
        ), $gateway);

        if (($http >= 500 || $http === 429) && $attempt < $max_attempts) {
            bonzai_log_event('warning', 'inflow_start:retryable_http', array(
                'order_id' => $bonzai_order_id,
                'attempt' => $attempt,
                'http' => $http,
            ), $gateway, true);
            usleep($attempt * 300000);
            continue;
        }

        if ($http < 200 || $http >= 300) {
            $msg = 'Inflow start failed with HTTP ' . $http . ' (order_id: ' . $bonzai_order_id . ')';
            if ($remote_error !== '') {
                $msg .= ' - ' . $remote_error;
            }
            bonzai_log_event('error', 'inflow_start:http_error', array(
                'order_id' => $bonzai_order_id,
                'attempt' => $attempt,
                'http' => $http,
                'remote_error' => $remote_error,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
            ), $gateway, true);
            return new WP_Error('bonzai_inflow_bad_http', $msg, array(
                'http' => $http,
                'order_id' => $bonzai_order_id,
                'url' => $url,
                'body' => $json,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
                'attempts' => $attempt,
            ));
        }

        $status = strtolower(trim((string) ($json['status'] ?? '')));
        if ($status !== 'success') {
            $msg = 'Inflow start returned a failed status';
            if ($remote_error !== '') {
                $msg .= ': ' . $remote_error;
            } elseif ($response_preview !== '') {
                $msg .= ' - ' . $response_preview;
            }
            bonzai_log_event('error', 'inflow_start:failed_status', array(
                'order_id' => $bonzai_order_id,
                'attempt' => $attempt,
                'http' => $http,
                'status' => $status,
                'remote_error' => $remote_error,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
            ), $gateway, true);
            return new WP_Error('bonzai_inflow_failed', $msg, array(
                'http' => $http,
                'order_id' => $bonzai_order_id,
                'url' => $url,
                'body' => $json,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
                'attempts' => $attempt,
            ));
        }

        $public_key = trim((string) ($json['inflowpay_public_key'] ?? ''));
        $payment_id = trim((string) ($json['inflowpay_payment_id'] ?? ''));
        if ($public_key === '' || $payment_id === '') {
            bonzai_log_event('error', 'inflow_start:missing_fields', array(
                'order_id' => $bonzai_order_id,
                'attempt' => $attempt,
                'http' => $http,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
            ), $gateway, true);
            return new WP_Error('bonzai_inflow_missing_fields', 'Inflow start response missing public key or payment id', array(
                'http' => $http,
                'order_id' => $bonzai_order_id,
                'url' => $url,
                'body' => $json,
                'response_keys' => $response_keys,
                'response_preview' => $response_preview,
                'attempts' => $attempt,
            ));
        }

        bonzai_log_event('info', 'inflow_start:success', array(
            'order_id' => $bonzai_order_id,
            'attempt' => $attempt,
        ), $gateway);

        return array(
            'status' => 'success',
            'inflowpay_public_key' => $public_key,
            'inflowpay_payment_id' => $payment_id,
            'raw' => $json,
        );
    }

    return new WP_Error('bonzai_inflow_unknown', 'Inflow start failed after retries', array(
        'order_id' => $bonzai_order_id,
        'url' => $url,
    ));
}

function bonzai_verify_token(WP_REST_Request $request, $gateway_or_token) {
    $configured = '';

    if (is_string($gateway_or_token)) {
        $configured = trim($gateway_or_token);
    } elseif (is_object($gateway_or_token) && method_exists($gateway_or_token, 'get_option')) {
        $configured = trim((string) $gateway_or_token->get_option('webhook_token'));
    }

    if ($configured === '') return false;

    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

function bonzai_find_wc_order_from_payload(array $evt) {
    // 1) Best case: Bonzai sends back our metadata.
    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    // 2) If a Bonzai order id is provided, match on stored meta.
    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    // 3) Bonzai access webhooks currently do NOT include order_id.
    // We therefore reconcile using (buyer email + product id) against metadata we store at checkout creation.
    $email = strtolower(trim((string) ($evt['user']['email'] ?? '')));
    $product_uuid = (string) ($evt['product']['id'] ?? '');

    if ($email !== '' && $product_uuid !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 5,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold','processing','failed','cancelled','completed'),
            'billing_email' => $email,
            'meta_key'      => '_bonzai_product_uuid',
            'meta_value'    => $product_uuid,
            'return'        => 'objects',
        ));
        foreach ($orders as $o) {
            if (method_exists($o, 'get_payment_method') && $o->get_payment_method() === 'bonzai') {
                return $o;
            }
        }
    }

    // 4) Fallback: email only (less reliable) – pick the most recent Bonzai order for that buyer.
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 10,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold','processing','failed'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        foreach ($orders as $o) {
            if (method_exists($o, 'get_payment_method') && $o->get_payment_method() === 'bonzai') {
                return $o;
            }
        }
    }

    return null;
}

function bonzai_norm_status($v) {
    $v = strtolower(trim((string) $v));
    $v = str_replace(array(' ', '-'), array('_', '_'), $v);
    return $v;
}

function bonzai_webhook_infer_order_state(array $evt) {
    $candidates = array();
    if (isset($evt['intent_status'])) $candidates[] = $evt['intent_status'];
    if (isset($evt['payment_status'])) $candidates[] = $evt['payment_status'];
    if (isset($evt['status'])) $candidates[] = $evt['status'];
    if (isset($evt['order']['intent_status'])) $candidates[] = $evt['order']['intent_status'];
    if (isset($evt['order']['payment_intent_status'])) $candidates[] = $evt['order']['payment_intent_status'];
    if (isset($evt['order']['status'])) $candidates[] = $evt['order']['status'];

    foreach ($candidates as $cand) {
        $s = bonzai_norm_status($cand);
        if ($s === '') continue;
        if (in_array($s, array('paid','succeeded','success','completed','captured','payment_succeeded'), true)) return 'paid';
        if (in_array($s, array('refunded','refund','charged_back','chargeback'), true)) return 'refunded';
        if (in_array($s, array('failed','payment_failed','requires_payment_method','requires_action'), true)) return 'failed';
        if (in_array($s, array('cancelled','canceled','payment_cancelled','payment_canceled'), true)) return 'cancelled';
    }
    return null;
}
function bonzai_handle_webhook(WP_REST_Request $request) {
    // IMPORTANT: REST requests can hit WordPress before WooCommerce initializes payment gateways.
    // Do not hard-depend on a WC gateway instance to validate / process the webhook.
    $gw = bonzai_get_gateway_instance();
    $settings = get_option('woocommerce_bonzai_settings', array());
    $token = isset($settings['webhook_token']) ? (string) $settings['webhook_token'] : '';

    if (!bonzai_verify_token($request, $gw ? $gw : $token)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);
    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    $inferred_state = bonzai_webhook_infer_order_state($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning('[Bonzai] Webhook received without wc_order_id: ' . $raw, array('source'=>'bonzai_gateway'));
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    // Keep an audit trail to debug why an event did/did not update order state.
    $order->add_order_note('Bonzai webhook received: ' . $type . ' (event ' . $event_id . ').');

    switch ($type) {
        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted -> payment confirmed.');
            } else {
                if ($order->get_status() !== 'completed') {
                    $order->update_status('completed', 'Bonzai: product_access_granted -> completed.');
                }
            }
            break;

        case 'product_access_revoked':
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            // Bonzai may send additional event types (e.g. payment succeeded/failed).
            // If we can infer a payment state from the payload, apply it defensively.
            $inferred = $inferred_state;
            if ($inferred === 'paid') {
                if (!$order->is_paid()) {
                    $order->payment_complete();
                    $order->add_order_note('Bonzai: inferred paid from webhook payload -> payment confirmed.');
                } else {
                    if ($order->get_status() !== 'completed') {
                        $order->update_status('completed', 'Bonzai: inferred paid from webhook payload -> completed.');
                    }
                }
            } elseif ($inferred === 'refunded') {
                if ($order->get_status() !== 'refunded') {
                    $order->update_status('refunded', 'Bonzai: inferred refunded from webhook payload.');
                }
            } elseif ($inferred === 'failed') {
                if (!$order->is_paid() && $order->get_status() !== 'failed') {
                    $order->update_status('failed', 'Bonzai: inferred failed from webhook payload.');
                }
            } elseif ($inferred === 'cancelled') {
                if (!$order->is_paid() && $order->get_status() !== 'cancelled') {
                    $order->update_status('cancelled', 'Bonzai: inferred cancelled from webhook payload.');
                }
            } else {
                $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            }
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

/**
 * Safety net: run Bonzai Retrieve Order after the customer returns.
 *
 * Webhooks are the preferred mechanism, but can be delayed or misconfigured.
 * Also, Bonzai may need a short time to finalize the intent/order state right
 * after payment. We therefore attempt an immediate retrieve and schedule a
 * couple of short retries.
 */
function bonzai_try_retrieve_and_sync_order($order_id, $context = 'post_return') {
    $order = wc_get_order((int) $order_id);
    if (!$order) return false;
    if ($order->get_payment_method() !== 'bonzai') return false;

    $gw = bonzai_get_gateway_instance();
    if (!$gw) return false;

    $bonzai_order_id = (string) $order->get_meta('_bonzai_order_id', true);
    if (!$bonzai_order_id) return false;

    $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
    if (is_wp_error($api_order)) {
        $order->add_order_note('Bonzai retrieve (' . $context . ') error: ' . $api_order->get_error_message());
        if (!empty($gw->debug)) {
            $gw->log('Retrieve (' . $context . ') error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
        }
        return false;
    }

    bonzai_store_last_retrieve_payload($order, $api_order);
    bonzai_sync_wc_order_with_bonzai($order, $api_order);
    return true;
}

add_action('bonzai_delayed_retrieve_order', function($order_id, $attempt = 1) {
    $order = wc_get_order((int) $order_id);
    if (!$order || $order->is_paid()) return;
    if ($order->get_payment_method() !== 'bonzai') return;

    $attempt = max(1, (int) $attempt);
    $key = 'bonzai_delayed_retrieve_' . (int) $order_id . '_' . $attempt;
    if (get_transient($key)) return; // avoid duplicate runs
    set_transient($key, 1, MINUTE_IN_SECONDS);

    bonzai_try_retrieve_and_sync_order($order_id, 'retry_' . $attempt);

    // If still not paid, schedule spaced retries (3s, 15s, 60s, 180s, 300s).
    $order = wc_get_order((int) $order_id);
    if ($order && !$order->is_paid()) {
        $delays = array(3, 15, 60, 180, 300);
        if ($attempt < count($delays)) {
            $delay = (int) $delays[$attempt]; // schedule attempt+1
            if (!wp_next_scheduled('bonzai_delayed_retrieve_order', array((int) $order_id, $attempt + 1))) {
                wp_schedule_single_event(time() + $delay, 'bonzai_delayed_retrieve_order', array((int) $order_id, $attempt + 1));
            }
        }
    }
}, 10, 2);

// Trigger the safety-net retrieve when the customer lands on the "order received" page.
add_action('woocommerce_thankyou_bonzai', function($order_id) {
    $order = wc_get_order((int) $order_id);
    if (!$order || $order->is_paid()) return;

    $order->add_order_note('Bonzai: customer returned. Running retrieve order safety check.');
    bonzai_try_retrieve_and_sync_order($order_id, 'post_return');

    // If not paid yet, schedule a couple short retries to avoid race conditions.
    $order = wc_get_order((int) $order_id);
    if ($order && !$order->is_paid()) {
        if (!wp_next_scheduled('bonzai_delayed_retrieve_order', array((int) $order_id, 1))) {
            wp_schedule_single_event(time() + 3, 'bonzai_delayed_retrieve_order', array((int) $order_id, 1));
        }
    }
}, 20, 1);

add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);

add_action('woocommerce_product_options_general_product_data', 'bonzai_product_fields');

function bonzai_product_fields() {
    echo '<div class="options_group">';

    woocommerce_wp_select(array(
        'id'          => 'bonzai_is_vat_incl',
        'label'       => 'Bonzai VAT handling',
        'description' => 'Override Bonzai VAT handling for this product. If Inherit, gateway default is used.',
        'desc_tip'    => true,
        'options'     => array(
            ''     => 'Inherit from gateway setting',
            'yes'  => 'Amount includes VAT',
            'no'   => 'Amount excludes VAT',
        ),
    ));

    woocommerce_wp_select(array(
        'id'          => 'bonzai_payment_mode',
        'label'       => 'Bonzai payment mode',
        'description' => 'Choose how this product should be charged in Bonzai.',
        'desc_tip'    => true,
        'options'     => array(
            ''                     => 'Inherit or auto detect',
            'one_off'              => 'One off payment',
            'subscription_monthly' => 'Subscription monthly',
            'subscription_yearly'  => 'Subscription yearly',
        ),
    ));

    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'bonzai_save_product_fields');

function bonzai_save_product_fields($post_id) {
    if (isset($_POST['bonzai_is_vat_incl'])) {
        $value = wc_clean(wp_unslash($_POST['bonzai_is_vat_incl']));
        if (!in_array($value, array('', 'yes', 'no'), true)) $value = '';
        update_post_meta($post_id, 'bonzai_is_vat_incl', $value);
    }

    if (isset($_POST['bonzai_payment_mode'])) {
        $mode = wc_clean(wp_unslash($_POST['bonzai_payment_mode']));
        if (!in_array($mode, array('', 'one_off', 'subscription_monthly', 'subscription_yearly'), true)) $mode = '';
        update_post_meta($post_id, 'bonzai_payment_mode', $mode);
    }
}

function bonzai_api_retrieve_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_no_order_id', 'Missing Bonzai order_id');
    }

    $api_token = trim($gateway->api_token);
    if ($api_token === '') {
        return new WP_Error('bonzai_no_token', 'Missing Bonzai API token');
    }

    $url = 'https://www.bonzai.pro/api/v1/orders/' . rawurlencode($bonzai_order_id);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ),
        'timeout' => max(5, (int) $gateway->timeout),
    ));

    if (is_wp_error($response)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order error: ' . $response->get_error_message());
        }
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body_txt = (string) wp_remote_retrieve_body($response);
    $body = json_decode($body_txt, true);

    if ($code !== 200 || !is_array($body)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order HTTP ' . $code . ' body=' . $body_txt);
        }
        return new WP_Error('bonzai_bad_response', 'Unexpected response from Bonzai retrieve order', array(
            'code' => $code,
            'body' => $body_txt,
        ));
    }

    return $body;
}

function bonzai_store_last_retrieve_payload(WC_Order $order, array $api_order) {
    // Store retrieve info using order meta API for HPOS compatibility.
    $order->update_meta_data('_bonzai_last_retrieve_payload', wp_json_encode($api_order));
    $order->update_meta_data('_bonzai_last_retrieve_at', current_time('mysql'));
    $order->save();
}

function bonzai_extract_timeline(array $payload) {
    $events = array();

    // 1) If there is a real timeline field, use it (future-proof)
    if (!empty($payload['timeline']) && is_array($payload['timeline'])) {
        foreach ($payload['timeline'] as $ev) {
            if (!is_array($ev)) continue;

            $date = $ev['date'] ?? ($ev['created_at'] ?? '');
            if (!$date) continue;

            $events[] = array(
                'date'    => (string) $date,
                'type'    => (string) ($ev['type'] ?? ($ev['event'] ?? 'event')),
                'message' => (string) ($ev['message'] ?? ($ev['label'] ?? '')),
            );
        }
    }

    // 2) Fallback: build timeline from accesses[]
    if (empty($events) && !empty($payload['accesses']) && is_array($payload['accesses'])) {
        foreach ($payload['accesses'] as $a) {
            if (!is_array($a)) continue;

            $id = isset($a['id']) ? (string) $a['id'] : '';

            if (!empty($a['created_at'])) {
                $events[] = array(
                    'date'    => (string) $a['created_at'],
                    'type'    => 'access',
                    'message' => 'Access created' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['updated_at']) && ($a['updated_at'] !== ($a['created_at'] ?? null))) {
                $events[] = array(
                    'date'    => (string) $a['updated_at'],
                    'type'    => 'access',
                    'message' => 'Access updated' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['deleted_at'])) {
                $events[] = array(
                    'date'    => (string) $a['deleted_at'],
                    'type'    => 'access',
                    'message' => 'Access deleted' . ($id ? " (#$id)" : ''),
                );
            }
        }
    }

    // Sort ASC by date
    usort($events, function($x, $y){
        $dx = strtotime((string)($x['date'] ?? '')) ?: 0;
        $dy = strtotime((string)($y['date'] ?? '')) ?: 0;
        return $dx <=> $dy;
    });

    return $events;
}

function bonzai_render_history_html(array $payload, $bonzai_order_id = '') {
    $has_access = array_key_exists('has_access', $payload) ? ($payload['has_access'] ? 'true' : 'false') : 'null';
    $intent_status = $payload['intent_status'] ?? ($payload['order']['intent_status'] ?? null);
    $subscription_status = $payload['subscription_status'] ?? ($payload['order']['subscription_status'] ?? null);

    $timeline = bonzai_extract_timeline($payload);

    ob_start();
    ?>
    <div style="padding:12px;">
        <div style="margin-bottom:10px;">
            <div><strong>Bonzai order_id:</strong> <?php echo esc_html($bonzai_order_id ?: ''); ?></div>
            <div><strong>has_access:</strong> <?php echo esc_html($has_access); ?></div>
            <div><strong>intent_status:</strong> <?php echo esc_html($intent_status !== null ? (string) $intent_status : 'null'); ?></div>
            <div><strong>subscription_status:</strong> <?php echo esc_html($subscription_status !== null ? (string) $subscription_status : 'null'); ?></div>
        </div>

        <h3 style="margin:0 0 8px 0;">Timeline</h3>

        <?php if (empty($timeline)) : ?>
            <p>No timeline data found in this Retrieve payload. Raw payload is available below.</p>
        <?php else : ?>
            <table class="widefat striped" style="margin-top:8px;">
                <thead>
                    <tr>
                        <th style="width:180px;">Date</th>
                        <th style="width:220px;">Type</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($timeline as $evt) : ?>
                    <tr>
                        <td><?php echo esc_html($evt['date']); ?></td>
                        <td><?php echo esc_html($evt['type']); ?></td>
                        <td><?php echo esc_html($evt['message']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <details style="margin-top:10px;">
            <summary>Raw payload</summary>
            <pre style="white-space:pre-wrap;"><?php echo esc_html(wp_json_encode($payload, JSON_PRETTY_PRINT)); ?></pre>
        </details>
    </div>
    <?php
    return ob_get_clean();
}

function bonzai_sync_wc_order_with_bonzai(WC_Order $order, array $api_order) {

    // Support plusieurs formats de réponse possibles
    $has_access = null;
    if (array_key_exists('has_access', $api_order)) {
        $has_access = (bool) $api_order['has_access'];
    } elseif (isset($api_order['order']) && is_array($api_order['order']) && array_key_exists('has_access', $api_order['order'])) {
        $has_access = (bool) $api_order['order']['has_access'];
    }

    $intent_status = $api_order['intent_status'] ?? ($api_order['order']['intent_status'] ?? null);
    $subscription_status = $api_order['subscription_status'] ?? ($api_order['order']['subscription_status'] ?? null);

    // Normalisation simple
    $intent_status_norm = is_string($intent_status) ? strtolower(trim($intent_status)) : null;
    $subscription_status_norm = is_string($subscription_status) ? strtolower(trim($subscription_status)) : null;

    $order->add_order_note(sprintf(
        'Bonzai sync: intent_status=%s, subscription_status=%s, has_access=%s',
        $intent_status_norm !== null ? $intent_status_norm : 'null',
        $subscription_status_norm !== null ? $subscription_status_norm : 'null',
        $has_access === null ? 'null' : ($has_access ? 'true' : 'false')
    ));

    // Heuristiques d'état de paiement (les valeurs exactes peuvent évoluer côté Bonzai).
    // Objectif: ne JAMAIS annuler une commande juste parce que has_access=false à l'instant T.
    $payment_completed =
        ($intent_status_norm === 'completed')
        || ($intent_status_norm === 'complete')
        || ($intent_status_norm === 'succeeded')
        || ($intent_status_norm === 'paid')
        || ($intent_status_norm === 'payment_completed');

    $payment_refunded =
        ($intent_status_norm === 'refunded')
        || ($intent_status_norm === 'refund')
        || ($intent_status_norm === 'partially_refunded')
        || ($intent_status_norm === 'partial_refund');

    $payment_failed_or_canceled =
        ($intent_status_norm === 'failed')
        || ($intent_status_norm === 'canceled')
        || ($intent_status_norm === 'cancelled')
        || ($intent_status_norm === 'voided');

    // 1) Access actif: on force completed même si c'était refunded
    if ($has_access === true) {
        if ($order->get_status() !== 'completed') {
            // payment_complete peut être bloquant selon l'état, donc on force le statut
            $order->update_status('completed', 'Bonzai sync: access active.');
        }
        return;
    }

    // 2) Access inactif
    if ($has_access === false) {

        // Si l'API indique explicitement un remboursement: refunded.
        if ($payment_refunded) {
            if ($order->get_status() !== 'refunded') {
                $order->update_status('refunded', 'Bonzai sync: payment refunded (access inactive).');
            }
            return;
        }

        // Si l'API indique explicitement un échec/annulation: failed/cancelled.
        if ($payment_failed_or_canceled && !$order->is_paid()) {
            // On n'annule pas une commande déjà marquée payée côté Woo.
            $target = ($intent_status_norm === 'failed') ? 'failed' : 'cancelled';
            if ($order->get_status() !== $target) {
                $order->update_status($target, 'Bonzai sync: payment ' . $intent_status_norm . ' (access inactive).');
            }
            return;
        }

        // Cas fréquent: paiement OK mais access pas encore accordé (race condition / traitement asynchrone).
        // Stratégie: si le paiement est confirmé (via retrieve ou via Woo), on fait avancer la commande.
        // Ici, on force directement "completed" pour que la double vérification (retrieve/webhook) fasse le taff
        // même si l'une des deux sources est HS.
        if ($payment_completed || $order->is_paid()) {
            if ($order->get_status() !== 'completed') {
                $order->update_status('completed', 'Bonzai sync: payment completed but access not yet active. Marking completed; waiting for webhook/access update.');
            } else {
                $order->add_order_note('Bonzai sync: payment completed but access not yet active. Already completed; waiting for webhook/access update.');
            }
            return;
        }

        // Si paiement jamais complété: ne pas toucher.
        $order->add_order_note('Bonzai sync: access inactive and payment not completed. No status change.');
        return;
    }

    // 3) Cas indéterminé: on ne touche pas au statut
    $order->add_order_note('Bonzai sync: unable to determine access state. No status change.');
}

add_action('init', 'bonzai_register_cron_event');

function bonzai_register_cron_event() {
    if (!wp_next_scheduled('bonzai_cron_order_sync')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'bonzai_cron_order_sync');
    }
}

add_action('bonzai_cron_order_sync', 'bonzai_run_cron_order_sync');

function bonzai_run_cron_order_sync() {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return;

    $mode = $gw->order_sync_enabled ?? 'no';
    if ($mode === 'no') return;

    $hour_config = isset($gw->order_sync_hour) ? (int) $gw->order_sync_hour : 3;
    $day_config  = isset($gw->order_sync_day) ? strtolower($gw->order_sync_day) : 'monday';

    $now      = current_datetime();
    $hour_now = (int) $now->format('G');
    $day_now  = strtolower($now->format('l'));

    if ($hour_now !== $hour_config) return;

    if ($mode === 'daily') {
        $today = $now->format('Y-m-d');
        $last  = get_option('bonzai_sync_last_daily');
        if ($last === $today) return;
        update_option('bonzai_sync_last_daily', $today);
    } elseif ($mode === 'weekly') {
        if ($day_now !== $day_config) return;
        $yearweek = $now->format('o-W');
        $last     = get_option('bonzai_sync_last_weekly');
        if ($last === $yearweek) return;
        update_option('bonzai_sync_last_weekly', $yearweek);
    } else {
        return;
    }

    if (!empty($gw->debug)) {
        $gw->log('Starting automatic Bonzai order sync via cron.');
    }

    $orders = wc_get_orders(array(
        'limit'        => -1,
        'meta_key'     => '_bonzai_order_id',
        'meta_compare' => 'EXISTS',
        'status'       => array('pending','on-hold','processing','completed','refunded','cancelled','failed'),
        'return'       => 'objects',
    ));

    if (empty($orders)) {
        if (!empty($gw->debug)) $gw->log('Automatic sync: no orders with Bonzai order_id found.');
        return;
    }

    foreach ($orders as $order) {
        $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
        if (!$bonzai_order_id) continue;

        $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
        if (is_wp_error($api_order)) {
            if (!empty($gw->debug)) {
                $gw->log('Automatic sync error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
            }
            $order->add_order_note('Bonzai automatic sync error: ' . $api_order->get_error_message());
            continue;
        }

        bonzai_store_last_retrieve_payload($order, $api_order);
        bonzai_sync_wc_order_with_bonzai($order, $api_order);
    }

    if (!empty($gw->debug)) {
        $gw->log('Automatic Bonzai order sync finished.');
    }
}

add_action('admin_menu', 'bonzai_register_admin_page');

function bonzai_register_admin_page() {
    add_submenu_page(
        'woocommerce',
        'Bonzai Order Sync',
        'Bonzai Order Sync',
        'manage_woocommerce',
        'bonzai_order_sync',
        'bonzai_render_order_sync_page'
    );
}

function bonzai_render_order_sync_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to access this page.');
    }

    $gw = bonzai_get_gateway_instance();
    if (!$gw) {
        echo '<div class="notice notice-error"><p>Bonzai gateway is not loaded.</p></div>';
        return;
    }

    $orders       = array();
    $search_email = '';
    $message      = '';
    $message_type = 'info';

    if (isset($_POST['bonzai_search_email']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'search') {
        check_admin_referer('bonzai_search_orders');
        $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
            if (empty($orders)) {
                $message = 'No orders found for this email.';
                $message_type = 'warning';
            }
        } else {
            $message = 'Please enter a valid email address.';
            $message_type = 'error';
        }
    }

    if (isset($_POST['bonzai_sync_order_id']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'sync') {
        check_admin_referer('bonzai_sync_single_order');

        $order_id = absint($_POST['bonzai_sync_order_id']);
        $search_email = isset($_POST['bonzai_search_email']) ? sanitize_email(wp_unslash($_POST['bonzai_search_email'])) : '';
        $order = wc_get_order($order_id);

        if ($order) {
            $o = wc_get_order($order_id);
            $bonzai_order_id = $o ? $o->get_meta('_bonzai_order_id', true) : '';
            if (!$bonzai_order_id) {
                $message = 'This order does not have a Bonzai order_id. It cannot be synced.';
                $message_type = 'error';
            } else {
                $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
                if (is_wp_error($api_order)) {
                    $message = 'Error while retrieving order from Bonzai: ' . esc_html($api_order->get_error_message());
                    $message_type = 'error';
                    $order->add_order_note('Bonzai manual sync error: ' . $api_order->get_error_message());
                } else {
                    bonzai_store_last_retrieve_payload($order, $api_order);
                    bonzai_sync_wc_order_with_bonzai($order, $api_order);
                    $message = 'Bonzai order synced successfully for WooCommerce order #' . $order_id . '.';
                    $message_type = 'success';
                }
            }
        } else {
            $message = 'Invalid WooCommerce order ID.';
            $message_type = 'error';
        }

        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
        }
    }

    $notice_class = 'notice notice-info';
    if ($message_type === 'success') $notice_class = 'notice notice-success';
    if ($message_type === 'warning') $notice_class = 'notice notice-warning';
    if ($message_type === 'error')   $notice_class = 'notice notice-error';

    echo '<div class="wrap"><h1>Bonzai Order Sync</h1>';

    if ($message) {
        echo '<div class="' . esc_attr($notice_class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    echo '<h2>Search orders by customer email</h2>';
    echo '<form method="post">';
    wp_nonce_field('bonzai_search_orders');
    echo '<input type="hidden" name="bonzai_action" value="search" />';
    echo '<p><label for="bonzai_search_email">Customer email:</label> ';
    echo '<input type="email" id="bonzai_search_email" name="bonzai_search_email" value="' . esc_attr($search_email) . '" size="40" />';
    submit_button('Search orders', 'secondary', 'submit', false);
    echo '</p></form>';

    if (!empty($orders)) {
        echo '<h2>Orders for ' . esc_html($search_email) . '</h2>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total</th><th>Bonzai order_id</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $order) {
            $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
            $payload_exists = (bool) $order->get_meta('_bonzai_last_retrieve_payload', true);

            echo '<tr>';
            echo '<td><a href="' . esc_url(get_edit_post_link($order->get_id())) . '">#' . esc_html($order->get_id()) . '</a></td>';
            echo '<td>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : '') . '</td>';
            echo '<td>' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            $total_html = wp_kses_post(
                wc_price($order->get_total(), array('currency' => $order->get_currency()))
            );

            if ($order->has_status('refunded')) {
                $zero_html = wp_kses_post(
                    wc_price(0, array('currency' => $order->get_currency()))
                );

                echo '<td>'
                    . '<del>' . $total_html . '</del> '
                    . '<ins>' . $zero_html . '</ins>'
                    . '</td>';
            } else {
                echo '<td>' . $total_html . '</td>';
            }
            echo '<td>' . esc_html($bonzai_order_id ? $bonzai_order_id : '') . '</td>';

            echo '<td>';
            if ($bonzai_order_id) {
                echo '<form method="post" style="display:inline-block; margin-right:8px;">';
                wp_nonce_field('bonzai_sync_single_order');
                echo '<input type="hidden" name="bonzai_action" value="sync" />';
                echo '<input type="hidden" name="bonzai_search_email" value="' . esc_attr($search_email) . '" />';
                echo '<input type="hidden" name="bonzai_sync_order_id" value="' . esc_attr($order->get_id()) . '" />';
                submit_button('Sync with Bonzai', 'primary', 'submit', false);
                echo '</form>';

                if ($payload_exists) {
                    echo '<button type="button" class="button bonzai_history_btn" data_order_id="' . esc_attr($order->get_id()) . '">History</button>';
                } else {
                    echo '<span style="margin-left:6px; color:#666;">No history yet</span>';
                }

            } else {
                echo 'No Bonzai order_id';
            }
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    $nonce = wp_create_nonce('bonzai_history_nonce');
    $ajax_url = admin_url('admin-ajax.php');

    echo '
<div id="bonzai_history_modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:99999;">
  <div style="background:#fff; width:90%; max-width:1100px; margin:40px auto; border-radius:6px; overflow:hidden;">
    <div style="padding:12px 16px; border-bottom:1px solid #ddd; display:flex; justify-content:space-between; align-items:center;">
      <div style="font-size:16px; font-weight:600;">Bonzai Retrieve History</div>
      <button type="button" class="button" id="bonzai_history_close">Close</button>
    </div>
    <div id="bonzai_history_meta" style="padding:8px 16px; border-bottom:1px solid #eee; color:#444;"></div>
    <div id="bonzai_history_content" style="max-height:70vh; overflow:auto;"></div>
  </div>
</div>

<script type="text/javascript">
(function($){
  function openModal(){ $("#bonzai_history_modal").show(); }
  function closeModal(){
    $("#bonzai_history_modal").hide();
    $("#bonzai_history_content").html("");
    $("#bonzai_history_meta").text("");
  }

  $(document).on("click", "#bonzai_history_close", function(){ closeModal(); });
  $(document).on("click", "#bonzai_history_modal", function(e){
    if (e.target === this) closeModal();
  });

  $(document).on("click", ".bonzai_history_btn", function(){
    var orderId = $(this).attr("data_order_id");
    $("#bonzai_history_content").html("<div style=\'padding:12px;\'>Loading...</div>");
    $("#bonzai_history_meta").text("");
    openModal();

    $.post("' . esc_js($ajax_url) . '", {
      action: "bonzai_get_order_history",
      nonce: "' . esc_js($nonce) . '",
      order_id: orderId
    })
    .done(function(resp){
      if (!resp || !resp.success) {
        var msg = (resp && resp.data && resp.data.message) ? resp.data.message : "Unknown error";
        $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>" + msg + "</div>");
        return;
      }
      if (resp.data && resp.data.last_retrieve_at) {
        $("#bonzai_history_meta").text("Last retrieve at: " + resp.data.last_retrieve_at);
      }
      $("#bonzai_history_content").html(resp.data.html || "<div style=\'padding:12px;\'>No data</div>");
    })
    .fail(function(){
      $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>Request failed</div>");
    });
  });
})(jQuery);
</script>
';

    echo '</div>';
}

add_action('wp_ajax_bonzai_get_order_history', 'bonzai_ajax_get_order_history');

function bonzai_ajax_get_order_history() {
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    check_ajax_referer('bonzai_history_nonce', 'nonce');

    $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
    if (!$order_id) {
        wp_send_json_error(array('message' => 'Missing order_id'), 400);
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(array('message' => 'Invalid WooCommerce order'), 404);
    }

    $payload_json = $order->get_meta('_bonzai_last_retrieve_payload', true);
    if (!$payload_json) {
        wp_send_json_error(array('message' => 'No stored Retrieve payload for this order. Run Sync first.'), 404);
    }

    $payload = json_decode($payload_json, true);
    if (!is_array($payload)) {
        wp_send_json_error(array('message' => 'Stored payload is invalid JSON'), 500);
    }

    $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
    $html = bonzai_render_history_html($payload, $bonzai_order_id);

    $last_at = (string) $order->get_meta('_bonzai_last_retrieve_at', true);

    wp_send_json_success(array(
        'html' => $html,
        'last_retrieve_at' => $last_at,
    ));
}

/**
 * Validate and parse a Bonzai checkout URL.
 *
 * Security goal: avoid turning the popup endpoint into an open redirect/iframe loader.
 * We only allow HTTPS URLs to bonzai.pro and its subdomains.
 *
 * @param string $url
 * @return array|null Parsed URL parts when valid, otherwise null.
 */
function bonzai_extract_bonzai_target($url) {
    $url = trim((string) $url);
    if ($url === '') {
        return null;
    }

    // Only allow absolute HTTPS URLs.
    $parts = wp_parse_url($url);
    if (!is_array($parts)) {
        return null;
    }

    $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
    if ($scheme !== 'https') {
        return null;
    }

    $host = isset($parts['host']) ? strtolower($parts['host']) : '';
    if ($host === '') {
        return null;
    }

    // Allow bonzai.pro and any subdomain *.bonzai.pro (including pay.bonzai.pro).
    if ($host === 'bonzai.pro' || $host === 'www.bonzai.pro') {
        return $parts;
    }

    // Note: '.bonzai.pro' length is 11.
    if (substr($host, -11) === '.bonzai.pro') {
        return $parts;
    }

    return null;
}
