(function ($) {
  'use strict';

  var CFG = window.BONZAI_POPUP || {};
  var ajaxToken = CFG.ajax_token || '';

function cleanCheckoutUrl(url) {
  try {
    var u = new URL(url, window.location.origin);
    u.hash = '';
    // Remove wc-ajax if present
    u.searchParams.delete('wc-ajax');
    return u.toString();
  } catch (e) {
    // Fallback
    return (url || '').split('#')[0];
  }
}

function ensureCheckoutUrlField() {
  var $form = $('form.checkout');
  if (!$form.length) return;
  var $field = $form.find('input[name="bonzai_checkout_page_url"]');
  if (!$field.length) {
    $field = $('<input>', { type: 'hidden', name: 'bonzai_checkout_page_url' });
    $form.append($field);
  }
  $field.val(cleanCheckoutUrl(window.location.href));
}

  function ensureModal() {
    if (document.getElementById('bonzai-modal')) return;

    var overlay = document.createElement('div');
    overlay.id = 'bonzai-modal';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.right = '0';
    overlay.style.bottom = '0';
    overlay.style.zIndex = '999999';
    overlay.style.background = 'rgba(0,0,0,0.55)';
    overlay.style.display = 'none';

    var modal = document.createElement('div');
    modal.style.position = 'absolute';
    modal.style.top = '50%';
    modal.style.left = '50%';
    modal.style.transform = 'translate(-50%, -50%)';
    modal.style.width = 'min(1100px, 96vw)';
    modal.style.height = 'min(780px, 94vh)';
    modal.style.background = '#fff';
    modal.style.borderRadius = '10px';
    modal.style.overflow = 'hidden';
    modal.style.boxShadow = '0 10px 40px rgba(0,0,0,0.35)';

    var header = document.createElement('div');
    header.style.height = '44px';
    header.style.display = 'flex';
    header.style.alignItems = 'center';
    header.style.justifyContent = 'space-between';
    header.style.padding = '0 10px';
    header.style.background = '#0b0f1a';
    header.style.color = '#fff';

    var title = document.createElement('div');
    title.textContent = (CFG.i18n && CFG.i18n.title) ? CFG.i18n.title : 'Secure payment';
    title.style.fontSize = '14px';

    var close = document.createElement('button');
    close.type = 'button';
    close.textContent = (CFG.i18n && CFG.i18n.close) ? CFG.i18n.close : 'Close';
    close.style.border = '0';
    close.style.background = 'transparent';
    close.style.color = '#fff';
    close.style.cursor = 'pointer';
    close.style.fontSize = '14px';

    var frame = document.createElement('iframe');
    frame.id = 'bonzai-iframe';
    frame.style.width = '100%';
    frame.style.height = 'calc(100% - 44px)';
    frame.style.border = '0';
    frame.setAttribute('allow', 'payment *; clipboard-read; clipboard-write');

    header.appendChild(title);
    header.appendChild(close);
    modal.appendChild(header);
    modal.appendChild(frame);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    function hide() {
      overlay.style.display = 'none';
      frame.src = 'about:blank';
      if (window.location.hash === '#bonzai') {
        try { history.replaceState(null, document.title, window.location.href.split('#')[0]); } catch (e) {}
      }
    }

    close.addEventListener('click', hide);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) hide();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && overlay.style.display !== 'none') hide();
    });
  }

  function showModal(url) {
    ensureModal();
    var overlay = document.getElementById('bonzai-modal');
    var frame = document.getElementById('bonzai-iframe');
    frame.src = url;
    overlay.style.display = 'block';

    // Fallback: if the iframe navigates back to a same-origin URL (e.g. WooCommerce thank-you),
    // break out of the modal and redirect the main window.
    try {
      if (window.__bonzaiPopupPoll) {
        window.clearInterval(window.__bonzaiPopupPoll);
        window.__bonzaiPopupPoll = null;
      }
      window.__bonzaiPopupPoll = window.setInterval(function () {
        try {
          if (frame && frame.contentWindow && frame.contentWindow.location) {
            var href = String(frame.contentWindow.location.href || '');
            if (href && href.indexOf(window.location.origin) === 0) {
              window.clearInterval(window.__bonzaiPopupPoll);
              window.__bonzaiPopupPoll = null;
              window.location.href = href;
            }
          }
        } catch (e) {
          // Cross-origin while still on Bonzai; ignore.
        }
      }, 1000);
    } catch (e) {
      // ignore
    }
  }

  function fetchSessionAndOpen() {
    if (!CFG.session_ajax) return;
    var q = {};
    if (ajaxToken) q.bonzai_token = ajaxToken;
    if (CFG.nonce) q.bonzai_nonce = CFG.nonce;
    $.get(CFG.session_ajax, q)
      .done(function (res) {
        if (!res || !res.ok || !res.embed_url) return;
        showModal(res.embed_url);
      })
      .fail(function () {
        // ignore
      });
  }

  // 1) If WooCommerce redirects to checkout_url#bonzai, open the modal from session.
  function handleHash() {
    if (window.location.hash === '#bonzai') {
      fetchSessionAndOpen();
    }
  }

  $(window).on('hashchange', handleHash);
  $(document).ready(function(){ ensureCheckoutUrlField(); handleHash(); });

  // 2) Intercept WooCommerce checkout success to prevent any navigation and open modal immediately.
  // This works for classic checkout. If a builder bypasses Woo's JS, we still have the hash fallback.
  $(document.body).on('updated_checkout', ensureCheckoutUrlField);

  $(document.body).on('checkout_place_order_success', function (e, result) {
    try {
      ensureCheckoutUrlField();
      var pm = $('input[name="payment_method"]:checked').val();
      if (pm !== 'bonzai') return true;

      // Stop the default redirect.
      if (result && result.redirect) {
        // Force hash on current checkout URL (no page reload) and let the hash handler open the modal.
        window.location.hash = '#bonzai';
        // Prevent Woo from navigating away.
        return false;
      }
    } catch (err) {
      // fall through
    }
    return true;
  });

})(jQuery);
