/* global jQuery, BONZAI_INLINE */
(function ($) {
  'use strict';

  var cfg = window.BONZAI_INLINE || {};
  var gatewayId = cfg.gateway_id || 'bonzai';
  var hashFlag = cfg.hash || '#bonzai-inline';
  var prepareUrl = cfg.prepare_ajax || null;
  var restUrl = cfg.rest || null;
  var restNonce = cfg.nonce || null;
  var ajaxToken = cfg.ajax_token || '';
  var paymentEngine = cfg.payment_engine || 'iframe_legacy';
  var inflowCfg = cfg.inflow || {};

  var prepareTimer = null;
  var pollTimer = null;
  var lastPreparedFp = null;
  var lastEmbedUrl = null;
  var lastOrder = { id: 0, key: '' };
  var inflowScriptPromise = null;
  var inflowActive = false;

  // IMPORTANT: force a brand new Bonzai session once per page load
  var forceNewNextPrepare = true;

  // i18n / UX copy (English as requested)
  var copy = (cfg && cfg.i18n) ? cfg.i18n : {};
  // Base requirements (terms may or may not exist depending on the store configuration)
  var requirementsBase = copy.requirements_base ||
    'To access Bonzai payment, please fill in your First name, Last name, Email, and full billing address (street, state, postal code).';
  var requirementsWithTerms = copy.requirements_with_terms ||
    (requirementsBase + ' If a terms & conditions checkbox is shown, you must accept it before proceeding.');

  var missingFieldsBase = copy.missing_fields_base ||
    'Please complete the required fields (First name, Last name, Email, street address, state, postal code) before accessing the payment form.';
  var missingFieldsWithTerms = copy.missing_fields_with_terms ||
    (missingFieldsBase + ' If a terms & conditions checkbox is shown, you must accept it to proceed.');

  // WooCommerce order button selectors (classic + blocks). We hide/disable them when Bonzai is selected.
  var orderButtonSelector = cfg.order_button_selector || '#place_order';
  var blocksOrderButtonSelector = '.wc-block-components-checkout-place-order-button, .wc-block-checkout__actions .wc-block-components-button';

  // Terms checkbox selectors (classic + blocks)
  var termsSelectors = [
    '#terms',
    'input[name="terms"]',
    '#wc-block-checkout__terms',
    'input[id*="terms"][type="checkbox"]'
  ].join(',');

  function getPaymentBox() {
    return $('.payment_box.payment_method_' + gatewayId).first();
  }

  function ensureContainer() {
    var box = getPaymentBox();
    if (!box.length) return null;

    var c = box.find('#bonzai-inline-container');
    if (c.length) return c;

    c = $('<div id="bonzai-inline-container" class="is-hidden"></div>');
    c.append('<div id="bonzai-inline-loading" style="display:none"></div>');
    c.append('<div id="bonzai-inline-error" style="display:none"></div>');
    c.append('<div id="bonzai-inline-sdk" style="display:none"></div>');
    c.append('<iframe id="bonzai-inline-iframe" title="Bonzai secure payment" allow="payment *; clipboard-write *" style="display:none;"></iframe>');
    box.append(c);

    bindIframeEvents();
    return c;
  }

  function showLoading(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-sdk').hide().empty();
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-loading').show().text(msg || (copy.loading || 'Loading secure payment...'));
  }

  function showError(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-sdk').hide().empty();
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-error').show().text(msg || (copy.error || 'Unable to load payment. Please refresh and try again.'));
  }

  function showIframe(url) {
    var c = ensureContainer();
    if (!c) return;
    inflowActive = false;

    var $iframe = c.find('#bonzai-inline-iframe');
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-sdk').hide().empty();

    // Always show loader until iframe really loads
    c.find('#bonzai-inline-loading').show().text(copy.loading || 'Loading secure payment...');

    // reset 3DS class; it will be re-evaluated on load
    $iframe.removeClass('is-3ds').hide();

    // FORCE HEIGHT (merchant setting):
    // Some 3DS providers (e.g. Basic Theory) render the challenge inside nested iframes
    // without changing the top iframe URL and without emitting reliable postMessage events.
    // In those cases, the `.is-3ds` class will never toggle, so we apply the configured
    // 3DS height directly whenever the iframe is displayed.
    var h3 = parseInt(cfg.iframe_height_3ds || 0, 10);
    if (h3 && h3 > 0) {
      // Boundaries must match server-side validation.
      if (h3 < 300) h3 = 300;
      if (h3 > 2000) h3 = 2000;
      // Force it even if the theme injects an `!important` height rule.
// jQuery .css() cannot set !important, so we use style.setProperty.
try {
  if ($iframe[0] && $iframe[0].style) {
    $iframe[0].style.setProperty('height', h3 + 'px', 'important');
    $iframe[0].style.setProperty('min-height', h3 + 'px', 'important');
    $iframe[0].style.setProperty('max-height', 'none', 'important');
  } else {
    $iframe.css('height', h3 + 'px');
    $iframe.css('min-height', h3 + 'px');
    $iframe.css('max-height', 'none');
  }
} catch (e) {
  $iframe.css('height', h3 + 'px');
  $iframe.css('min-height', h3 + 'px');
  $iframe.css('max-height', 'none');
}
    }

    // ALSO force parent containers to expand (some themes/builders set max-height/overflow on wrappers).
    if (h3 && h3 > 0) {
      // 1) Inject a high-specificity stylesheet with !important rules.
      try {
        var styleId = 'bonzai-force-3ds-height';
        var $style = $('#' + styleId);
        var css = '';
        css += '#bonzai-inline-iframe{height:' + h3 + 'px!important;min-height:' + h3 + 'px!important;max-height:none!important;}';
        css += '.payment_box.payment_method_' + gatewayId + ', .payment_box.payment_method_' + gatewayId + ' #bonzai-inline-container{max-height:none!important;overflow:visible!important;height:auto!important;}';
        css += '.payment_box.payment_method_' + gatewayId + ' #bonzai-inline-container{min-height:' + h3 + 'px!important;}';
        if ($style.length) {
          $style.text(css);
        } else {
          $('<style>', { id: styleId, type: 'text/css' }).text(css).appendTo('head');
        }
      } catch (e2) {}

      // 2) Walk up the DOM from the iframe and neutralize max-height/overflow that could clip the iframe.
      try {
        var $p = $iframe;
        for (var i = 0; i < 12; i++) {
          $p = $p.parent();
          if (!$p || !$p.length) break;
          if ($p.is('body') || $p.is('html') || $p.is('form.checkout')) break;

          if ($p[0] && $p[0].style) {
            $p[0].style.setProperty('max-height', 'none', 'important');
            $p[0].style.setProperty('overflow', 'visible', 'important');
            $p[0].style.setProperty('height', 'auto', 'important');
          }

          if ($p.hasClass('payment_box') || $p.attr('id') === 'bonzai-inline-container') {
            if ($p[0] && $p[0].style) {
              $p[0].style.setProperty('min-height', h3 + 'px', 'important');
            }
          }
        }
      } catch (e3) {}
    }


    // Hard reload without breaking signature: only append a fragment
    var finalUrl = url;
    if (finalUrl.indexOf('#') === -1) {
      finalUrl += '#t=' + Date.now();
    } else {
      finalUrl += '&t=' + Date.now();
    }

    // Avoid reusing an already stuck iframe: always re-set src on prepare
    $iframe.attr('src', finalUrl);
  }

  function loadInflowScript() {
    if (!inflowCfg || !inflowCfg.sdk_script_url) {
      return $.Deferred().reject(new Error('missing_sdk_script_url')).promise();
    }
    // Some SDK bundles still reference `process.env.NODE_ENV` in browser context.
    // Provide a tiny shim to avoid "process is not defined" runtime crashes.
    try {
      var g = (typeof globalThis !== 'undefined') ? globalThis : window;
      if (!g.process) g.process = {};
      if (!g.process.env) g.process.env = {};
      if (typeof g.process.env.NODE_ENV === 'undefined') {
        g.process.env.NODE_ENV = 'production';
      }
    } catch (e) {}
    if (window.InflowPaySDK || window.InflowPay || window.inflowPay || window.Inflow || window.InflowSDK) {
      return $.Deferred().resolve().promise();
    }
    if (inflowScriptPromise) return inflowScriptPromise;

    var dfd = $.Deferred();
    var s = document.createElement('script');
    s.async = true;
    s.src = inflowCfg.sdk_script_url;
    s.onload = function () { dfd.resolve(); };
    s.onerror = function () { dfd.reject(new Error('sdk_load_failed')); };
    document.head.appendChild(s);
    inflowScriptPromise = dfd.promise();
    return inflowScriptPromise;
  }

  function resolveInflowApi() {
    return window.InflowPaySDK || window.InflowPay || window.inflowPay || window.Inflow || window.InflowSDK || null;
  }

  function getInflowLocale() {
    var locale = inflowCfg && inflowCfg.locale ? String(inflowCfg.locale).toLowerCase() : '';
    return locale || 'en';
  }

  function createInflowPayload(mountEl, publicKey, paymentId) {
    return {
      publicKey: publicKey,
      public_key: publicKey,
      inflowpay_public_key: publicKey,
      paymentId: paymentId,
      payment_id: paymentId,
      inflowpay_payment_id: paymentId,
      container: mountEl,
      element: mountEl,
      mount: mountEl,
      orderId: lastOrder.id,
      orderKey: lastOrder.key
    };
  }

  function createInflowCardOptions(mountEl, paymentId, onError) {
    return {
      paymentId: paymentId,
      container: mountEl,
      showDefaultSuccessUI: true,
      onComplete: function () {},
      onError: onError,
      style: {
        inputContainer: {
          backgroundColor: '#F5F5F5',
          borderRadius: '8px',
          borderEnabled: true,
          borderColor: 'transparent'
        },
        fontFamily: 'Inter',
        input: {
          borderColor: '#E0E0E0',
          textColor: '#1A1A1A',
          placeholderColor: '#999999',
          backgroundColor: '#FFFFFF'
        }
      }
    };
  }

  function logInflowInit(branch, locale, paymentId, cardOptions) {
    if (!window.console || typeof window.console.info !== 'function') return;
    window.console.info('[Bonzai][Inflow SDK] init', {
      branch: branch,
      locale: locale,
      paymentId: paymentId,
      style: cardOptions && cardOptions.style ? cardOptions.style : null,
      showDefaultSuccessUI: !!(cardOptions && cardOptions.showDefaultSuccessUI)
    });
  }

  function tryStartInflow(api, mountEl, publicKey, paymentId) {
    var payload = createInflowPayload(mountEl, publicKey, paymentId);
    var locale = getInflowLocale();
    var cardOptions;
    mountEl.classList.add('bonzai-inflow-mounted');
    if (typeof window.BONZAI_INFLOW_ADAPTER === 'function') {
      return window.BONZAI_INFLOW_ADAPTER(payload);
    }
    if (!api) throw new Error('sdk_api_not_found');
    if (typeof api.InflowPayProvider === 'function') {
      var provider = new api.InflowPayProvider({ config: { publicKey: publicKey, locale: locale } });
      cardOptions = createInflowCardOptions(mountEl, paymentId, function (err2) {
        if (window.console && typeof window.console.error === 'function') {
          window.console.error('[Bonzai][Inflow SDK] onError', err2);
        }
      });
      logInflowInit('provider', locale, paymentId, cardOptions);
      var card2 = provider.createCardElement(cardOptions);
      if (card2 && typeof card2.mount === 'function') return card2.mount();
      return card2;
    }
    // Inflow SDK v0.8+ UMD also exposes a PaymentSDK API.
    if (typeof api.PaymentSDK === 'function') {
      var sdk = new api.PaymentSDK({ publicKey: publicKey, locale: locale });
      cardOptions = createInflowCardOptions(mountEl, paymentId, function (err) {
        if (window.console && typeof window.console.error === 'function') {
          window.console.error('[Bonzai][Inflow SDK] onError', err);
        }
      });
      logInflowInit('payment_sdk', locale, paymentId, cardOptions);
      var card = sdk.createCardElement(cardOptions);
      if (card && typeof card.mount === 'function') return card.mount();
      return card;
    }
    if (typeof api.mount === 'function') return api.mount(payload);
    if (typeof api.start === 'function') return api.start(payload);
    if (typeof api.init === 'function') return api.init(payload);
    if (typeof api.create === 'function') {
      var inst = api.create(payload);
      if (inst && typeof inst.mount === 'function') return inst.mount(mountEl);
      return inst;
    }
    throw new Error('sdk_entrypoint_not_found');
  }

  function showInflow(publicKey, paymentId) {
    var c = ensureContainer();
    if (!c) return $.Deferred().reject(new Error('no_container')).promise();

    var dfd = $.Deferred();
    var mountEl = c.find('#bonzai-inline-sdk').get(0);
    if (!mountEl) {
      dfd.reject(new Error('missing_sdk_mount'));
      return dfd.promise();
    }

    showLoading(copy.loading || 'Loading secure payment...');
    loadInflowScript().done(function () {
      try {
        var api = resolveInflowApi();
        tryStartInflow(api, mountEl, publicKey, paymentId);
        inflowActive = true;
        c.removeClass('is-hidden');
        c.find('#bonzai-inline-loading').hide();
        c.find('#bonzai-inline-error').hide().text('');
        c.find('#bonzai-inline-iframe').hide();
        c.find('#bonzai-inline-sdk').show();
        dfd.resolve();
      } catch (err) {
        dfd.reject(err);
      }
    }).fail(function (err) {
      dfd.reject(err || new Error('sdk_load_failed'));
    });

    return dfd.promise();
  }

  function hideContainer() {
    var c = ensureContainer();
    if (!c) return;
    inflowActive = false;
    c.addClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-sdk').hide().empty();
    c.find('#bonzai-inline-iframe').hide();
  }

  function isGatewaySelected() {
    return $('input[name="payment_method"]:checked').val() === gatewayId;
  }

  function getCheckoutForm() {
    var $form = $('form.checkout');
    if ($form.length) return $form;

    $form = $('form').filter(function () {
      return $(this).find('input[name="payment_method"]').length > 0;
    }).first();

    return $form.length ? $form : null;
  }

  function getFieldValue(selectors) {
    var val = '';
    selectors.split(',').forEach(function (sel) {
      sel = $.trim(sel);
      if (!sel) return;
      var $el = $(sel).first();
      if ($el.length && $el.val() !== undefined && $el.val() !== null) {
        val = String($el.val());
      }
    });
    return $.trim(val);
  }

  function getCheckoutSnapshot() {
    var email = getFieldValue('#billing_email, input[name="billing_email"]');
    var first = getFieldValue('#billing_first_name, input[name="billing_first_name"]');
    var last = getFieldValue('#billing_last_name, input[name="billing_last_name"]');
    var postcode = getFieldValue('#billing_postcode, input[name="billing_postcode"]');
    var address1 = getFieldValue('#billing_address_1, input[name="billing_address_1"]');
    var city = getFieldValue('#billing_city, input[name="billing_city"]');
    var country = getFieldValue('#billing_country, select[name="billing_country"], input[name="billing_country"]');
    var state = getFieldValue('#billing_state, select[name="billing_state"], input[name="billing_state"]');

    // State is not required in all countries. We approximate this by checking whether the field
    // is visible and marked as required by WooCommerce validation classes/attributes.
    var $stateEl = $('#billing_state, select[name="billing_state"], input[name="billing_state"]').first();
    var statePresent = $stateEl.length > 0;
    var stateVisible = statePresent && $stateEl.is(':visible') && !$stateEl.prop('disabled');
    var stateRequired = false;
    if (stateVisible) {
      var $stateRow = $stateEl.closest('.form-row');
      stateRequired = !!($stateEl.prop('required') || $stateEl.attr('aria-required') === 'true' || $stateRow.hasClass('validate-required') || $stateRow.hasClass('woocommerce-validated') && $stateRow.hasClass('validate-required'));
    }

    // Terms: only enforce if a terms checkbox exists on the page.
    var $terms = $(termsSelectors).first();
    var termsPresent = $terms.length > 0;
    var termsAccepted = termsPresent ? !!$terms.prop('checked') : true;

    return {
      email: email,
      first: first,
      last: last,
      postcode: postcode,
      address1: address1,
      city: city,
      country: country,
      state: state,
      stateRequired: stateRequired,
      termsPresent: termsPresent,
      termsAccepted: termsAccepted
    };
  }

  function isValidEmail(email) {
    return !!email && /.+@.+\..+/.test(email);
  }

  function computeFp(snapshot) {
    return [snapshot.email, snapshot.first, snapshot.last, snapshot.address1, snapshot.city, snapshot.country, snapshot.state, snapshot.postcode].join('|');
  }

  function hasRequiredFields(snap) {
    if (!snap) return false;
    if (!isValidEmail(snap.email)) return false;
    if (!snap.first || !snap.last) return false;
    if (!snap.address1 || !snap.city || !snap.country || !snap.postcode) return false;
    if (snap.stateRequired && !snap.state) return false;
    // Only enforce terms acceptance if a terms checkbox is actually present.
    if (snap.termsPresent && !snap.termsAccepted) return false;
    return true;
  }

  function toggleOrderButtons() {
    var hide = isGatewaySelected();

    // Classic checkout button
    var $btn = $(orderButtonSelector);
    if ($btn.length) {
      if (hide) {
        $btn.prop('disabled', true).attr('aria-disabled', 'true').hide();
      } else {
        $btn.prop('disabled', false).removeAttr('aria-disabled').show();
      }
    }

    // Blocks checkout button (best-effort)
    var $bbtn = $(blocksOrderButtonSelector);
    if ($bbtn.length) {
      if (hide) {
        $bbtn.prop('disabled', true).attr('aria-disabled', 'true').hide();
      } else {
        $bbtn.prop('disabled', false).removeAttr('aria-disabled').show();
      }
    }
  }

  function isLikely3dsUrl(url) {
    if (!url) return false;
    return /3ds|secure|authentication|acs|challenge/i.test(url);
  }

  function update3dsClass($iframe) {
    var src = String($iframe.attr('src') || '');
    if (isLikely3dsUrl(src)) $iframe.addClass('is-3ds');
    else $iframe.removeClass('is-3ds');
  }

  function bindIframeEvents() {
    var c = ensureContainer();
    if (!c) return;
    var $iframe = c.find('#bonzai-inline-iframe');

    if ($iframe.data('bonzaiBound')) return;
    $iframe.data('bonzaiBound', true);

    $iframe.on('load', function () {
      // iframe loaded: hide loader and show iframe
      update3dsClass($iframe);
      c.find('#bonzai-inline-loading').hide();
      $iframe.show();
    });

    // Listen to Bonzai iframe postMessage events to detect 3DS reliably.
    // We cannot read iframe DOM (cross-origin), so this is the clean approach.
    // We bind this once per page and only react to messages coming from our iframe window.
    function getIframeOrigin($ifr){
      try {
        var src = String($ifr.attr('src') || '');
        if (!src) return '';
        // URL() handles absolute URLs; relative should never happen here.
        return (new URL(src, window.location.href)).origin;
      } catch(e){
        return '';
      }
    }

    if (!window.__bonzaiInlineMsgBound) {
      window.__bonzaiInlineMsgBound = true;
      window.addEventListener('message', function (event) {
        try {
          var $ifr = $('#bonzai-inline-iframe');
          if (!$ifr.length) return;
          var ifr = $ifr[0];
          if (!ifr || !ifr.contentWindow) return;

          // SECURITY:
          // Bonzai may emit messages from within nested frames during 3DS.
          // In those cases, event.source is not equal to iframe.contentWindow.
          // We therefore prefer validating via origin when possible.
          var expectedOrigin = getIframeOrigin($ifr);
          if (expectedOrigin && event.origin && event.origin !== expectedOrigin) {
            return;
          }

          // Fallback (when origin is missing): only trust direct iframe window.
          if (!event.origin && event.source !== ifr.contentWindow) {
            return;
          }

          var data = event.data;
          var type = '';
          var state = '';

          if (typeof data === 'string') {
            type = data;
          } else if (data && typeof data === 'object') {
            type = String(data.type || data.event || '');
            state = String(data.state || data.status || '');
          }

          var t = (type || '').toLowerCase();
          var s = (state || '').toLowerCase();

          // Start 3DS
          if (
            t === 'bonzai_3ds_start' ||
            (t === 'bonzai_checkout_state' && s === '3ds') ||
            t.indexOf('3ds') !== -1 ||
            s.indexOf('3ds') !== -1
          ) {
            $ifr.addClass('is-3ds');
            return;
          }

          // End 3DS / back to payment step
          if (
            t === 'bonzai_3ds_end' ||
            (t === 'bonzai_checkout_state' && (s === 'payment' || s === 'checkout'))
          ) {
            $ifr.removeClass('is-3ds');
          }
        } catch (e) {
          // Never block checkout UX on message handler errors.
        }
      });
    }
  }

  function prepareSession() {
    if (!prepareUrl) {
      showError('Configuration Bonzai invalide (prepare endpoint manquant).');
      return;
    }

    var snap = getCheckoutSnapshot();

    // Gate access to the payment form: require full identity + address + terms.
    if (!snap || !snap.email) {
      hideContainer();
      return;
    }
    if (!hasRequiredFields(snap)) {
      // Keep the container visible with clear instructions.
      showError(snap.termsPresent ? missingFieldsWithTerms : missingFieldsBase);
      return;
    }

    var fp = computeFp(snap);

    // If we already have a fresh embed for same identity and we are not forcing new
    if (!forceNewNextPrepare && lastPreparedFp && fp === lastPreparedFp && lastEmbedUrl) {
      showIframe(lastEmbedUrl);
      return;
    }

    var $form = getCheckoutForm();
    if (!$form) {
      showError('Formulaire de paiement introuvable.');
      return;
    }

    showLoading(copy.loading || 'Loading secure payment...');

    $.ajax({
      url: prepareUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        checkout_data: $form.serialize(),
        bonzai_token: ajaxToken,
        bonzai_nonce: restNonce,
        force_new: forceNewNextPrepare ? 1 : 0
      }
    }).done(function (res) {
      var missingFieldsMsg = snap.termsPresent ? missingFieldsWithTerms : missingFieldsBase;
      // After first call, stop forcing new sessions
      forceNewNextPrepare = false;

      if (!res || !res.ok) {
        var msg = copy.error || 'Unable to load payment. Please refresh and try again.';
        if (res && res.error === 'missing_email') msg = copy.missing_email || missingFieldsMsg;
        if (res && res.error === 'missing_required_fields') msg = missingFieldsMsg;
        if (res && res.error === 'missing_terms') msg = copy.missing_terms || 'Please accept the terms and conditions to proceed.';
        if (res && res.error === 'inflow_start_failed') msg = copy.sdk_unavailable || msg;
        showError(msg);
        return;
      }

      lastPreparedFp = fp;
      lastEmbedUrl = String(res.embed_url || '');
      lastOrder.id = parseInt(res.order_id || 0, 10) || 0;
      lastOrder.key = String(res.order_key || '');
      var engine = String(res.engine || paymentEngine || 'iframe_legacy');

      try {
        if (window.location.hash !== hashFlag) window.location.hash = hashFlag;
      } catch (e) {}

      if (engine === 'inflow_sdk' && res.inflowpay_public_key && res.inflowpay_payment_id) {
        showInflow(String(res.inflowpay_public_key), String(res.inflowpay_payment_id))
          .done(function () {
            startPolling();
          })
          .fail(function (err) {
            if (window.console && typeof window.console.error === 'function') {
              window.console.error('[Bonzai][Inflow SDK] embed inline init failed', err);
            }
            if (inflowCfg && inflowCfg.fallback_iframe && lastEmbedUrl) {
              showIframe(lastEmbedUrl);
              startPolling();
              return;
            }
            showError(copy.sdk_unavailable || (copy.error || 'Unable to load payment. Please refresh and try again.'));
          });
        return;
      }

      if (!lastEmbedUrl) {
        showError(copy.error || 'Unable to load payment. Please refresh and try again.');
        return;
      }
      showIframe(lastEmbedUrl);
      startPolling();
    }).fail(function () {
      showError(copy.error || 'Unable to load payment. Please refresh and try again.');
    });
  }

  function startPolling() {
    if (!restUrl || !lastOrder.id || !lastOrder.key) return;
    if (pollTimer) return;

    pollTimer = window.setInterval(function () {
      // Fallback for iframe mode: if provider navigates iframe back to merchant domain, escape immediately.
      if (!inflowActive) {
        try {
          var $ifr = $('#bonzai-inline-iframe');
          if ($ifr.length && $ifr[0].contentWindow && $ifr[0].contentWindow.location) {
            var href = String($ifr[0].contentWindow.location.href || '');
            if (href && href.indexOf(window.location.origin) === 0) {
              window.clearInterval(pollTimer);
              pollTimer = null;
              window.location.href = href;
              return;
            }
          }
        } catch (e) {
          // Cross-origin while still on provider domain; ignore.
        }
      }

      $.ajax({
        url: restUrl,
        method: 'GET',
        dataType: 'json',
        headers: restNonce ? { 'X-WP-Nonce': restNonce } : {},
        data: { order_id: lastOrder.id, order_key: lastOrder.key }
      }).done(function (res) {
        if (!res) return;

        var paid = false;
        var thankyou = '';

        if (res.ok) {
          paid = !!res.paid;
          thankyou = res.thankyou || '';
        } else if (res.valid !== undefined) {
          paid = !!res.paid;
          thankyou = res.thankyou_url || '';
        }

        if (paid && thankyou) {
          window.clearInterval(pollTimer);
          pollTimer = null;
          window.location.href = thankyou;
        }
      });
    }, 2000);
  }

  function schedulePrepare() {
    // Hide/disable the default WooCommerce order button when Bonzai is selected.
    toggleOrderButtons();
    if (!isGatewaySelected()) {
      hideContainer();
      return;
    }
    if (prepareTimer) window.clearTimeout(prepareTimer);
    prepareTimer = window.setTimeout(function () {
      prepareSession();
    }, 550);
  }

  function bindEvents() {
    ensureContainer();

    $(document.body).on('updated_checkout', function () {
      ensureContainer();
      // Do not force new here; just prepare if needed
      schedulePrepare();
    });

    $(document.body).on('change', 'input[name="payment_method"]', function () {
      toggleOrderButtons();
      if (!isGatewaySelected()) {
        hideContainer();
        lastPreparedFp = null;
        lastEmbedUrl = null;
        lastOrder = { id: 0, key: '' };
        forceNewNextPrepare = true; // next time user comes back, create a fresh session
        if (pollTimer) {
          window.clearInterval(pollTimer);
          pollTimer = null;
        }
        return;
      }
      // When user selects Bonzai, create a fresh session
      forceNewNextPrepare = true;
      schedulePrepare();
    });

    $(document.body).on(
      'input change',
      '#billing_first_name, #billing_last_name, #billing_email, #billing_postcode, #billing_address_1, #billing_city, #billing_country, #billing_state, input[name="billing_first_name"], input[name="billing_last_name"], input[name="billing_email"], input[name="billing_postcode"], input[name="billing_address_1"], input[name="billing_city"], select[name="billing_country"], input[name="billing_country"], select[name="billing_state"], input[name="billing_state"]',
      function () {
        schedulePrepare();
      }
    );

    // Terms acceptance must trigger re-check.
    $(document.body).on('change', termsSelectors, function () {
      schedulePrepare();
    });

    // Prevent the classic checkout from submitting when Bonzai is selected.
    // The payment is completed inside the Bonzai iframe; the WooCommerce button is hidden/disabled.
    $(document).on('submit', 'form.checkout', function (e) {
      if (!isGatewaySelected()) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      schedulePrepare();
      return false;
    });

    // If address changes affect totals, let Woo recompute then prepare
    $(document.body).on(
      'input change',
      '#billing_country, #billing_state, #billing_city, #billing_address_1, #billing_address_2, input[name="billing_country"], input[name="billing_state"], input[name="billing_city"], input[name="billing_address_1"], input[name="billing_address_2"]',
      function () {
        if (!isGatewaySelected()) return;
        $(document.body).trigger('update_checkout');
      }
    );

    // On page load: if Bonzai is already selected, force a fresh session once
    if (isGatewaySelected()) {
      forceNewNextPrepare = true;
      schedulePrepare();
    }
  }

  $(function () {
    bindEvents();
  });
})(jQuery);
